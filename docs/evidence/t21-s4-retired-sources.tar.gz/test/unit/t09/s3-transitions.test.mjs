/* global AbortController */
// Public-state oracles: shared creation prefix/lifecycle contract and S1 v1 format.
import { describe, it, expect } from "vitest";
import { setImmediate } from "node:timers/promises";
import { SessionError } from "../../../dist/auth/index.js";
import { decodeOperationStore, openOperationRepository } from "../../../dist/operations/index.js";
import { args, binding, durableBinding, gate, memory, signal } from "./s2-helpers.mjs";

const success = (record) => ({
  ok: true,
  data: { operationId: record.operationId, routineId: record.routineId, status: "saved" },
});
const rejection = (record, overrides = {}) => ({
  ok: false,
  error: {
    code: "id_collision",
    retryable: false,
    operationId: record.operationId,
    routineId: record.routineId,
    lastConfirmedStep: "none",
    outcomeUnknown: false,
    ...overrides,
  },
});
const stored = (f) => decodeOperationStore(f.bytes(), durableBinding).operations;

describe("S3 ordered durable state and lifecycle", () => {
  it("advances a confirmed prefix, retains exact identities/reservation/Int64, settles and minimizes", async () => {
    const f = memory();
    let initial;
    const receipt = await f.run(args(), async (h) => {
      initial = await h.snapshot();
      for (const [step, revision] of [
        ["draft", "9007199254740993"],
        ["populate", "9007199254740995"],
        ["save", "9223372036854775807"],
      ]) {
        await h.recordDispatchPossible(step);
        const commits = f.calls.commits;
        await h.recordDispatchPossible(step);
        expect(f.calls.commits).toBe(commits);
        expect((await h.snapshot()).steps.find((s) => s.step === step).state).toBe(
          "dispatch-possible",
        );
        await h.recordConfirmation({ step, revision });
        const confirmedCommits = f.calls.commits;
        await h.recordConfirmation({ revision, step });
        expect(f.calls.commits).toBe(confirmedCommits);
        expect((await h.confirmationBaseline()).revision).toBe(revision);
      }
      const confirmed = await h.snapshot();
      expect(confirmed.steps.map((step) => ({ ...step, state: "unsent" }))).toEqual(initial.steps);
      expect(confirmed.reservationBytes).toBe(initial.reservationBytes);
      const terminal = success(initial);
      await h.settleTerminal(terminal);
      const terminalCommits = f.calls.commits;
      await h.settleTerminal(terminal);
      expect(f.calls.commits).toBe(terminalCommits);
      expect(await h.confirmationBaseline()).toBeNull();
      await h.compactTerminal();
      const compactCommits = f.calls.commits;
      await h.compactTerminal();
      expect(f.calls.commits).toBe(compactCommits);
      await expect(h.recordDispatchPossible("save")).rejects.toMatchObject({
        code: "invalid_state",
      });
      await expect(h.readStep("draft")).rejects.toMatchObject({ code: "recovery_unavailable" });
      return h.snapshot();
    });
    expect(receipt).toEqual({
      version: 1,
      kind: "receipt",
      binding: durableBinding,
      operationId: initial.operationId,
      routineId: initial.routineId,
      intent: initial.intent,
      maxResponseBytes: initial.limits.maxResponseBytes,
      lastConfirmedStep: "save",
      result: success(initial),
    });
    expect(Buffer.from(f.bytes()).toString()).not.toContain("Synthetic routine");
    expect(await f.run()).toEqual(receipt);
    await expect(f.run({ ...args(), name: "Changed" })).rejects.toMatchObject({
      code: "operation_id_reused",
    });
    f.repository.close();
  });

  it("rejects invalid ordering, malformed facts and conflicting history without committing", async () => {
    const f = memory();
    await f.run(args(), async (h) => {
      const initial = f.bytes();
      for (const action of [
        () => h.recordDispatchPossible("populate"),
        () => h.recordConfirmation({ step: "draft", revision: "1" }),
        () => h.compactTerminal(),
      ]) {
        await expect(action()).rejects.toMatchObject({ code: "invalid_state" });
        expect(f.bytes()).toEqual(initial);
      }
      for (const marker of [
        { step: "draft", revision: "01" },
        { step: "draft", revision: "9223372036854775808" },
        { step: "draft", revision: 1 },
        { step: "draft", revision: "1", body: "forbidden" },
      ]) {
        await expect(h.recordConfirmation(marker)).rejects.toMatchObject({
          code: "invalid_arguments",
        });
      }
      await expect(h.recordDispatchPossible("unknown")).rejects.toMatchObject({
        code: "invalid_arguments",
      });
      await h.recordDispatchPossible("draft");
      await h.recordConfirmation({ step: "draft", revision: "1" });
      const confirmed = f.bytes();
      await expect(h.recordDispatchPossible("draft")).rejects.toMatchObject({
        code: "invalid_state",
      });
      await expect(h.recordConfirmation({ step: "draft", revision: "2" })).rejects.toMatchObject({
        code: "invalid_state",
      });
      expect(f.bytes()).toEqual(confirmed);
    });
    f.repository.close();
  });

  it("commits save confirmation and terminal conflict atomically in one store update", async () => {
    const f = memory();
    await f.run(args(), async (h) => {
      const initial = await h.snapshot();
      for (const step of ["draft", "populate"]) {
        await h.recordDispatchPossible(step);
        await h.recordConfirmation({ step, revision: step === "draft" ? "1" : "2" });
      }
      await h.recordDispatchPossible("save");
      const before = f.bytes(),
        count = f.calls.commits;
      const terminal = rejection(initial, {
        code: "concurrent_modification",
        lastConfirmedStep: "save",
      });
      const marker = { step: "save", revision: "3" };
      await h.recordConfirmation(marker, terminal);
      expect(f.calls.commits).toBe(count + 1);
      expect(f.bytes()).not.toEqual(before);
      const persisted = stored(f)[0];
      expect(persisted.confirmed).toEqual(marker);
      expect(persisted.terminal).toEqual(terminal);
      expect(persisted.steps.every((s) => s.state === "confirmed")).toBe(true);
      await h.recordConfirmation(marker, terminal);
      expect(f.calls.commits).toBe(count + 1);
      await h.compactTerminal();
      expect((await h.snapshot()).lastConfirmedStep).toBe("save");
    });
    f.repository.close();
  });

  it("invalid atomic terminal facts leave confirmation pending and terminal results cannot be replaced", async () => {
    const f = memory();
    await f.run(args(), async (h) => {
      const initial = await h.snapshot();
      await h.recordDispatchPossible("draft");
      const before = f.bytes();
      await expect(
        h.recordConfirmation({ step: "draft", revision: "1" }, success(initial)),
      ).rejects.toMatchObject({ code: "invalid_state" });
      expect(f.bytes()).toEqual(before);
      const result = rejection(initial);
      await h.settleTerminal(result);
      const terminal = f.bytes();
      await expect(
        h.settleTerminal(rejection(initial, { code: "backend_error" })),
      ).rejects.toMatchObject({ code: "invalid_state" });
      await expect(h.recordConfirmation({ step: "draft", revision: "1" })).rejects.toMatchObject({
        code: "invalid_state",
      });
      await expect(
        h.settleTerminal({
          ...result,
          error: { ...result.error, message: "private backend text" },
        }),
      ).rejects.toMatchObject({ code: "invalid_arguments" });
      expect(f.bytes()).toEqual(terminal);
    });
    await expect(
      f.repository.retireOperation(binding, args().operationId, signal()),
    ).rejects.toMatchObject({ code: "invalid_state" });
    f.repository.close();
  });

  it("uncertain evidence cannot compact; trusted retirement erases bodies and permanently reserves the ID", async () => {
    const f = memory();
    let initial;
    await f.run(args(), async (h) => {
      initial = await h.snapshot();
      await h.recordDispatchPossible("draft");
      await h.settleTerminal(rejection(initial, { code: "backend_error", outcomeUnknown: true }));
      const before = f.bytes();
      await expect(h.compactTerminal()).rejects.toMatchObject({ code: "invalid_state" });
      expect(f.bytes()).toEqual(before);
      await expect(h.recordDispatchPossible("draft")).rejects.toMatchObject({
        code: "invalid_state",
      });
    });
    f.repository.close();
    const disabled = openOperationRepository({
      owner: f.owner,
      reads: f.reads,
      config: { ...f.settings, writesEnabled: false },
    });
    await disabled.retireOperation(binding, args().operationId, signal());
    const tombstone = stored(f)[0];
    expect(tombstone).toEqual({
      version: 1,
      kind: "retired",
      binding: durableBinding,
      operationId: initial.operationId,
      routineId: initial.routineId,
    });
    const count = f.calls.commits;
    await disabled.retireOperation(binding, args().operationId, signal());
    expect(f.calls.commits).toBe(count);
    disabled.close();
    const enabled = f.factory();
    for (const input of [args(), { ...args(), name: "Changed" }])
      await expect(
        enabled.withOperation(binding, input, signal(), async () => {}),
      ).rejects.toMatchObject({ code: "recovery_unavailable" });
    await expect(
      enabled.retireOperation(binding, args(99).operationId, signal()),
    ).rejects.toMatchObject({ code: "recovery_unavailable" });
    expect(f.calls.commits).toBe(count);
    enabled.close();
  });

  it("state changes recheck current auth instead of retaining admission authorization", async () => {
    let deny = false;
    const f = memory({
      auth: async () => {
        if (deny) throw new SessionError("reauthentication_required");
      },
    });
    await f.run(args(), async (h) => {
      const before = f.bytes();
      deny = true;
      await expect(h.recordDispatchPossible("draft")).rejects.toMatchObject({
        code: "reauthentication_required",
      });
      expect(f.bytes()).toEqual(before);
      deny = false;
    });
    f.repository.close();
  });

  it("cancellation during transition commit preserves settled bytes and suppresses success", async () => {
    const started = gate(),
      release = gate(),
      abort = new AbortController();
    let hold = false;
    const f = memory({
      commit: async () => {
        if (hold) {
          started.resolve();
          await release.promise;
        }
      },
    });
    const pending = f
      .run(
        args(),
        async (h) => {
          hold = true;
          await h.recordDispatchPossible("draft");
        },
        abort.signal,
      )
      .catch((e) => e);
    await started.promise;
    abort.abort();
    let finished = false;
    void pending.then(() => {
      finished = true;
    });
    await setImmediate();
    expect(finished).toBe(false);
    release.resolve();
    expect(await pending).toMatchObject({ code: "operation_interrupted" });
    expect(stored(f)[0].steps[0].state).toBe("dispatch-possible");
    hold = false;
    expect((await f.run()).steps[0].state).toBe("dispatch-possible");
    f.repository.close();
  });

  it("callback end drains a begun unawaited commit before releasing same-ID exclusion", async () => {
    const started = gate(),
      release = gate();
    let hold = false,
      leaked;
    const f = memory({
      commit: async () => {
        if (hold) {
          started.resolve();
          await release.promise;
        }
      },
    });
    const first = f
      .run(args(), async (h) => {
        hold = true;
        leaked = h.recordDispatchPossible("draft").catch((e) => e);
        await started.promise;
      })
      .catch((e) => e);
    await started.promise;
    const authCalls = f.calls.auth;
    const second = f.run();
    let settled = false;
    void first.then(() => {
      settled = true;
    });
    await setImmediate();
    expect(settled).toBe(false);
    expect(f.calls.auth).toBe(authCalls);
    release.resolve();
    expect(await first).toMatchObject({ code: "operation_interrupted" });
    expect(await leaked).toMatchObject({ code: "operation_interrupted" });
    expect((await second).steps[0].state).toBe("dispatch-possible");
    expect(f.calls.commits).toBe(2);
    f.repository.close();
  });

  it("serializes different-ID state updates with admissions without losing either reservation", async () => {
    const f = memory();
    let first;
    await f.run(args(), async (h) => {
      first = await h.snapshot();
    });
    const [changed, other] = await Promise.all([
      f.run(args(), async (h) => {
        await h.recordDispatchPossible("draft");
        return h.snapshot();
      }),
      f.run(args(9)),
    ]);
    expect(stored(f)).toHaveLength(2);
    expect(stored(f).find((r) => r.operationId === first.operationId)).toEqual(changed);
    expect(changed.reservationBytes).toBe(first.reservationBytes);
    expect(other.routineId).not.toBe(first.routineId);
    f.repository.close();
  });
});
