/* global AbortController */
// Local decision fake only. Real holder/provider/auth evidence is in fault/t09.
import { createHmac } from "node:crypto";
import { openOperationRepository } from "../../../dist/operations/index.js";

export const uuid = (n) => `00000000-0000-4000-8000-${n.toString(16).padStart(12, "0")}`;
export const binding = {
  origin: "https://synthetic.example",
  accountUuid: uuid(1),
  profileGenerationId: uuid(2),
  sessionGeneration: 1,
};
export const durableBinding = {
  origin: binding.origin,
  accountUuid: binding.accountUuid,
  profileGenerationId: binding.profileGenerationId,
};
export const signal = () => new AbortController().signal;
export const args = (n = 3) => ({
  operationId: uuid(n),
  name: "Synthetic routine",
  exercises: [
    { exerciseId: uuid(4), sets: [{}] },
    { exerciseId: uuid(4), sets: [] },
  ],
});
export const config = (origin = binding.origin) => ({
  version: 1,
  serviceOrigin: origin,
  storage: {
    profileRoot: "/synthetic/profile",
    anchorRoot: "/synthetic/anchor",
    secretServiceBusAddress: "unix:path=/synthetic/bus",
  },
  bindingDescriptorPath: "/synthetic/binding.json",
  writesEnabled: true,
});
export function gate() {
  let resolve;
  const promise = new Promise((r) => {
    resolve = r;
  });
  return { promise, resolve };
}
export function memory(options = {}) {
  let bytes = new Uint8Array();
  let next = 100;
  const calls = { auth: 0, visible: [], commits: 0, allocated: 0, reads: 0 };
  const owner = {
    binding: { ...binding },
    async readOperationStoreBytes() {
      calls.reads++;
      return new Uint8Array(bytes);
    },
    async keyedIntentDigest(material) {
      return new Uint8Array(createHmac("sha256", "synthetic-only-key").update(material).digest());
    },
    async commit(update) {
      calls.commits++;
      if (options.commit) await options.commit(update);
      bytes = new Uint8Array(update.operationBytes);
    },
  };
  const reads = {
    get binding() {
      return { ...owner.binding };
    },
    async listRoutines(b, query, s) {
      calls.auth++;
      if (options.auth) await options.auth(b, query, s);
    },
    async getExercise(b, id, s) {
      calls.visible.push(id);
      if (options.visible) await options.visible(b, id, s);
    },
  };
  const settings = options.config ?? config();
  const factory = () =>
    openOperationRepository({
      owner,
      reads,
      config: settings,
      generateUuid() {
        calls.allocated++;
        return uuid(next++);
      },
    });
  const repository = factory();
  return {
    owner,
    reads,
    calls,
    repository,
    factory,
    settings,
    bytes: () => new Uint8Array(bytes),
    seed: (value) => {
      bytes = new Uint8Array(value);
    },
    run: (
      input = args(),
      work = (h) => h.snapshot(),
      s = signal(),
      captured = { ...owner.binding },
    ) => repository.withOperation(captured, input, s, work),
  };
}
