/* global AbortController */
// Specification-derived S2 local decisions/concurrency. No live auth claim.
import { describe, it, expect } from "vitest";
import { SessionError } from "../../../dist/auth/index.js";
import { TransportError } from "../../../dist/http/index.js";
import { StorageError, MAX_STORE_BYTES } from "../../../dist/storage/index.js";
import {
  decodeOperationStore,
  encodeOperationStore,
  measureOperationStore,
  openOperationRepository,
} from "../../../dist/operations/index.js";
import {
  args,
  binding,
  durableBinding,
  config,
  gate,
  memory,
  signal,
  uuid,
} from "./s2-helpers.mjs";

const error404 = () =>
  new TransportError("not_found", {
    backendErrorCode: null,
    retryAfterSeconds: null,
    status: 404,
    dispatched: true,
    outcomeUnknown: false,
    attempts: 1,
    elapsedMs: 0,
    correlationId: uuid(90),
  });

describe("S2 admission guards and identities", () => {
  it("captures arguments and policy before awaiting; freezes exact committed requests", async () => {
    const started = gate(),
      release = gate();
    const f = memory({
      auth: async (_b, query) => {
        expect(query).toEqual({ limit: 1 });
        started.resolve();
        await release.promise;
      },
    });
    const input = args();
    const pending = f.run(input, async (h) => {
      const snap = await h.snapshot();
      const request = await h.readStep("populate");
      const original = [...request.body];
      request.body.fill(0);
      expect([...(await h.readStep("populate")).body]).toEqual(original);
      expect(decodeOperationStore(f.bytes(), durableBinding).operations[0]).toEqual(snap);
      expect(snap.steps.every((s) => s.state === "unsent")).toBe(true);
      expect(await h.confirmationBaseline()).toBeNull();
      return snap;
    });
    await started.promise;
    input.name = "Changed after invocation";
    f.settings.writesEnabled = false;
    release.resolve();
    const record = await pending;
    expect(JSON.parse(Buffer.from(record.steps[1].bodyBase64, "base64")).name).toBe(
      "Synthetic routine",
    );
    expect(f.calls.visible).toEqual([uuid(4)]);
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  for (const enabled of [false, undefined, "true"]) {
    it(`fails closed for writesEnabled ${String(enabled)}`, async () => {
      const settings = config();
      if (enabled === undefined) delete settings.writesEnabled;
      else settings.writesEnabled = enabled;
      if (enabled === "true") {
        expect(() => memory({ config: settings })).toThrow(
          expect.objectContaining({ code: "configuration_required" }),
        );
        return;
      }
      const f = memory({ config: settings });
      await expect(f.run()).rejects.toMatchObject({ code: "configuration_required" });
      expect(f.calls).toEqual({ auth: 0, visible: [], commits: 0, allocated: 0, reads: 0 });
      f.repository.close();
    });
  }

  it("rejects complete invalid args without invoking getters or auth", async () => {
    const f = memory();
    let invoked = false;
    const bad = args();
    Object.defineProperty(bad, "name", {
      get() {
        invoked = true;
        return "bad";
      },
    });
    await expect(f.run(bad)).rejects.toMatchObject({ code: "invalid_arguments" });
    await expect(
      f.run({ ...args(), exercises: [{ exerciseId: uuid(4), sets: [{ weightKg: -1 }] }] }),
    ).rejects.toMatchObject({ code: "invalid_arguments" });
    expect(invoked).toBe(false);
    expect(f.calls.auth).toBe(0);
    expect(f.calls.allocated).toBe(0);
    f.repository.close();
  });

  it("auth and visibility failures reserve nothing and sanitize unknown errors", async () => {
    for (const options of [
      {
        auth: async () => {
          throw new SessionError("authentication_required");
        },
        code: "authentication_required",
      },
      {
        visible: async () => {
          throw error404();
        },
        code: "invalid_reference",
      },
      {
        visible: async () => {
          throw new Error("synthetic private body must not escape");
        },
        code: "internal_error",
      },
    ]) {
      const f = memory(options);
      await expect(f.run()).rejects.toMatchObject({ code: options.code });
      expect(f.calls.commits).toBe(0);
      expect(f.calls.allocated).toBe(0);
      expect(f.bytes().length).toBe(0);
      f.repository.close();
    }
  });

  it("opens normalized equivalent intent without new visibility/allocation; rejects changed intent", async () => {
    let missing = false;
    const f = memory({
      visible: async () => {
        if (missing) throw error404();
      },
    });
    const first = await f.run();
    const bytes = f.bytes();
    const allocated = f.calls.allocated;
    missing = true;
    const equivalent = {
      exercises: [
        {
          sets: [{ repetitions: null, weightKg: null }],
          exerciseId: uuid(4),
          restDurationSeconds: 30,
        },
        { exerciseId: uuid(4), sets: [], restDurationSeconds: 30 },
      ],
      name: "Synthetic routine",
      operationId: uuid(3),
    };
    expect(await f.run(equivalent)).toEqual(first);
    await expect(f.run({ ...args(), name: "Changed" })).rejects.toMatchObject({
      code: "operation_id_reused",
    });
    expect(f.calls.allocated).toBe(allocated);
    expect(f.calls.visible).toHaveLength(1);
    expect(f.bytes()).toEqual(bytes);
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  it("retired lookup precedes changed-intent comparison and visibility", async () => {
    const f = memory();
    const first = await f.run();
    f.seed(
      encodeOperationStore({
        version: 1,
        binding: first.binding,
        operations: [
          {
            version: 1,
            kind: "retired",
            binding: first.binding,
            operationId: first.operationId,
            routineId: first.routineId,
          },
        ],
      }),
    );
    await expect(f.run({ ...args(), name: "Changed" })).rejects.toMatchObject({
      code: "recovery_unavailable",
    });
    expect(f.calls.visible).toHaveLength(1);
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  it("compact rejection retains keyed repeat identity and no request access", async () => {
    const f = memory();
    const first = await f.run();
    const receipt = {
      version: 1,
      kind: "receipt",
      binding: first.binding,
      operationId: first.operationId,
      routineId: first.routineId,
      intent: first.intent,
      maxResponseBytes: first.limits.maxResponseBytes,
      lastConfirmedStep: "none",
      result: {
        ok: false,
        error: {
          code: "invalid_reference",
          retryable: false,
          operationId: first.operationId,
          routineId: first.routineId,
          lastConfirmedStep: "none",
          outcomeUnknown: false,
        },
      },
    };
    f.seed(encodeOperationStore({ version: 1, binding: first.binding, operations: [receipt] }));
    await f.run(args(), async (h) => {
      expect(await h.snapshot()).toEqual(receipt);
      await expect(h.readStep("draft")).rejects.toMatchObject({ code: "recovery_unavailable" });
    });
    await expect(f.run({ ...args(), name: "Corrected" })).rejects.toMatchObject({
      code: "operation_id_reused",
    });
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  it("corrupt or foreign evidence fails closed without replacement", async () => {
    const foreign = {
      origin: binding.origin,
      accountUuid: uuid(7),
      profileGenerationId: binding.profileGenerationId,
    };
    for (const data of [
      Buffer.from('{"version":2}'),
      encodeOperationStore({ version: 1, binding: foreign, operations: [] }),
    ]) {
      const f = memory();
      f.seed(data);
      await expect(f.run()).rejects.toMatchObject({ code: "recovery_unavailable" });
      expect(f.calls.allocated).toBe(0);
      expect(f.calls.commits).toBe(0);
      expect([...f.bytes()]).toEqual([...data]);
      f.repository.close();
    }
  });
});

describe("S2 exclusion, lifetime and capacity", () => {
  it("holds same-ID exclusion through callback; equivalent and conflicting waiters never allocate", async () => {
    const entered = gate(),
      release = gate();
    const f = memory();
    let active = 0;
    const first = f.run(args(), async (h) => {
      active++;
      entered.resolve();
      await release.promise;
      active--;
      return h.snapshot();
    });
    await entered.promise;
    const second = f.run(args(), async (h) => {
      expect(active).toBe(0);
      return h.snapshot();
    });
    const conflict = f.run({ ...args(), name: "Changed" }).catch((e) => e);
    expect(f.calls.auth).toBe(1);
    release.resolve();
    expect(await second).toEqual(await first);
    expect(await conflict).toMatchObject({ code: "operation_id_reused" });
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  it("concurrent different IDs retain both commits and distinct roots", async () => {
    const entered = gate(),
      release = gate();
    let count = 0;
    const f = memory({
      visible: async () => {
        if (++count === 2) entered.resolve();
        await release.promise;
      },
    });
    const one = f.run(args(3)),
      two = f.run(args(5));
    await entered.promise;
    release.resolve();
    const records = await Promise.all([one, two]);
    expect(new Set(records.map((r) => r.routineId)).size).toBe(2);
    expect(decodeOperationStore(f.bytes(), durableBinding).operations).toHaveLength(2);
    expect(f.calls.commits).toBe(2);
    f.repository.close();
  });

  it("rejects duplicate facades and nested callbacks; releases claim after close/drain", async () => {
    const f = memory();
    expect(f.factory).toThrow(expect.objectContaining({ code: "invalid_arguments" }));
    await f.run(args(), async () => {
      await expect(f.run()).rejects.toMatchObject({ code: "invalid_arguments" });
    });
    f.repository.close();
    const fresh = f.factory();
    fresh.close();
    expect(() =>
      openOperationRepository({ owner: f.owner, reads: {}, config: config() }),
    ).toThrow();
  });

  it("fences retained handles, current-generation drift and callback errors release locks", async () => {
    const f = memory();
    let saved;
    await expect(
      f.run(args(), async (h) => {
        saved = h;
        throw new Error("synthetic callback failure");
      }),
    ).rejects.toMatchObject({
      code: "internal_error",
      message: "Operation failure: internal_error.",
    });
    await expect(saved.snapshot()).rejects.toMatchObject({ code: "operation_interrupted" });
    await f
      .run(args(), async (h) => {
        f.owner.binding.sessionGeneration++;
        await expect(h.snapshot()).rejects.toMatchObject({ code: "operation_interrupted" });
      })
      .catch((e) => expect(e.code).toBe("operation_interrupted"));
    await expect(f.run(args(), undefined, signal(), binding)).rejects.toMatchObject({
      code: "operation_interrupted",
    });
    f.repository.close();
  });

  it("queued cancellation is local; aborted precheck allocates nothing", async () => {
    const entered = gate(),
      release = gate();
    const f = memory();
    const first = f.run(args(), async () => {
      entered.resolve();
      await release.promise;
    });
    await entered.promise;
    const abort = new AbortController();
    const waiting = f.run(args(), undefined, abort.signal);
    abort.abort();
    await expect(waiting).rejects.toMatchObject({ code: "operation_interrupted" });
    release.resolve();
    await first;
    expect(f.calls.auth).toBe(1);
    f.repository.close();
    const c = new AbortController();
    const g = memory({ visible: async () => c.abort() });
    await expect(g.run(args(), undefined, c.signal)).rejects.toMatchObject({
      code: "operation_interrupted",
    });
    expect(g.calls.allocated).toBe(0);
    expect(g.calls.commits).toBe(0);
    g.repository.close();
  });

  it("cancellation during begun commit waits for settlement, suppresses work and preserves identity", async () => {
    const started = gate(),
      release = gate(),
      abort = new AbortController();
    let worked = false;
    const f = memory({
      commit: async () => {
        started.resolve();
        await release.promise;
      },
    });
    let settled = false;
    const pending = f
      .run(
        args(),
        async () => {
          worked = true;
        },
        abort.signal,
      )
      .catch((e) => {
        settled = true;
        return e;
      });
    await started.promise;
    abort.abort();
    await Promise.resolve();
    expect(settled).toBe(false);
    release.resolve();
    expect(await pending).toMatchObject({ code: "operation_interrupted" });
    expect(worked).toBe(false);
    const before = f.bytes();
    await f.run();
    expect(f.bytes()).toEqual(before);
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  it("unknown commit errors are ambiguous and cannot be retried via another facade", async () => {
    const f = memory({
      commit: async () => {
        throw new Error("synthetic private path");
      },
    });
    await expect(f.run()).rejects.toBeInstanceOf(StorageError);
    await expect(f.run()).rejects.toMatchObject({ code: "operation_interrupted" });
    expect(f.factory).toThrow(expect.objectContaining({ code: "commit_ambiguous" }));
    expect(f.calls.commits).toBe(1);
    f.repository.close();
  });

  it("close fences held-commit work and retains the owner claim until safe settlement", async () => {
    const started = gate(),
      release = gate();
    const f = memory({
      commit: async () => {
        started.resolve();
        await release.promise;
      },
    });
    let worked = false;
    const pending = f
      .run(args(), async () => {
        worked = true;
      })
      .catch((e) => e);
    await started.promise;
    f.repository.close();
    expect(f.factory).toThrow(expect.objectContaining({ code: "invalid_arguments" }));
    release.resolve();
    expect(await pending).toMatchObject({ code: "operation_interrupted" });
    expect(worked).toBe(false);
    expect(f.calls.commits).toBe(1);
    const reopened = f.factory();
    const original = decodeOperationStore(f.bytes(), durableBinding).operations[0];
    expect(await reopened.withOperation(binding, args(), signal(), (h) => h.snapshot())).toEqual(
      original,
    );
    expect(f.calls.commits).toBe(1);
    reopened.close();
  });

  it("whole-store reservations reject the next admission before consuming earlier headroom", async () => {
    const settings = config();
    settings.transportBudgets = { maxResponseBytes: 16777216 };
    const f = memory({ config: settings });
    for (let i = 0; i < 15; i++) await f.run(args(1000 + i));
    const before = f.bytes();
    const size = measureOperationStore(decodeOperationStore(before, durableBinding));
    expect(size.reservedBytes).toBeLessThan(MAX_STORE_BYTES);
    expect(size.remainingBytes).toBeLessThan(16777216);
    await expect(f.run(args(1015))).rejects.toMatchObject({ code: "resource_exhausted" });
    expect(f.bytes()).toEqual(before);
    expect(f.calls.commits).toBe(15);
    f.repository.close();
  });
});
