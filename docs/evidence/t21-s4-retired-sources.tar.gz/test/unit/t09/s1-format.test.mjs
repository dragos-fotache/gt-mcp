// T09-S1 pure format checks. Oracles come from the S1 work order and shared
// request contract; no admission, storage integrity or dispatch is claimed.
import { describe, expect, it } from "vitest";
import {
  JOURNAL_VERSION,
  OPERATION_STORE_VERSION,
  OperationError,
  isOperationError,
  operationIntentMaterial,
  createOperationCandidate,
  validateOperationRecord,
  encodeOperationStore,
  decodeOperationStore,
  readOperationStep,
  readConfirmationBaseline,
  measureOperationStore,
} from "../../../dist/operations/index.js";

const uuid = (value) => `00000000-0000-4000-8000-${value.toString(16).padStart(12, "0")}`;
const binding = {
  origin: "https://synthetic.example",
  accountUuid: uuid(1),
  profileGenerationId: uuid(2),
};
const limits = { maxRequestBytes: 65536, maxResponseBytes: 65536 };
const digest = Uint8Array.from({ length: 32 }, (_, index) => index);
const clone = (value) => JSON.parse(JSON.stringify(value));
const bytes = (text) => Uint8Array.from(Buffer.from(text, "utf8"));
const text = (value) => Buffer.from(value).toString("utf8");
const base64 = (value) => Buffer.from(value, "utf8").toString("base64");
const byteLength = (value) => Buffer.byteLength(JSON.stringify(value), "utf8");

function input(overrides = {}) {
  return {
    operationId: uuid(3),
    name: "  Synthetic 💪 routine  ",
    exercises: [
      { exerciseId: uuid(4), sets: [{}, { repetitions: 0, weightKg: 0 }] },
      { exerciseId: uuid(4), restDurationSeconds: 0, sets: [] },
    ],
    ...overrides,
  };
}

function candidate(args = input(), overrides = {}, start = 10) {
  let next = start;
  return createOperationCandidate(args, {
    binding,
    limits,
    intentDigest: digest,
    generateUuid: () => uuid(next++),
    ...overrides,
  });
}

function store(operations = []) {
  return { version: 1, binding: clone(binding), operations };
}

function expectError(action, code = "recovery_unavailable") {
  let caught;
  try {
    action();
  } catch (error) {
    caught = error;
  }
  expect(caught).toBeInstanceOf(OperationError);
  expect(isOperationError(caught)).toBe(true);
  expect(caught.code).toBe(code);
  expect(caught.message).toBeTruthy();
  expect(caught.cause).toBeUndefined();
  return caught;
}

// Reservation belongs to original identity, not to later progress. This helper
// is needed only when a test changes the immutable encoding itself.
function reserve(record) {
  const original = clone(record);
  original.reservationBytes = 0;
  original.confirmed = null;
  original.terminal = null;
  for (const step of original.steps) step.state = "unsent";
  record.reservationBytes = byteLength(original) + record.limits.maxResponseBytes + 2048;
  return record;
}

function progress(count, revision = "9223372036854775807") {
  const record = clone(candidate());
  for (let index = 0; index < count; index++) record.steps[index].state = "confirmed";
  record.confirmed = count === 0 ? null : { step: record.steps[count - 1].step, revision };
  return record;
}

function failure(record, outcomeUnknown = false) {
  return {
    ok: false,
    error: {
      code: "backend_error",
      retryable: false,
      operationId: record.operationId,
      routineId: record.routineId,
      lastConfirmedStep: record.confirmed?.step ?? "none",
      outcomeUnknown,
    },
  };
}

describe("T09-S1 immutable candidates and intent", () => {
  it("keeps resource-key distinction separate from the routine UUID family namespace", () => {
    const allocations = [10, 11, 12, 13, 14, 10, 20, 21];
    let index = 0;
    const record = candidate(input(), { generateUuid: () => uuid(allocations[index++]) });
    expect(record.steps[0].resourceKey).toBe(record.routineId);
    expect(new Set(record.steps.map((step) => step.resourceKey)).size).toBe(3);
  });

  it("retains machine error codes without accepting presentation text or identifying hex runs", () => {
    const record = progress(1);
    record.terminal = failure(record);
    record.terminal.error.backendErrorCode = "synthetic_domain_rejection";
    expect(validateOperationRecord(record, binding)).toEqual(record);
    for (const code of [
      "synthetic\n",
      "https://synthetic.example/private",
      "synthetic\nmessage",
      "error_" + "a".repeat(32),
    ]) {
      record.terminal.error.backendErrorCode = code;
      expectError(() => validateOperationRecord(record, binding));
    }
  });

  it("captures read-helper records and byte capabilities without invoking shadow getters", () => {
    let calls = 0;
    const record = candidate();
    Object.defineProperty(record, "binding", {
      enumerable: true,
      get() {
        calls += 1;
        return binding;
      },
    });
    expectError(() => readOperationStep(record, "draft"));
    expectError(() => readConfirmationBaseline(record));
    const wire = encodeOperationStore(store());
    Object.defineProperty(wire, "buffer", {
      get() {
        calls += 1;
        throw new Error("Synthetic shadow getter must not run.");
      },
    });
    expect(decodeOperationStore(wire, binding)).toEqual(store());
    expect(calls).toBe(0);
  });

  it("domain-separates normalized UTF-8 material without including operation identity", () => {
    const expected = {
      name: input().name,
      exercises: [
        {
          exerciseId: uuid(4),
          restDurationSeconds: 30,
          sets: [
            { repetitions: null, weightKg: null },
            { repetitions: 0, weightKg: 0 },
          ],
        },
        { exerciseId: uuid(4), restDurationSeconds: 0, sets: [] },
      ],
    };
    const material = operationIntentMaterial(input());
    expect(text(material)).toBe(`gymtracka-create-intent-v1\0${JSON.stringify(expected)}`);
    const equivalent = input({ operationId: uuid(99) });
    equivalent.exercises[0].restDurationSeconds = 30;
    equivalent.exercises[0].sets[0] = { weightKg: null, repetitions: null };
    equivalent.exercises[0].sets[1] = { weightKg: -0, repetitions: -0 };
    expect(operationIntentMaterial(equivalent)).toEqual(material);
    expect(operationIntentMaterial(input({ name: "different" }))).not.toEqual(material);
    const reordered = input();
    reordered.exercises.reverse();
    expect(operationIntentMaterial(reordered)).not.toEqual(material);
    const changedNull = input();
    changedNull.exercises[0].sets[0].weightKg = 0;
    expect(operationIntentMaterial(changedNull)).not.toEqual(material);
  });

  it("allocates family IDs in input order then three distinct resource keys", () => {
    const record = candidate();
    expect(JOURNAL_VERSION).toBe(1);
    expect(OPERATION_STORE_VERSION).toBe(1);
    expect(record).toMatchObject({
      version: 1,
      kind: "journal",
      binding,
      operationId: uuid(3),
      routineId: uuid(10),
      intent: {
        version: "gymtracka-create-intent-v1",
        digestKeyVersion: "gymtracka-digest-v1",
        digestBase64: Buffer.from(digest).toString("base64"),
      },
      limits,
      confirmed: null,
      terminal: null,
    });
    const expectedPopulate = {
      id: uuid(10),
      name: input().name,
      isDraft: true,
      exercises: [
        {
          id: uuid(11),
          exerciseId: uuid(4),
          position: 0,
          restDurationSeconds: 30,
          sets: [
            { id: uuid(12), position: 0, repetitions: null, weightKg: null },
            { id: uuid(13), position: 1, repetitions: 0, weightKg: 0 },
          ],
        },
        {
          id: uuid(14),
          exerciseId: uuid(4),
          position: 1,
          restDurationSeconds: 0,
          sets: [],
        },
      ],
    };
    const expected = [
      ["draft", "POST", "/v1/routines", uuid(15), { id: uuid(10) }],
      ["populate", "PUT", `/v1/routines/${uuid(10)}`, uuid(16), expectedPopulate],
      ["save", "POST", `/v1/routines/${uuid(10)}/save`, uuid(17), { name: input().name }],
    ];
    for (const [index, [step, method, route, resourceKey, body]] of expected.entries()) {
      expect(record.steps[index]).toMatchObject({
        step,
        method,
        route,
        resourceKey,
        state: "unsent",
      });
      expect(JSON.parse(text(readOperationStep(record, step).body))).toEqual(body);
      expect(record.steps[index].bodyBase64).toBe(
        base64(text(readOperationStep(record, step).body)),
      );
    }
  });

  it("rejects invalid or colliding allocations without repairing their identity", () => {
    for (const generator of [
      () => "not-a-uuid",
      () => uuid(10) + "\n",
      () => uuid(10),
      () => {
        throw new Error("synthetic-private-value");
      },
    ]) {
      const error = expectError(
        () => candidate(input(), { generateUuid: generator }),
        "internal_error",
      );
      expect(`${error.message}\n${error.stack}`).not.toContain("synthetic-private-value");
    }
  });

  it("rejects final-newline UUIDs at resource-key and retained-binding boundaries", () => {
    let next = 10;
    expectError(
      () =>
        candidate(input(), {
          generateUuid: () => {
            const value = uuid(next++);
            return next > 15 ? value + "\n" : value;
          },
        }),
      "internal_error",
    );
    const record = candidate();
    record.steps[2].resourceKey += "\n";
    expectError(() => validateOperationRecord(record, binding));
    const wrong = { ...binding, accountUuid: binding.accountUuid + "\n" };
    expectError(() => decodeOperationStore(encodeOperationStore(store()), wrong));
  });

  it("detaches admitted input, options, digest and returned body bytes", () => {
    const args = input();
    const options = {
      binding: clone(binding),
      limits: clone(limits),
      intentDigest: digest.slice(),
    };
    const record = candidate(args, options);
    args.name = "mutated";
    args.exercises[0].sets[0].repetitions = 99;
    options.binding.accountUuid = uuid(99);
    options.limits.maxResponseBytes = 64;
    options.intentDigest.fill(255);
    const first = readOperationStep(record, "populate");
    const original = first.body.slice();
    first.body.fill(0);
    expect(readOperationStep(record, "populate").body).toEqual(original);
    expect(record.binding).toEqual(binding);
    expect(record.limits).toEqual(limits);
    expect(record.intent.digestBase64).toBe(Buffer.from(digest).toString("base64"));
    expect(JSON.parse(text(original)).name).toBe(input().name);
    const mutableRecord = clone(record);
    const validated = validateOperationRecord(mutableRecord, binding);
    mutableRecord.binding.origin = "https://changed.example";
    mutableRecord.steps[1].bodyBase64 = "changed";
    expect(validated).toEqual(record);
  });

  it("validates strict JSON arguments and budgets before allocating", () => {
    let allocated = 0;
    const generateUuid = () => uuid(allocated++ + 10);
    for (const args of [input({ extra: true }), input({ name: " " })]) {
      expectError(() => candidate(args, { generateUuid }), "invalid_arguments");
    }
    for (const budget of [63, 16777217, 64.5, "65536", null]) {
      expectError(
        () => candidate(input(), { limits: { ...limits, maxRequestBytes: budget }, generateUuid }),
        "invalid_arguments",
      );
    }
    expect(allocated).toBe(0);
    expectError(
      () => candidate(input(), { intentDigest: new Uint8Array(31) }),
      "invalid_arguments",
    );
    expectError(
      () => candidate(input(), { limits: { ...limits, maxRequestBytes: 64 } }),
      "request_too_large",
    );
  });

  it("rejects getters, toJSON, symbols and cycles without executing callbacks", () => {
    let executed = 0;
    const getter = input();
    Object.defineProperty(getter, "name", {
      enumerable: true,
      get() {
        executed++;
        return "x";
      },
    });
    const toJSON = input({
      toJSON() {
        executed++;
        return input();
      },
    });
    const symbolic = input();
    symbolic[Symbol("hidden")] = 1;
    const cycle = input();
    cycle.exercises.push(cycle);
    for (const value of [getter, toJSON, symbolic, cycle])
      expectError(() => operationIntentMaterial(value), "invalid_arguments");
    expect(executed).toBe(0);
  });
});

describe("T09-S1 lossless store decoding", () => {
  it("treats only authenticated initial zero bytes as an empty logical store", () => {
    expect(decodeOperationStore(new Uint8Array(), binding)).toEqual(store());
    expectError(() => decodeOperationStore(bytes(" "), binding));
    const record = candidate();
    const encoded = encodeOperationStore(store([record]));
    expect(decodeOperationStore(encoded, binding)).toEqual(store([record]));
    encoded.fill(0);
    expect(encodeOperationStore(store([record]))).not.toEqual(encoded);
  });

  it("rejects shared and detached byte inputs rather than accepting mutable shared evidence", () => {
    const sharedDigest = new Uint8Array(new globalThis.SharedArrayBuffer(32));
    expectError(() => candidate(input(), { intentDigest: sharedDigest }), "invalid_arguments");
    expectError(() => decodeOperationStore(sharedDigest, binding));
    const detached = new Uint8Array(32);
    globalThis.structuredClone(detached.buffer, { transfer: [detached.buffer] });
    expectError(() => candidate(input(), { intentDigest: detached }), "invalid_arguments");
    expectError(() => decodeOperationStore(detached, binding));
  });

  it("retains alternate valid body whitespace, field order and numeric spelling byte-for-byte", () => {
    const record = clone(candidate());
    record.steps[0].bodyBase64 = base64(` { "id" : "${record.routineId}" }\n`);
    const populate = JSON.parse(text(readOperationStep(candidate(), "populate").body));
    const alternative = JSON.stringify(
      { exercises: populate.exercises, isDraft: true, name: populate.name, id: populate.id },
      null,
      2,
    ).replace('"position": 0', '"position": 0e0');
    record.steps[1].bodyBase64 = base64(alternative);
    reserve(record);
    const reopened = decodeOperationStore(encodeOperationStore(store([record])), binding)
      .operations[0];
    expect(text(readOperationStep(reopened, "draft").body)).toBe(
      ` { "id" : "${record.routineId}" }\n`,
    );
    expect(text(readOperationStep(reopened, "populate").body)).toBe(alternative);
  });

  it("ignores outer JSON key order and whitespace while rejecting duplicate and unsupported fields", () => {
    expect(
      decodeOperationStore(
        bytes(JSON.stringify({ operations: [], binding, version: 1 }, null, 2)),
        binding,
      ),
    ).toEqual(store());
    for (const raw of [
      '{"version":1,"version":1,"binding":{},"operations":[]}',
      JSON.stringify({ ...store(), version: 2 }),
      JSON.stringify({ ...store(), extra: null }),
      JSON.stringify(store()).replace('"accountUuid":', '"accountUuid":"duplicate","accountUuid":'),
      `${JSON.stringify(store())} trailing`,
      `\ufeff${JSON.stringify(store())}`,
    ])
      expectError(() => decodeOperationStore(bytes(raw), binding));
    expectError(() => decodeOperationStore(Uint8Array.from([0xc3, 0x28]), binding));
  });

  it("rejects fractional numeric tokens that round into valid integer budgets", () => {
    const encoded = text(encodeOperationStore(store([candidate()])));
    const rounded = encoded.replace(
      '"maxRequestBytes":65536',
      '"maxRequestBytes":65536.000000000000001',
    );
    expect(rounded).not.toBe(encoded);
    expectError(() => decodeOperationStore(bytes(rounded), binding));
  });

  it("fails closed on foreign durable bindings and duplicate operation or root identities", () => {
    const record = candidate();
    for (const field of ["origin", "accountUuid", "profileGenerationId"]) {
      const foreign = {
        ...binding,
        [field]: field === "origin" ? "https://foreign.example" : uuid(99),
      };
      expectError(() => validateOperationRecord(record, foreign));
      expectError(() => decodeOperationStore(encodeOperationStore(store([record])), foreign));
    }
    const second = clone(candidate(input({ operationId: uuid(90) }), {}, 30));
    expectError(() => encodeOperationStore(store([record, record])));
    second.routineId = record.routineId;
    expectError(() => encodeOperationStore(store([record, second])));
  });

  it("rejects corrupted routes, body whitelist, positions, names, base64 and identities", () => {
    const cases = [
      (record) => {
        record.steps[0].route = "/v1/workouts";
      },
      (record) => {
        record.steps[1].method = "POST";
      },
      (record) => {
        record.steps[0].bodyBase64 = base64(JSON.stringify({ id: uuid(99) }));
      },
      (record) => {
        record.steps[2].bodyBase64 = base64('{"name":"changed"}');
      },
      (record) => {
        record.steps[0].bodyBase64 += "\n";
      },
      (record) => {
        record.steps[2].resourceKey = record.steps[0].resourceKey;
      },
      (record) => {
        record.intent.version = "future-intent";
      },
      (record) => {
        record.intent.digestKeyVersion = "future-digest";
      },
      (record) => {
        record.intent.digestBase64 = base64("short");
      },
      (record) => {
        record.binding.sessionGeneration = 0;
      },
      (record) => {
        record.version = 2;
      },
    ];
    for (const mutate of cases) {
      const record = clone(candidate());
      mutate(record);
      expectError(() => validateOperationRecord(record, binding));
    }
    for (const mutate of [
      (body) => {
        body.exercises[0].notes = "forbidden";
      },
      (body) => {
        body.exercises[0].position = 1;
      },
      (body) => {
        body.exercises[0].sets[0].id = body.id;
      },
      (body) => {
        body.exercises[0].sets[0].repetitions = -1;
      },
    ]) {
      const record = clone(candidate());
      const body = JSON.parse(text(readOperationStep(record, "populate").body));
      mutate(body);
      record.steps[1].bodyBase64 = base64(JSON.stringify(body));
      reserve(record);
      expectError(() => validateOperationRecord(record, binding));
    }
  });
});

describe("T09-S1 persisted progress and minimized records", () => {
  it("accepts a confirmed prefix and one possible dispatch followed by unsent steps", () => {
    for (const count of [0, 1, 2, 3]) {
      const record = progress(count);
      if (count < 3) record.steps[count].state = "dispatch-possible";
      expect(validateOperationRecord(record, binding)).toEqual(record);
    }
  });

  it("rejects progress gaps, multiple unresolved steps and mismatched confirmation markers", () => {
    const cases = [
      (record) => {
        record.steps[1].state = "confirmed";
      },
      (record) => {
        record.steps[0].state = "dispatch-possible";
        record.steps[1].state = "dispatch-possible";
      },
      (record) => {
        record.confirmed = { step: "draft", revision: "1" };
      },
      (record) => {
        record.steps[0].state = "confirmed";
      },
      (record) => {
        record.steps[0].state = "unknown";
      },
    ];
    for (const mutate of cases) {
      const record = clone(candidate());
      mutate(record);
      expectError(() => validateOperationRecord(record, binding));
    }
    const record = progress(2);
    record.confirmed.step = "draft";
    expectError(() => validateOperationRecord(record, binding));
  });

  it("derives exact domain baselines from admitted bytes without retaining additive fields", () => {
    expect(readConfirmationBaseline(candidate())).toBeNull();
    expect(readConfirmationBaseline(progress(1))).toEqual({
      id: uuid(10),
      name: "",
      isDraft: true,
      exercises: [],
      revision: "9223372036854775807",
    });
    for (const count of [2, 3]) {
      const record = progress(count);
      const admitted = JSON.parse(text(readOperationStep(record, "populate").body));
      expect(readConfirmationBaseline(record)).toEqual({
        ...admitted,
        isDraft: count !== 3,
        revision: "9223372036854775807",
      });
    }
  });

  it("requires canonical positive exact Int64 confirmation revisions", () => {
    for (const revision of ["1", "9007199254740993", "9223372036854775807"]) {
      expect(validateOperationRecord(progress(1, revision), binding).confirmed.revision).toBe(
        revision,
      );
    }
    for (const revision of ["0", "01", "1.0", "1e0", "9223372036854775808", 1])
      expectError(() => validateOperationRecord(progress(1, revision), binding));
  });

  it("validates stable success and failure results and returns no terminal baseline", () => {
    const saved = progress(3);
    saved.terminal = {
      ok: true,
      data: { operationId: saved.operationId, routineId: saved.routineId, status: "saved" },
    };
    expect(validateOperationRecord(saved, binding)).toEqual(saved);
    expect(readConfirmationBaseline(saved)).toBeNull();
    const failed = progress(1);
    failed.steps[1].state = "dispatch-possible";
    failed.terminal = failure(failed, true);
    expect(validateOperationRecord(failed, binding)).toEqual(failed);
    expect(readConfirmationBaseline(failed)).toBeNull();
    for (const mutate of [
      (record) => {
        record.steps[2].state = "unsent";
      },
      (record) => {
        record.terminal.data.routineId = uuid(99);
      },
      (record) => {
        record.terminal.data.status = "draft";
      },
    ]) {
      const record = clone(saved);
      mutate(record);
      expectError(() => validateOperationRecord(record, binding));
    }
    for (const extra of [
      { retryable: true },
      { message: "synthetic private message" },
      { lastConfirmedStep: "none" },
      { code: "future_code" },
      { backendBody: "forbidden" },
    ]) {
      const record = clone(failed);
      Object.assign(record.terminal.error, extra);
      expectError(() => validateOperationRecord(record, binding));
    }
  });

  it("permits definitive compact receipts and minimal permanent tombstones only", () => {
    const record = progress(1);
    const receipt = {
      version: 1,
      kind: "receipt",
      binding,
      operationId: record.operationId,
      routineId: record.routineId,
      intent: record.intent,
      maxResponseBytes: limits.maxResponseBytes,
      lastConfirmedStep: "draft",
      result: failure(record),
    };
    const retired = {
      version: 1,
      kind: "retired",
      binding,
      operationId: record.operationId,
      routineId: record.routineId,
    };
    expect(validateOperationRecord(receipt, binding)).toEqual(receipt);
    expect(validateOperationRecord(retired, binding)).toEqual(retired);
    expectError(() => validateOperationRecord({ ...retired, intent: record.intent }, binding));
    expectError(() => validateOperationRecord({ ...receipt, steps: record.steps }, binding));
    expectError(() =>
      validateOperationRecord({ ...receipt, result: failure(record, true) }, binding),
    );
    expectError(() =>
      validateOperationRecord({ ...receipt, lastConfirmedStep: "populate" }, binding),
    );
    expect(decodeOperationStore(encodeOperationStore(store([receipt])), binding)).toEqual(
      store([receipt]),
    );
    const saved = {
      ...receipt,
      lastConfirmedStep: "save",
      result: {
        ok: true,
        data: { operationId: record.operationId, routineId: record.routineId, status: "saved" },
      },
    };
    expect(validateOperationRecord(saved, binding)).toEqual(saved);
    expect(measureOperationStore(store([receipt])).reservedBytes).toBe(
      byteLength(store()) + byteLength(receipt),
    );
    expect(measureOperationStore(store([retired])).reservedBytes).toBe(
      byteLength(store()) + byteLength(retired),
    );
  });
});

describe("T09-S1 bounded capacity and safe errors", () => {
  it("reserves encoded identity plus the retained response budget and finite metadata headroom", () => {
    const record = clone(candidate());
    const original = clone(record);
    original.reservationBytes = 0;
    expect(record.reservationBytes).toBe(byteLength(original) + limits.maxResponseBytes + 2048);
    const measured = measureOperationStore(store([record]));
    const empty = byteLength(store());
    expect(measured).toEqual({
      encodedBytes: byteLength(store([record])),
      reservedBytes: empty + record.reservationBytes,
      remainingBytes: 268435456 - empty - record.reservationBytes,
    });
    const two = candidate(input({ operationId: uuid(90) }), {}, 30);
    expect(measureOperationStore(store([record, two])).reservedBytes).toBe(
      empty + record.reservationBytes + two.reservationBytes + 1,
    );
    expectError(() =>
      validateOperationRecord(
        { ...record, reservationBytes: record.reservationBytes - 1 },
        binding,
      ),
    );
  });

  it("keeps growth of confirmed and bounded terminal state inside the original reservation", () => {
    const initial = candidate(input(), { limits: { ...limits, maxResponseBytes: 64 } });
    const record = clone(initial);
    record.steps.forEach((step) => {
      step.state = "confirmed";
    });
    record.confirmed = { step: "save", revision: "9223372036854775807" };
    record.terminal = {
      ok: true,
      data: { operationId: record.operationId, routineId: record.routineId, status: "saved" },
    };
    expect(validateOperationRecord(record, binding)).toEqual(record);
    expect(byteLength(record)).toBeLessThanOrEqual(initial.reservationBytes);
    expect(measureOperationStore(store([record])).reservedBytes).toBe(
      measureOperationStore(store([initial])).reservedBytes,
    );
  });

  it("exhausts the whole-store reservation before allocating response padding", () => {
    const records = Array.from({ length: 17 }, (_, index) =>
      candidate(
        input({ operationId: uuid(1000 + index) }),
        { limits: { ...limits, maxResponseBytes: 16777216 } },
        100 + index * 20,
      ),
    );
    expect(measureOperationStore(store(records.slice(0, 15))).remainingBytes).toBeGreaterThan(0);
    expectError(() => measureOperationStore(store(records)), "resource_exhausted");
    expectError(() => encodeOperationStore(store(records)), "resource_exhausted");
  });

  it("exposes safe local errors without accepting arbitrary lookalike objects", () => {
    const error = new OperationError("internal_error");
    expect(isOperationError(error)).toBe(true);
    expect(isOperationError({ code: "internal_error", message: error.message })).toBe(false);
    expect(isOperationError(null)).toBe(false);
    expect(error.cause).toBeUndefined();
    expect(typeof error.stack).toBe("string");
  });
});
