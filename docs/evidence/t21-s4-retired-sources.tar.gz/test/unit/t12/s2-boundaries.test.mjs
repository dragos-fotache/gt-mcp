/* global AbortController */
import { describe, it, expect } from "vitest";
import { main } from "../../../dist/cli/main.js";
import { removeLoginProfile, reconcileLoginProfile } from "../../../dist/lifecycle/index.js";
import {
  resumeProfileRemoval,
  provisionReconciledProfile,
} from "../../../dist/storage/lifecycle.js";
import { parseRemovalFence } from "../../../dist/storage/removal.js";
import { uuid } from "../../unit/t09/s2-helpers.mjs";

const config = ["--config", "/synthetic/missing"];
describe("T12-S2 closed destructive CLI grammar", () => {
  it.each(
    [
      ["profile-remove", ...config],
      ["profile-remove", ...config, "--confirm", "--confirm"],
      ["profile-remove", ...config, "--confirm", "--operation-id", uuid(1)],
      ["profile-remove", ...config, "--confirm", "--reconcile"],
      ["setup", ...config, "--reconcile"],
      ["setup", ...config, "--confirm"],
      ["setup", ...config, "--reconcile", "--confirm", "--reconcile"],
      ["recover", ...config, "--confirm"],
    ].map((args) => ({ args })),
  )("rejects missing/extraneous/duplicate intent before IO: $args", async ({ args }) => {
    const before = ["SIGINT", "SIGTERM"].map((s) => process.listenerCount(s));
    let text = "";
    expect(
      await main(
        args,
        {
          stderr: (value) => {
            text += value;
          },
        },
        () => {
          throw new Error("Unexpected browser");
        },
      ),
    ).toBe(2);
    expect(text).toMatch(/^Usage:/);
    expect(text).not.toContain("/synthetic/missing");
    expect(["SIGINT", "SIGTERM"].map((s) => process.listenerCount(s))).toEqual(before);
  });

  it("validates/captures trusted factory inputs and cancellation before storage IO", async () => {
    const cancelled = new AbortController();
    cancelled.abort();
    for (const action of [removeLoginProfile, reconcileLoginProfile]) {
      await expect(
        action({ configPath: "/synthetic/missing" }, cancelled.signal),
      ).rejects.toMatchObject({ code: "operation_interrupted" });
      await expect(
        action({ configPath: "/synthetic/missing", confirm: true }, cancelled.signal),
      ).rejects.toMatchObject({ code: "invalid_arguments" });
    }
    await expect(resumeProfileRemoval({ profileRoot: "relative" })).rejects.toMatchObject({
      code: "invalid_argument",
    });
    await expect(provisionReconciledProfile({ token: "synthetic-private" })).rejects.toMatchObject({
      code: "invalid_argument",
    });
  });
});

describe("T12-S2 external removal metadata safety", () => {
  it("requires exact minimized completed shape; rejects malformed, unknown-version and account-bearing completion", () => {
    const complete = {
      version: 1,
      phase: "complete",
      profileGenerationId: uuid(1),
      profile: { path: "/synthetic/profile", dev: "1", ino: "2" },
      anchor: { path: "/synthetic/anchor", dev: "1", ino: "3" },
      lock: { dev: "1", ino: "4" },
      euid: 1000,
    };
    const bytes = (r) => Buffer.from(JSON.stringify(r));
    expect(parseRemovalFence(bytes(complete))).toEqual(complete);
    for (const bad of [
      { ...complete, version: 2 },
      { ...complete, phase: "unknown" },
      { ...complete, binding: { accountUuid: uuid(3) } },
      { ...complete, keyDigest: "0".repeat(64) },
      { ...complete, lock: { ...complete.lock, ino: "-1" } },
      { ...complete, euid: -1 },
      { ...complete, phase: "pending" },
    ])
      expect(() => parseRemovalFence(bytes(bad))).toThrow(/Storage failure: fence_mismatch/);
    expect(() => parseRemovalFence(Buffer.from('{"version":1,"version":1}'))).toThrow(
      /fence_mismatch/,
    );
  });
});
