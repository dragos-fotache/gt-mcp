// Integrated trusted lifecycle over actual isolated provider/HTTPS, compiled CLI and SDK.
import fs from "node:fs";
import { describe, it, expect } from "vitest";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { main } from "../../../dist/cli/main.js";
import { fixture, signIn } from "../../login/configured-helpers.mjs";
import { runCli, expectSafe, browserSettings, startCli } from "../../login/cli-helpers.mjs";
import { ajvValidator, expectError } from "../../read-protocol/helpers.mjs";
import { CREATE_ARGS } from "../../read-protocol/fixtures.mjs";
import { SERVER } from "../../stdio-server/helpers.mjs";
import { lifecycleFixture, inspect, withRepository, args, signal, uuid } from "./s1-helpers.mjs";
import { statusFixture, state, descriptor, deleted, json, submit } from "./s3-helpers.mjs";
import { fencePath } from "./s2-helpers.mjs";
import { assertPortReleased } from "../../login/browser-helpers.mjs";

async function completed(f, command) {
  const result = await runCli(command);
  expectSafe(result, f);
  expect(result.code).toBe(0);
  return result;
}

describe("T12-S4 integrated operator flow", () => {
  it("failed setup/login disclosure leaves new private deployment untouched", async () => {
    const f = await fixture();
    try {
      for (const name of ["setup", "login"]) {
        const command = [name, "--config", f.configPath];
        if (name === "login") command.push("--login-config", f.loginConfigPath);
        expect(
          await main(command, {
            stderr() {
              throw new Error("synthetic sink failure");
            },
          }),
        ).toBe(4);
        expect(fs.existsSync(f.descriptorPath)).toBe(false);
        expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
        expect(fs.readdirSync(f.storage.profileRoot)).toEqual([]);
        expect(fs.readdirSync(f.storage.anchorRoot)).toEqual([]);
        expect(f.requests).toHaveLength(0);
      }
    } finally {
      await f.close();
    }
  });

  it("server handoff retains same-account identity, then retirement and reconciled removal end recovery", async () => {
    const f = await lifecycleFixture();
    let client, transport, exited;
    const stop = async () => {
      if (!transport) return;
      if (transport.pid !== null) process.kill(transport.pid, "SIGTERM");
      await exited;
      await client.close();
      transport = undefined;
    };
    try {
      transport = new StdioClientTransport({
        command: process.execPath,
        args: [SERVER, "--config", f.configPath],
        env: process.env,
        stderr: "pipe",
      });
      let stderr = "";
      transport.stderr.on("data", (c) => {
        stderr += c.toString();
      });
      exited = new Promise((resolve) => {
        transport.onclose = resolve;
      });
      client = new Client(
        { name: "synthetic-t12-s4", version: "0" },
        { jsonSchemaValidator: ajvValidator() },
      );
      const beforeStartup = f.requests.length;
      await client.connect(transport);
      expect((await client.listTools()).tools.map((t) => t.name)).toHaveLength(7);
      expectError(
        await client.callTool({ name: "create_routine", arguments: CREATE_ARGS }),
        "configuration_required",
        false,
        { message: "Routine creation is disabled in the operator configuration." },
      );
      expect(f.requests).toHaveLength(beforeStartup);
      const blocked = await runCli(["sign-out", "--config", f.configPath]);
      expectSafe(blocked, f);
      expect(blocked.code).toBe(3);
      await stop();
      expect(stderr).toBe("");
      expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
      await completed(f, ["sign-out", "--config", f.configPath]);
      expect((await inspect(f, descriptor(f))).operationBytes).toEqual(f.operationBytes);
      const next = await signIn(f);
      await withRepository(f, next, async (repository) => {
        expect(await repository.withOperation(next, args(), signal(), (h) => h.snapshot())).toEqual(
          f.candidate,
        );
      });
      const retire = [
        "retire-operation",
        "--config",
        f.configPath,
        "--operation-id",
        args().operationId,
        "--confirm",
      ];
      await completed(f, retire);
      await completed(f, ["sign-out", "--config", f.configPath]);
      const reauthenticated = await signIn(f);
      await withRepository(f, reauthenticated, async (repository) => {
        for (const input of [args(), { ...args(), name: "Different synthetic intent" }]) {
          await expect(
            repository.withOperation(reauthenticated, input, signal(), (h) => h.snapshot()),
          ).rejects.toMatchObject({ code: "recovery_unavailable" });
        }
      });
      await completed(f, ["profile-remove", "--config", f.configPath, "--confirm"]);
      const fence = fs.readFileSync(fencePath(f));
      expect((await runCli(["setup", "--config", f.configPath])).code).toBe(3);
      await completed(f, ["setup", "--config", f.configPath, "--reconcile", "--confirm"]);
      const fresh = await signIn(f);
      expect(fresh.profileGenerationId).not.toBe(f.binding.profileGenerationId);
      const owner = await f.open(fresh);
      try {
        expect((await owner.readOperationStoreBytes()).byteLength).toBe(0);
      } finally {
        await owner.close();
      }
      expect(fs.readFileSync(fencePath(f))).toEqual(fence);
      expect(JSON.parse(fs.readFileSync(f.configPath)).writesEnabled).toBe(false);
      expect(
        f.requests.some((r) => /^\/v1\/routines(?:\/|$)/.test(r.route) && !r.route.includes("?")),
      ).toBe(false);
    } finally {
      await stop();
      await f.close();
    }
  }, 30000);

  it("signed-out verified A deletion leaves separate B and its recovery evidence unchanged", async () => {
    const a = await statusFixture();
    const b = await lifecycleFixture({ accountUuid: uuid(900) });
    let running;
    try {
      const beforeB = await inspect(b);
      await completed(a, ["sign-out", "--config", a.configPath]);
      const beforeA = await state(a);
      expect(beforeA.operations).toEqual(a.operationBytes);
      await browserSettings(a);
      a.setStatus((_req, res) => json(res, deleted(a.binding.accountUuid)));
      running = startCli(
        ["account-status", "--config", a.configPath, "--login-config", a.loginConfigPath],
        { launcherMode: "ok" },
      );
      const url = new URL(await running.ready);
      const h = { port: Number(url.port), settings: { browserOrigin: url.origin } };
      expect((await submit(h)).response.status).toBe(200);
      const result = await running.exited;
      expectSafe(result, a);
      expect(result.code).toBe(0);
      expect(result.stderr).toContain("Account deletion verified");
      expect(fs.readdirSync(a.storage.profileRoot)).toEqual([]);
      expect(JSON.parse(fs.readFileSync(fencePath(a))).phase).toBe("complete");
      await assertPortReleased(h.port);
      expect(await inspect(b)).toEqual(beforeB);
      expect(JSON.parse(fs.readFileSync(a.configPath)).writesEnabled).toBe(false);
      expect(a.requests.some((r) => r.route === "/v1/account/delete")).toBe(false);
    } finally {
      await running?.close();
      await a.close();
      await b.close();
    }
  }, 30000);
});
