/* global AbortController */
// Shared-contract oracles over actual isolated provider/ext4 and compiled CLI.
import fs from "node:fs";
import { randomUUID } from "node:crypto";
import { describe, it, expect } from "vitest";
import { main } from "../../../dist/cli/main.js";
import { removeLoginProfile, reconcileLoginProfile } from "../../../dist/lifecycle/index.js";
import { recoverLoginProfile, setupLoginProfile } from "../../../dist/login/index.js";
import { openLoginMetadata } from "../../../dist/login/metadata.js";
import { openProfile, provisionProfile } from "../../../dist/storage/index.js";
import { resumeProfileRemoval } from "../../../dist/storage/lifecycle.js";
import { assertBusAddress } from "../../../dist/storage/validate.js";
import { SecretMasterKey } from "../../../dist/storage/keyring.js";
import { fixture, signal, parse } from "../../login/configured-helpers.mjs";
import { lifecycleFixture, inspect } from "./s1-helpers.mjs";
import { runCli, expectSafe } from "../../login/cli-helpers.mjs";

const command = (f) => ["profile-remove", "--config", f.configPath, "--confirm"];
const reconcile = (f) => ["setup", "--config", f.configPath, "--reconcile", "--confirm"];
const descriptor = (f) => parse(fs.readFileSync(f.descriptorPath)).binding;
const fencePath = (f, binding = f.binding) =>
  `${f.storage.anchorRoot}/removed.${binding.profileGenerationId}.json`;
const keyAccess = (f, binding = f.binding) =>
  new SecretMasterKey(
    assertBusAddress(f.storage.secretServiceBusAddress).socketPath,
    binding.profileGenerationId,
  );
const target = (binding) => ({ ...binding, accountUuid: null, sessionGeneration: 0 });

describe("T12-S2 trusted profile removal and reconciliation", () => {
  it("compiled removal erases private material/key without HTTP; ordinary setup refuses and explicit reconciliation provisions distinct empty evidence", async () => {
    const f = await lifecycleFixture();
    const separate = await lifecycleFixture();
    try {
      const before = f.requests.length;
      const abandoned = `${f.dir}/.binding.json.${randomUUID()}.tmp`;
      fs.writeFileSync(abandoned, JSON.stringify({ version: 1, binding: f.binding }), {
        mode: 0o600,
      });
      const result = await runCli(command(f));
      expect(fs.existsSync(abandoned)).toBe(false);
      expect(result.code).toBe(0);
      expectSafe(result, f);
      expect(result.stderr).toMatch(/permanently ends replay guarantees/);
      expect(result.stderr).toMatch(/backend data is not deleted/);
      expect(f.requests).toHaveLength(before);
      expect(fs.readdirSync(f.storage.profileRoot)).toEqual([]);
      expect(fs.readdirSync(f.storage.anchorRoot).sort()).toEqual(
        ["owner.lock", `removed.${f.binding.profileGenerationId}.json`].sort(),
      );
      const fence = parse(fs.readFileSync(fencePath(f)));
      expect(fence.phase).toBe("complete");
      expect(fence).not.toHaveProperty("binding");
      expect(fence).not.toHaveProperty("keyDigest");
      expect(fence).not.toHaveProperty("files");
      expect(JSON.stringify(fence)).not.toContain(f.binding.accountUuid);
      expect(fs.statSync(fencePath(f)).mode & 0o777).toBe(0o600);
      expect(descriptor(f)).toEqual(target(f.binding));
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      await expect(keyAccess(f).loadMaster(Date.now() + 5000)).rejects.toMatchObject({
        code: "key_not_found",
      });
      await expect(
        openProfile({
          ...f.storage,
          secretServiceBusAddress: `unix:path=${f.dir}/absent`,
          expectedBinding: f.binding,
        }),
      ).rejects.toMatchObject({ code: "fence_mismatch" });
      expect((await runCli(["setup", "--config", f.configPath])).code).toBe(3);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      for (const generation of [f.binding.profileGenerationId, randomUUID()])
        await expect(
          provisionProfile({ ...f.storage, origin: f.origin, profileGenerationId: generation }),
        ).rejects.toMatchObject({ code: "fence_mismatch" });
      expect((await inspect(separate)).operationBytes).toEqual(separate.operationBytes);
      const held = await resumeProfileRemoval({ ...f.storage, expectedBinding: target(f.binding) });
      try {
        expect((await runCli(reconcile(f))).code).toBe(3);
        expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      } finally {
        await held.close();
      }
      expect(
        await main(reconcile(f), {
          stderr: (text) => {
            if (text.startsWith("Reconciled setup")) throw new Error("synthetic sink failure");
          },
        }),
      ).toBe(4);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      const replacement = await runCli(reconcile(f));
      expect(replacement.code).toBe(0);
      expectSafe(replacement, f);
      expect(replacement.stderr).toMatch(/reconciled possible remote creations/);
      const next = descriptor(f);
      expect(next.profileGenerationId).not.toBe(f.binding.profileGenerationId);
      expect(next.accountUuid).toBeNull();
      expect(next.sessionGeneration).toBe(0);
      const owner = await f.open(next);
      try {
        expect((await owner.readVaultBytes()).byteLength).toBe(0);
        expect((await owner.readOperationStoreBytes()).byteLength).toBe(0);
      } finally {
        await owner.close();
      }
      expect(parse(fs.readFileSync(fencePath(f)))).toEqual(fence);
      await expect(f.open(f.binding)).rejects.toMatchObject({ code: "fence_mismatch" });
      await expect(
        resumeProfileRemoval({ ...f.storage, expectedBinding: f.binding }),
      ).rejects.toMatchObject({ code: "fence_mismatch" });
      expect(f.requests).toHaveLength(before);
      expect((await inspect(separate)).operationBytes).toEqual(separate.operationBytes);
    } finally {
      await f.close();
      await separate.close();
    }
  }, 30000);

  it("local removal requires no account binding or usable backend session", async () => {
    const f = await fixture();
    try {
      const source = await setupLoginProfile({ configPath: f.configPath });
      expect((await runCli(command(f))).code).toBe(0);
      expect(descriptor(f)).toEqual(source);
      expect(f.requests).toHaveLength(0);
      expect((await runCli(command(f))).code).toBe(0);
      expect(parse(fs.readFileSync(fencePath(f, source))).phase).toBe("complete");
    } finally {
      await f.close();
    }
  });

  it("warning failure or cancellation before intent leaves private evidence and no removal receipt", async () => {
    const f = await lifecycleFixture();
    try {
      expect(
        await main(command(f), {
          stderr: () => {
            throw new Error("synthetic sink failure");
          },
        }),
      ).toBe(4);
      let warned = false;
      expect(
        await main(command(f), {
          stderr: (text) => {
            if (text.startsWith("Profile removal")) {
              warned = true;
              process.emit("SIGINT");
            }
          },
        }),
      ).toBe(130);
      expect(warned).toBe(true);
      expect(fs.existsSync(fencePath(f))).toBe(false);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
      const controller = new AbortController();
      controller.abort();
      await expect(
        removeLoginProfile({ configPath: f.configPath }, controller.signal),
      ).rejects.toMatchObject({ code: "operation_interrupted" });
    } finally {
      await f.close();
    }
  });

  it("signals after removal/reconciliation preparation settle durable work and release ownership", async () => {
    const f = await lifecycleFixture();
    try {
      for (const args of [command(f), reconcile(f)]) {
        let interrupted = false;
        const watcher = fs.watch(f.dir, (_event, name) => {
          if (!interrupted && name === "binding.json.pending") {
            interrupted = true;
            process.emit("SIGTERM");
          }
        });
        try {
          expect(await main(args, { stderr: () => {} })).toBe(130);
          expect(interrupted).toBe(true);
        } finally {
          watcher.close();
        }
        expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      }
      const next = descriptor(f);
      expect(next.profileGenerationId).not.toBe(f.binding.profileGenerationId);
      const owner = await f.open(next);
      try {
        expect((await owner.readOperationStoreBytes()).byteLength).toBe(0);
      } finally {
        await owner.close();
      }
    } finally {
      await f.close();
    }
  });

  it("a running actual owner excludes removal and unremoved profiles cannot be reconciled", async () => {
    const f = await lifecycleFixture();
    try {
      const owner = await f.open(f.binding);
      try {
        const result = await runCli(command(f));
        expect(result.code).toBe(3);
        expectSafe(result, f);
        expect(Buffer.from(await owner.readOperationStoreBytes())).toEqual(f.operationBytes);
      } finally {
        await owner.close();
      }
      expect(fs.existsSync(fencePath(f))).toBe(false);
      await expect(
        reconcileLoginProfile({ configPath: f.configPath }, signal()),
      ).rejects.toMatchObject({ code: "recovery_required" });
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
    } finally {
      await f.close();
    }
  });

  it.each(["source", "removed", "published"])(
    "explicit metadata recovery recognizes %s without HTTP or inventing removal intent",
    async (stage) => {
      const f = await lifecycleFixture();
      try {
        const metadata = await openLoginMetadata(f.configPath);
        const to = target(f.binding);
        const receipt = {
          version: 1,
          kind: "remove",
          transitionId: randomUUID(),
          from: f.binding,
          to,
        };
        const owner = await f.open(f.binding);
        try {
          await metadata.prepareReceipt(receipt);
          if (stage !== "source") {
            await owner.removeProfile();
            await expect(owner.readVaultBytes()).rejects.toMatchObject({
              code: "generation_mismatch",
            });
            if (stage === "published") await metadata.publishDescriptor(f.binding, to);
          }
        } finally {
          await owner.close();
        }
        const before = f.requests.length;
        expect((await runCli(["recover", "--config", f.configPath])).code).toBe(0);
        expect(descriptor(f)).toEqual(stage === "source" ? f.binding : to);
        expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
        expect(f.requests).toHaveLength(before);
        if (stage === "source") expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
        else
          await expect(keyAccess(f).loadMaster(Date.now() + 5000)).rejects.toMatchObject({
            code: "key_not_found",
          });
      } finally {
        await f.close();
      }
    },
  );

  it("a removal metadata receipt never turns unfenced corrupt storage into erasure permission", async () => {
    const f = await lifecycleFixture();
    try {
      const metadata = await openLoginMetadata(f.configPath);
      await metadata.prepareReceipt({
        version: 1,
        kind: "remove",
        transitionId: randomUUID(),
        from: f.binding,
        to: target(f.binding),
      });
      fs.unlinkSync(`${f.storage.profileRoot}/operations.bin`);
      await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
        code: "recovery_required",
      });
      expect(fs.existsSync(fencePath(f))).toBe(false);
      expect(fs.existsSync(`${f.storage.profileRoot}/vault.bin`)).toBe(true);
      const key = await keyAccess(f).loadMaster(Date.now() + 5000);
      key.fill(0);
    } finally {
      await f.close();
    }
  });
});
