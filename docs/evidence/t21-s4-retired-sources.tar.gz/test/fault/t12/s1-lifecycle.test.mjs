/* global AbortController */
// Actual isolated Secret Service/ext4/private-CA HTTPS and compiled trusted CLI.
import fs from "node:fs";
import { randomUUID } from "node:crypto";
import { describe, it, expect } from "vitest";
import { main } from "../../../dist/cli/main.js";
import { signOutProfile, retireProfileOperation } from "../../../dist/lifecycle/index.js";
import { recoverLoginProfile, setupLoginProfile } from "../../../dist/login/index.js";
import { openLoginMetadata } from "../../../dist/login/metadata.js";
import { encodeOperationStore } from "../../../dist/operations/index.js";
import { signIn, fixture as configuredFixture } from "../../login/configured-helpers.mjs";
import { runCli, expectSafe } from "../../login/cli-helpers.mjs";
import { deferred } from "../../login/browser-helpers.mjs";
import {
  lifecycleFixture,
  inspect,
  withRepository,
  signal,
  bytes,
  parse,
  args,
  uuid,
} from "./s1-helpers.mjs";

const retirement = (f, id = args().operationId) => [
  "retire-operation",
  "--config",
  f.configPath,
  "--operation-id",
  id,
  "--confirm",
];
const descriptor = (f) => parse(fs.readFileSync(f.descriptorPath)).binding;
const mutations = (f) =>
  f.requests.filter((r) => /^\/v1\/routines(?:\/|$)/.test(r.route) && !r.route.includes("?"));

describe("T12-S1 configured sign-out and private recovery", () => {
  it("pre-auth setup stays unchanged when lifecycle controls require an account", async () => {
    const f = await configuredFixture();
    try {
      const initial = await setupLoginProfile({ configPath: f.configPath });
      for (const command of [["sign-out", "--config", f.configPath], retirement(f)]) {
        const result = await runCli(command);
        expect(result.code).toBe(4);
        expectSafe(result, f);
      }
      expect(descriptor(f)).toEqual(initial);
      expect(f.requests).toHaveLength(0);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      const owner = await f.open(initial);
      try {
        expect((await owner.readVaultBytes()).byteLength).toBe(0);
      } finally {
        await owner.close();
      }
    } finally {
      await f.close();
    }
  });
  it("compiled sign-out clears credentials despite failed logout, preserves exact identity, and permits only same-account explicit reauthentication", async () => {
    const f = await lifecycleFixture();
    try {
      // Existing fixture returns200 for logout: a deliberately invalid cleanup
      // reply must not undo acknowledged local credential clearing.
      const result = await runCli(["sign-out", "--config", f.configPath]);
      expectSafe(result, f);
      expect(result.code).toBe(0);
      expect(result.stderr).toContain("Sign-out complete");
      const target = { ...f.binding, sessionGeneration: f.binding.sessionGeneration + 1 };
      expect(descriptor(f)).toEqual(target);
      const state = await inspect(f, target);
      expect(state.vault).toEqual({
        version: 3,
        binding: target,
        grant: null,
        pendingRefresh: null,
        superseded: [],
      });
      expect(state.operationBytes).toEqual(f.operationBytes);
      expect(state.digest).toEqual(f.digest);
      expect(f.requests.filter((r) => r.route === "/v1/auth/logout")).toHaveLength(1);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
      await expect(f.open(f.binding)).rejects.toMatchObject({ code: "generation_mismatch" });

      const before = f.requests.length;
      const refused = await runCli(retirement(f));
      expect(refused.code).toBe(4);
      expectSafe(refused, f);
      expect(f.requests).toHaveLength(before);
      expect((await inspect(f, target)).operationBytes).toEqual(f.operationBytes);

      const next = await signIn(f);
      expect(next).toEqual({ ...target, sessionGeneration: target.sessionGeneration + 1 });
      expect((await inspect(f, next)).operationBytes).toEqual(f.operationBytes);
      await withRepository(f, next, async (repository) => {
        const retained = await repository.withOperation(next, args(), signal(), (h) =>
          h.snapshot(),
        );
        expect(retained).toEqual(f.candidate);
      });
      f.grant.account.id = uuid(999);
      await expect(signIn(f)).rejects.toMatchObject({ code: "sign_in_failed" });
      expect(descriptor(f)).toEqual(next);
      expect((await inspect(f, next)).operationBytes).toEqual(f.operationBytes);
      expect(mutations(f)).toHaveLength(0);
      expect(parse(fs.readFileSync(f.configPath)).writesEnabled).toBe(false);
    } finally {
      await f.close();
    }
  });

  it("SIGTERM after durable clearing settles publication and releases the actual owner", async () => {
    const f = await lifecycleFixture();
    const entered = deferred(),
      release = deferred();
    let work;
    try {
      f.setLogout((_req, res) => {
        entered.resolve();
        void release.promise.then(() => {
          res.writeHead(204);
          res.end();
        });
      });
      let output = "";
      work = main(["sign-out", "--config", f.configPath], {
        stderr: (text) => {
          output += text;
        },
      });
      await entered.promise;
      process.emit("SIGTERM");
      release.resolve();
      expect(await work).toBe(130);
      expect(output).toMatch(/interrupted/);
      expect(output).not.toContain(f.dir);
      const target = descriptor(f);
      expect(target.sessionGeneration).toBe(f.binding.sessionGeneration + 1);
      const state = await inspect(f, target);
      expect(state.vault.grant).toBeNull();
      expect(state.operationBytes).toEqual(f.operationBytes);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
    } finally {
      release.resolve();
      if (work) await work;
      await f.close();
    }
  });

  it.each(["source", "target", "published"])(
    "explicit local recovery reconciles %s without login or backend traffic",
    async (stage) => {
      const f = await lifecycleFixture();
      const target = { ...f.binding, sessionGeneration: f.binding.sessionGeneration + 1 };
      try {
        const metadata = await openLoginMetadata(f.configPath);
        const receipt = {
          version: 1,
          kind: "sign-out",
          transitionId: randomUUID(),
          from: f.binding,
          to: target,
        };
        const owner = await f.open(f.binding);
        try {
          await metadata.prepareReceipt(receipt);
          if (stage !== "source") {
            await owner.advanceSessionGeneration(
              bytes({
                version: 3,
                binding: target,
                grant: null,
                pendingRefresh: null,
                superseded: [],
              }),
            );
            if (stage === "published") await metadata.publishDescriptor(f.binding, target);
          }
        } finally {
          await owner.close();
        }
        const before = f.requests.length;
        await expect(signOutProfile({ configPath: f.configPath }, signal())).rejects.toMatchObject({
          code: "recovery_required",
        });
        const expected = stage === "source" ? f.binding : target;
        const result = await runCli(["recover", "--config", f.configPath]);
        expect(result.code).toBe(0);
        expectSafe(result, f);
        expect(descriptor(f)).toEqual(expected);
        expect(f.requests).toHaveLength(before);
        expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
        const state = await inspect(f, expected);
        expect(state.operationBytes).toEqual(f.operationBytes);
        expect(state.vault.grant === null).toBe(stage !== "source");
      } finally {
        await f.close();
      }
    },
  );

  it("does not publish a sign-out target that still contains credentials", async () => {
    const f = await lifecycleFixture();
    try {
      const metadata = await openLoginMetadata(f.configPath);
      const owner = await f.open(f.binding);
      const target = { ...f.binding, sessionGeneration: f.binding.sessionGeneration + 1 };
      try {
        const vault = parse(await owner.readVaultBytes());
        await metadata.prepareReceipt({
          version: 1,
          kind: "sign-out",
          transitionId: randomUUID(),
          from: f.binding,
          to: target,
        });
        await owner.advanceSessionGeneration(bytes({ ...vault, binding: target }));
      } finally {
        await owner.close();
      }
      await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
        code: "recovery_required",
      });
      expect(descriptor(f)).toEqual(f.binding);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(true);
      expect((await inspect(f, target)).operationBytes).toEqual(f.operationBytes);
    } finally {
      await f.close();
    }
  });

  it("running profile ownership blocks both separate CLI controls without mutation", async () => {
    const f = await lifecycleFixture();
    try {
      const owner = await f.open(f.binding);
      try {
        const before = f.requests.length;
        for (const command of [["sign-out", "--config", f.configPath], retirement(f)]) {
          const result = await runCli(command);
          expect(result.code).toBe(3);
          expectSafe(result, f);
        }
        expect(f.requests).toHaveLength(before);
        expect(Buffer.from(await owner.readOperationStoreBytes())).toEqual(f.operationBytes);
      } finally {
        await owner.close();
      }
      expect(descriptor(f)).toEqual(f.binding);
    } finally {
      await f.close();
    }
  });
});

describe("T12-S1 trusted unresolved-operation retirement", () => {
  it("warns and permanently retires through the compiled CLI with creation disabled", async () => {
    const f = await lifecycleFixture();
    try {
      const result = await runCli(retirement(f));
      expect(result.code).toBe(0);
      expectSafe(result, f);
      expect(result.stderr).toMatch(/remote draft or saved routine/i);
      expect(result.stderr).toMatch(/does not roll back or delete backend data/i);
      expect(result.stderr).not.toContain(args().operationId);
      const expected = {
        version: 1,
        kind: "retired",
        binding: f.candidate.binding,
        operationId: f.candidate.operationId,
        routineId: f.candidate.routineId,
      };
      expect((await inspect(f)).records).toEqual([expected]);
      expect((await runCli(retirement(f))).code).toBe(0);
      await withRepository(f, f.binding, async (repository) => {
        for (const input of [args(), { ...args(), name: "Different synthetic intent" }])
          await expect(
            repository.withOperation(f.binding, input, signal(), (h) => h.snapshot()),
          ).rejects.toMatchObject({ code: "recovery_unavailable" });
      });
      expect((await inspect(f)).records).toEqual([expected]);
      expect(parse(fs.readFileSync(f.configPath)).writesEnabled).toBe(false);
      expect(mutations(f)).toHaveLength(0);
    } finally {
      await f.close();
    }
  });

  it("warning-output failure and cancellation before admission preserve private evidence", async () => {
    const f = await lifecycleFixture();
    try {
      const before = f.requests.length;
      expect(
        await main(retirement(f), {
          stderr: () => {
            throw new Error("synthetic-sink-failure");
          },
        }),
      ).toBe(4);
      let warned = false;
      expect(
        await main(retirement(f), {
          stderr: (text) => {
            if (text.startsWith("Retirement")) {
              warned = true;
              process.emit("SIGINT");
            }
          },
        }),
      ).toBe(130);
      expect(warned).toBe(true);
      expect(f.requests).toHaveLength(before);
      expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
    } finally {
      await f.close();
    }
  });

  it("live authorization failure or cancellation at its probe never erases the journal", async () => {
    const f = await lifecycleFixture();
    try {
      const controller = new AbortController();
      f.setRoutines((_req, res) => {
        controller.abort();
        res.writeHead(200, { "content-type": "application/json" });
        res.end(bytes({ items: [], hasMore: false, nextPageToken: null }));
      });
      await expect(
        retireProfileOperation({ configPath: f.configPath }, args().operationId, controller.signal),
      ).rejects.toMatchObject({ code: "operation_interrupted" });
      expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
      f.setRoutines((_req, res) => {
        res.writeHead(401, { "content-type": "application/json" });
        res.end(bytes({ errorCode: "invalid_session" }));
      });
      const result = await runCli(retirement(f));
      expect(result.code).toBe(4);
      expectSafe(result, f);
      expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
      expect(mutations(f)).toHaveLength(0);
    } finally {
      await f.close();
    }
  });

  it("missing IDs and definitive receipts cannot be retired or replaced", async () => {
    const f = await lifecycleFixture();
    try {
      expect((await runCli(retirement(f, uuid(999)))).code).toBe(4);
      expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
      const receipt = {
        version: 1,
        kind: "receipt",
        binding: f.candidate.binding,
        operationId: f.candidate.operationId,
        routineId: f.candidate.routineId,
        intent: f.candidate.intent,
        maxResponseBytes: 65536,
        lastConfirmedStep: "save",
        result: {
          ok: true,
          data: {
            operationId: f.candidate.operationId,
            routineId: f.candidate.routineId,
            status: "saved",
          },
        },
      };
      const owner = await f.open(f.binding);
      try {
        await owner.commit({
          operationBytes: encodeOperationStore({
            version: 1,
            binding: receipt.binding,
            operations: [receipt],
          }),
        });
      } finally {
        await owner.close();
      }
      const retained = (await inspect(f)).operationBytes;
      const result = await runCli(retirement(f));
      expect(result.code).toBe(4);
      expectSafe(result, f);
      expect(result.stderr).toMatch(/Definitive receipts are retained/);
      expect((await inspect(f)).operationBytes).toEqual(retained);
      expect(mutations(f)).toHaveLength(0);
    } finally {
      await f.close();
    }
  });
});
