// Test-only lease holder: same persistence engine and actual Secret Service;
// one explicit removal checkpoint, never imported by a production entry.
import { StorageEngine, mintRandomMaster } from "../../../dist/storage/engine.js";
import { SecretMasterKey } from "../../../dist/storage/keyring.js";
import {
  assertBusAddress,
  assertBinding,
  assertLocationRoots,
} from "../../../dist/storage/validate.js";
import { FaultArmed } from "../../../dist/storage/faults.js";
import { serveWorker } from "../../../dist/storage/ipc.js";

let engine;
let armed = false;
serveWorker({
  open: async (p) => {
    const binding = assertBinding(p.expectedBinding);
    engine = new StorageEngine({
      ...assertLocationRoots(p.profileRoot, p.anchorRoot),
      expectedLock: p.expectedLock,
      generationId: binding.profileGenerationId,
      keyAccess: new SecretMasterKey(
        assertBusAddress(p.busAddress).socketPath,
        binding.profileGenerationId,
      ),
      faults: {
        probe: async (point) => {
          if (armed && point === p.point) {
            armed = false;
            if (p.action === "kill-holder") process.kill(process.pid, "SIGKILL");
            throw new FaultArmed(point);
          }
        },
      },
      allowedFilesystems: ["ext4"],
      mintMaster: mintRandomMaster,
    });
    const opened = await engine.open(binding, p.deadlineMs);
    armed = true;
    return { binding: opened };
  },
  readVault: async (p) => engine.readVault(p.captureGeneration, p.deadlineMs),
  removeProfile: async (p) => {
    await engine.removeProfile(p.captureGeneration, p.deadlineMs);
    return null;
  },
  close: async () => {
    engine?.closeEngine();
    return null;
  },
});
