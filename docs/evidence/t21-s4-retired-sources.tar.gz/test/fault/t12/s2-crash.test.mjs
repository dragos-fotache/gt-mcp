import { fencePath, key, redacted, interruptRemoval } from "./s2-helpers.mjs";
// Representative crash-order oracles from shared journal lifecycle and S2 plan.
import fs from "node:fs";
import { randomUUID, randomBytes } from "node:crypto";
import { describe, it, expect } from "vitest";
import {
  resumeProfileRemoval,
  provisionReconciledProfile,
} from "../../../dist/storage/lifecycle.js";
import { recoverLoginProfile } from "../../../dist/login/index.js";
import { openLoginMetadata } from "../../../dist/login/metadata.js";
import { lifecycleFixture, inspect, signal, parse, bytes } from "./s1-helpers.mjs";
import { removeLoginProfile, reconcileLoginProfile } from "../../../dist/lifecycle/index.js";
import { secretToolStoreDuplicate, secretToolClearDuplicate } from "../t04/provider-helpers.mjs";

describe("T12-S2 durable removal interruptions", () => {
  it.each([
    "remove.before.intent",
    "remove.intent.durable",
    "remove.files.erased",
    "remove.key.erased",
    "remove.complete.durable",
  ])(
    "holder death at %s never reopens a removed generation and explicit recovery settles",
    async (point) => {
      const f = await lifecycleFixture();
      try {
        await interruptRemoval(f, point);
        const before = f.requests.length;
        if (point === "remove.before.intent") {
          expect(fs.existsSync(fencePath(f))).toBe(false);
          expect((await inspect(f)).operationBytes).toEqual(f.operationBytes);
        } else {
          expect(fs.existsSync(fencePath(f))).toBe(true);
          await expect(f.open(f.binding)).rejects.toMatchObject({ code: "fence_mismatch" });
        }
        if (["remove.key.erased", "remove.complete.durable"].includes(point))
          await expect(key(f).loadMaster(Date.now() + 5000)).rejects.toMatchObject({
            code: "key_not_found",
          });
        await expect(recoverLoginProfile({ configPath: f.configPath })).resolves.toEqual(
          point === "remove.before.intent" ? f.binding : redacted(f),
        );
        expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(false);
        expect(f.requests).toHaveLength(before);
        if (point !== "remove.before.intent") {
          const completed = parse(fs.readFileSync(fencePath(f)));
          expect(completed.phase).toBe("complete");
          expect(JSON.stringify(completed)).not.toContain(f.binding.accountUuid);
          const resumed = await resumeProfileRemoval({
            ...f.storage,
            expectedBinding: redacted(f),
          });
          try {
            await resumed.removeProfile();
          } finally {
            await resumed.close();
          }
        }
      } finally {
        await f.close();
      }
    },
    15000,
  );

  it("provider unavailability after intent preserves the fence and later recovery finishes without old ciphertext", async () => {
    const f = await lifecycleFixture();
    try {
      await interruptRemoval(f, "remove.files.erased");
      const owner = await resumeProfileRemoval({
        ...f.storage,
        secretServiceBusAddress: `unix:path=${f.dir}/absent`,
        expectedBinding: f.binding,
      });
      try {
        await expect(owner.removeProfile()).rejects.toMatchObject({ code: "commit_ambiguous" });
      } finally {
        await owner.close();
      }
      expect(parse(fs.readFileSync(fencePath(f))).phase).toBe("pending");
      expect(fs.readdirSync(f.storage.profileRoot)).toEqual([]);
      await expect(f.open(f.binding)).rejects.toMatchObject({ code: "fence_mismatch" });
      await expect(recoverLoginProfile({ configPath: f.configPath })).resolves.toEqual(redacted(f));
    } finally {
      await f.close();
    }
  });

  it("ambiguous reserved provider items are never deleted during pending removal", async () => {
    const f = await lifecycleFixture();
    try {
      await interruptRemoval(f, "remove.files.erased");
      secretToolStoreDuplicate(f.storage.secretServiceBusAddress, f.binding.profileGenerationId);
      try {
        await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
          code: "recovery_required",
        });
        expect(parse(fs.readFileSync(fencePath(f))).phase).toBe("pending");
        await expect(key(f).loadMaster(Date.now() + 5000)).rejects.toMatchObject({
          code: "key_ambiguous",
        });
      } finally {
        secretToolClearDuplicate(f.storage.secretServiceBusAddress);
      }
      await expect(recoverLoginProfile({ configPath: f.configPath })).resolves.toEqual(redacted(f));
    } finally {
      await f.close();
    }
  });

  it("a replacement key after durable intent is preserved and cannot finish the old cleanup", async () => {
    const f = await lifecycleFixture();
    try {
      await interruptRemoval(f, "remove.files.erased");
      const pending = parse(fs.readFileSync(fencePath(f)));
      await key(f).deleteMaster(pending.keyDigest, Date.now() + 5000);
      const replacement = randomBytes(32);
      try {
        await key(f).createMaster(replacement, Date.now() + 5000);
        await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
          code: "recovery_required",
        });
        const remaining = await key(f).loadMaster(Date.now() + 5000);
        try {
          expect(Buffer.from(remaining)).toEqual(replacement);
        } finally {
          remaining.fill(0);
        }
        expect(parse(fs.readFileSync(fencePath(f))).phase).toBe("pending");
      } finally {
        replacement.fill(0);
      }
    } finally {
      await f.close();
    }
  });

  it.each(["symlink", "hardlink", "replacement", "root"])(
    "pending cleanup refuses %s substitution and retains its fence",
    async (kind) => {
      const f = await lifecycleFixture();
      try {
        await interruptRemoval(f, "remove.intent.durable");
        const selected = `${f.storage.profileRoot}/vault.bin`;
        const preserved = `${f.dir}/preserved.bin`;
        fs.copyFileSync(selected, preserved);
        if (kind === "root") {
          fs.renameSync(f.storage.profileRoot, `${f.dir}/old-profile`);
          fs.mkdirSync(f.storage.profileRoot, { mode: 0o700 });
        } else {
          fs.unlinkSync(selected);
          if (kind === "symlink") fs.symlinkSync(preserved, selected);
          else if (kind === "hardlink") fs.linkSync(preserved, selected);
          else fs.copyFileSync(preserved, selected);
        }
        const expected = fs.readFileSync(preserved);
        await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
          code: "recovery_required",
        });
        expect(fs.readFileSync(preserved)).toEqual(expected);
        expect(parse(fs.readFileSync(fencePath(f))).phase).toBe("pending");
        const stillPresent = await key(f).loadMaster(Date.now() + 5000);
        stillPresent.fill(0);
      } finally {
        await f.close();
      }
    },
  );

  it.each(["source", "target", "published"])(
    "reconciliation publication recovery verifies %s; no old evidence or IDs are adopted",
    async (stage) => {
      const f = await lifecycleFixture();
      try {
        const source = await removeLoginProfile({ configPath: f.configPath }, signal());
        const metadata = await openLoginMetadata(f.configPath);
        const to = { ...source, profileGenerationId: randomUUID() };
        await metadata.prepareReceipt({
          version: 1,
          kind: "reconcile",
          transitionId: randomUUID(),
          from: source,
          to,
        });
        if (stage !== "source") {
          const owner = await provisionReconciledProfile({
            ...f.storage,
            origin: f.origin,
            profileGenerationId: to.profileGenerationId,
            removedBinding: source,
          });
          try {
            if (stage === "published") await metadata.publishDescriptor(source, to);
          } finally {
            await owner.close();
          }
        }
        const before = f.requests.length;
        const verified = await recoverLoginProfile({ configPath: f.configPath });
        expect(verified).toEqual(stage === "source" ? source : to);
        expect(f.requests).toHaveLength(before);
        expect(parse(fs.readFileSync(fencePath(f))).phase).toBe("complete");
        if (stage === "source") await reconcileLoginProfile({ configPath: f.configPath }, signal());
      } finally {
        await f.close();
      }
    },
  );

  it("new-profile publication recovery still requires the old completed removal fence", async () => {
    const f = await lifecycleFixture();
    try {
      const source = await removeLoginProfile({ configPath: f.configPath }, signal());
      const metadata = await openLoginMetadata(f.configPath);
      const to = { ...source, profileGenerationId: randomUUID() };
      await metadata.prepareReceipt({
        version: 1,
        kind: "reconcile",
        transitionId: randomUUID(),
        from: source,
        to,
      });
      const owner = await provisionReconciledProfile({
        ...f.storage,
        origin: f.origin,
        profileGenerationId: to.profileGenerationId,
        removedBinding: source,
      });
      await owner.close();
      fs.unlinkSync(fencePath(f));
      await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
        code: "recovery_required",
      });
      expect(parse(fs.readFileSync(f.descriptorPath)).binding).toEqual(source);
      expect(fs.existsSync(`${f.descriptorPath}.pending`)).toBe(true);
    } finally {
      await f.close();
    }
  });

  it("corrupt fence or stale binding cannot authorize cleanup", async () => {
    const f = await lifecycleFixture();
    try {
      await interruptRemoval(f, "remove.intent.durable");
      await expect(
        resumeProfileRemoval({
          ...f.storage,
          expectedBinding: { ...f.binding, sessionGeneration: f.binding.sessionGeneration + 1 },
        }),
      ).rejects.toMatchObject({ code: "binding_mismatch" });
      const fence = parse(fs.readFileSync(fencePath(f)));
      fs.writeFileSync(fencePath(f), bytes({ ...fence, extra: true }));
      await expect(recoverLoginProfile({ configPath: f.configPath })).rejects.toMatchObject({
        code: "recovery_required",
      });
      expect(fs.existsSync(`${f.storage.profileRoot}/vault.bin`)).toBe(true);
    } finally {
      await f.close();
    }
  });
});
