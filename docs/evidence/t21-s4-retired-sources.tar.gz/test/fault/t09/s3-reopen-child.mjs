/* global AbortController */
// Separate process restart proof; only synthetic fixture metadata enters stdin.
import { createHash } from "node:crypto";
import { attachStorageTestFacility } from "../../../dist/storage/test-facility.js";
import { openOperationRepository } from "../../../dist/operations/index.js";
let owner, repository;
try {
  let input = "";
  for await (const chunk of process.stdin) input += chunk;
  const { ticket, binding, args, config } = JSON.parse(input);
  const facility = await attachStorageTestFacility(ticket);
  owner = await facility.open(binding);
  repository = openOperationRepository({
    owner,
    config,
    reads: {
      binding: owner.binding,
      async listRoutines() {},
      async getExercise() {
        throw new Error("existing operation must not precheck");
      },
    },
  });
  const record = await repository.withOperation(binding, args, new AbortController().signal, (h) =>
    h.snapshot(),
  );
  process.stdout.write(createHash("sha256").update(JSON.stringify(record)).digest("hex"));
} catch {
  process.stderr.write("Synthetic restart probe failed.");
  process.exitCode = 1;
} finally {
  repository?.close();
  if (owner) await owner.close();
}
