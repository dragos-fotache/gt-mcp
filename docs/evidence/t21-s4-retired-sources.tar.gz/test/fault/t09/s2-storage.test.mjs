// Real production provider/ext4/HTTPS composition, plus bounded diagnostic faults.
// Synthetic fixtures only. No actual backend mutation or live-auth claim.
import { describe, it, expect } from "vitest";
import { randomUUID } from "node:crypto";
import { readFileSync, rmSync } from "node:fs";
import { spawn } from "node:child_process";
import { openProfile, provisionProfile } from "../../../dist/storage/index.js";
import { createStorageTestFacility } from "../../../dist/storage/test-facility.js";
import { openSessionState, openAuthenticatedSessionState } from "../../../dist/auth/index.js";
import { openOperationRepository } from "../../../dist/operations/index.js";
import { startLoopbackHttps, closeServer } from "../t05/helpers.mjs";
import { bundledExerciseWire, routineListWire } from "../../unit/t05/helpers.mjs";
import { requireProviderEnv, assertExt4Parent, makeRoots } from "../t04/provider-helpers.mjs";
import { teardownAll } from "../../unit/t06/helpers.mjs";
import { args, config, signal, uuid } from "../../unit/t09/s2-helpers.mjs";

// Child receives only synthetic noncredential location/binding metadata over stdin.
async function childOpen(request) {
  const entry = new URL("../../../dist/storage/index.js", import.meta.url).href;
  const script = `import {openProfile} from ${JSON.stringify(entry)};
    let text=''; for await (const chunk of process.stdin) text+=chunk;
    try { const p=await openProfile(JSON.parse(text)); await p.close(); process.stdout.write('opened'); }
    catch(e) { process.stdout.write(e.code==='locked_by_other_owner'?'locked_by_other_owner':'unexpected'); process.exitCode=e.code==='locked_by_other_owner'?0:1; }`;
  const child = spawn(process.execPath, ["--input-type=module", "-e", script], {
    stdio: ["pipe", "pipe", "pipe"],
    timeout: 10000,
  });
  let output = "",
    stderr = "";
  child.stdout.on("data", (b) => {
    output += b;
  });
  child.stderr.on("data", (b) => {
    stderr += b;
  });
  const ended = new Promise((resolve, reject) => {
    child.once("error", reject);
    child.once("close", (code) => resolve({ code, output, stderr }));
  });
  child.stdin.end(JSON.stringify(request));
  return ended;
}

describe("S2 real protected storage and authenticated reads", () => {
  it("commits once, excludes a second process, reopens exact identity and fences actual generation advance", async () => {
    const { bus, parent } = requireProviderEnv();
    assertExt4Parent(parent);
    const roots = makeRoots(parent, "synthetic-t09-s2-");
    let fixture, owner, auth, repository;
    let invisible = false,
      unauthorized = false;
    const cleanup = [];
    try {
      fixture = await startLoopbackHttps(
        {
          keyPem: readFileSync(process.env.GT_S1_FIXTURE_KEY_FILE),
          certPem: readFileSync(process.env.GT_S1_FIXTURE_CERT_FILE),
          label: "synthetic-t09-s2",
        },
        (req, res) => {
          expect(req.method).toBe("GET");
          expect(req.headers.authorization).toBe("Bearer synthetic-t09-access");
          const isExercise = req.url === `/v1/exercises/${uuid(4)}`;
          const status = unauthorized ? 403 : isExercise && invisible ? 404 : 200;
          const body =
            status === 200
              ? isExercise
                ? bundledExerciseWire(uuid(4))
                : routineListWire([])
              : {
                  errorCode: status === 404 ? "not_found" : "read_only",
                  message: null,
                };
          res.writeHead(status, { "content-type": "application/json" });
          res.end(JSON.stringify(body));
        },
      );
      cleanup.push(() => closeServer(fixture.server));
      const storage = {
        profileRoot: roots.profileRoot,
        anchorRoot: roots.anchorRoot,
        secretServiceBusAddress: bus,
        timeoutMs: 5000,
      };
      owner = await provisionProfile({
        ...storage,
        origin: fixture.origin,
        profileGenerationId: randomUUID(),
      });
      const session = await openSessionState({ profile: owner });
      const grant = {
        account: { id: uuid(1), displayName: null },
        accessToken: "synthetic-t09-access",
        refreshToken: "synthetic-t09-refresh",
        accessExpiresAt: new Date(Date.now() + 600000).toISOString(),
        refreshExpiresAt: new Date(Date.now() + 86400000).toISOString(),
      };
      const bound = await session.installInitialGrant(
        owner.binding,
        Buffer.from(JSON.stringify(grant)),
        signal(),
      );
      session.invalidate();
      await owner.close();
      owner = await openProfile({ ...storage, expectedBinding: bound });
      const settings = {
        ...config(fixture.origin),
        storage,
        bindingDescriptorPath: `${roots.base}/binding.json`,
      };
      const open = async () => {
        auth = await openAuthenticatedSessionState({
          profile: owner,
          transportConfig: {
            origin: fixture.origin,
            budgets: { perAttemptTimeoutMs: 1000, totalDeadlineMs: 3000 },
          },
        });
        repository = openOperationRepository({ owner, reads: auth, config: settings });
      };
      await open();
      const vault = await owner.readVaultBytes();
      const first = await repository.withOperation(owner.binding, args(), signal(), (h) =>
        h.snapshot(),
      );
      const originalBytes = await owner.readOperationStoreBytes();
      expect(fixture.requests.map((r) => r.url)).toEqual([
        "/v1/routines?limit=1",
        `/v1/exercises/${uuid(4)}`,
      ]);
      expect(await owner.readVaultBytes()).toEqual(vault);
      expect(await childOpen({ ...storage, expectedBinding: owner.binding })).toEqual({
        code: 0,
        output: "locked_by_other_owner",
        stderr: "",
      });
      invisible = true;
      expect(
        await repository.withOperation(owner.binding, args(), signal(), (h) => h.snapshot()),
      ).toEqual(first);
      await expect(
        repository.withOperation(owner.binding, args(5), signal(), async () => {
          throw new Error("must not admit");
        }),
      ).rejects.toMatchObject({ code: "invalid_reference" });
      expect(await owner.readOperationStoreBytes()).toEqual(originalBytes);
      unauthorized = true;
      await expect(
        repository.withOperation(owner.binding, args(6), signal(), async () => {}),
      ).rejects.toMatchObject({ code: "read_only" });
      expect(await owner.readOperationStoreBytes()).toEqual(originalBytes);
      unauthorized = false;
      repository.close();
      auth.invalidate();
      const binding = owner.binding;
      await owner.close();
      expect(await childOpen({ ...storage, expectedBinding: binding })).toEqual({
        code: 0,
        output: "opened",
        stderr: "",
      });
      owner = await openProfile({ ...storage, expectedBinding: binding });
      await open();
      expect(
        await repository.withOperation(owner.binding, args(), signal(), (h) => h.snapshot()),
      ).toEqual(first);
      let nextBinding;
      await expect(
        repository.withOperation(owner.binding, args(), signal(), async (h) => {
          nextBinding = await owner.advanceSessionGeneration(await owner.readVaultBytes());
          // T04 retains the old binding snapshot, so this requires an actual owner call.
          expect(owner.binding.sessionGeneration).toBe(binding.sessionGeneration);
          await expect(h.snapshot()).rejects.toMatchObject({ code: "generation_mismatch" });
        }),
      ).rejects.toMatchObject({ code: "generation_mismatch" });
      repository.close();
      auth.invalidate();
      await owner.close();
      owner = await openProfile({ ...storage, expectedBinding: nextBinding });
      // Trusted same-account new-generation vault would be installed by T07/T12.
      // For this storage fence proof, use mandatory local read fakes, not stale credentials.
      repository = openOperationRepository({
        owner,
        config: settings,
        reads: {
          binding: owner.binding,
          async listRoutines() {},
          async getExercise() {
            throw new Error("existing repeat must skip visibility");
          },
        },
      });
      expect(
        await repository.withOperation(owner.binding, args(), signal(), (h) => h.snapshot()),
      ).toEqual(first);
      expect(await owner.readOperationStoreBytes()).toEqual(originalBytes);
      expect(fixture.requests.every((r) => r.method === "GET")).toBe(true);
    } finally {
      repository?.close();
      auth?.invalidate();
      await teardownAll([
        ...(owner ? [() => owner.close()] : []),
        ...cleanup,
        () => rmSync(roots.base, { recursive: true, force: true }),
      ]);
    }
  }, 30000);
});

describe("S2 admission commit failures through the real T04 engine", () => {
  for (const point of ["commit.before.prepare", "commit.reply"]) {
    it(`${point} never acknowledges admission; ambiguity fences the repository`, async () => {
      const facility = await createStorageTestFacility();
      let owner, repository;
      try {
        owner = await facility.provision("https://synthetic.example");
        const next = await owner.bindAccount(uuid(1), new Uint8Array());
        await owner.close();
        owner = await facility.open(next);
        const factory = () =>
          openOperationRepository({
            owner,
            config: config(),
            reads: { binding: owner.binding, async listRoutines() {}, async getExercise() {} },
          });
        repository = factory();
        await facility.armFault({
          point,
          action: point === "commit.reply" ? "kill-holder" : "throw",
        });
        let entered = false;
        await expect(
          repository.withOperation(owner.binding, args(), signal(), async () => {
            entered = true;
          }),
        ).rejects.toMatchObject({
          code: point === "commit.reply" ? "commit_ambiguous" : "io_failure",
        });
        expect(entered).toBe(false);
        await facility.clearFault();
        if (point === "commit.reply") {
          await expect(
            repository.withOperation(owner.binding, args(), signal(), async () => {}),
          ).rejects.toMatchObject({ code: "operation_interrupted" });
          expect(factory).toThrow(expect.objectContaining({ code: "commit_ambiguous" }));
        } else {
          expect(await owner.readOperationStoreBytes()).toEqual(new Uint8Array());
        }
        repository.close();
        const binding = owner.binding;
        await owner.close();
        owner = await facility.open(binding);
        repository = factory();
        const before = await owner.readOperationStoreBytes();
        const reopened = await repository.withOperation(owner.binding, args(), signal(), (h) =>
          h.snapshot(),
        );
        expect(reopened.steps.every((s) => s.state === "unsent")).toBe(true);
        if (point === "commit.reply") expect(await owner.readOperationStoreBytes()).toEqual(before);
        else expect(before.length).toBe(0);
      } finally {
        repository?.close();
        await teardownAll([...(owner ? [() => owner.close()] : []), () => facility.cleanup()]);
      }
    }, 20000);
  }
});
