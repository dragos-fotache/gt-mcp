// S3 repository persistence boundaries on the real isolated T04 engine.
import { describe, it, expect } from "vitest";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { createStorageTestFacility } from "../../../dist/storage/test-facility.js";
import {
  createOperationCandidate,
  decodeOperationStore,
  encodeOperationStore,
  openOperationRepository,
  operationIntentMaterial,
  validateOperationRecord,
} from "../../../dist/operations/index.js";
import { teardownAll } from "../../unit/t06/helpers.mjs";
import { args, config, signal, uuid } from "../../unit/t09/s2-helpers.mjs";

const fingerprint = (value) => createHash("sha256").update(JSON.stringify(value)).digest("hex");
const saved = (record) => ({
  ok: true,
  data: { operationId: record.operationId, routineId: record.routineId, status: "saved" },
});
const uncertain = (record) => ({
  ok: false,
  error: {
    code: "backend_error",
    retryable: false,
    operationId: record.operationId,
    routineId: record.routineId,
    lastConfirmedStep: "none",
    outcomeUnknown: true,
  },
});

async function fixture() {
  const facility = await createStorageTestFacility();
  let owner, repository;
  try {
    owner = await facility.provision("https://synthetic.example");
    const binding = await owner.bindAccount(uuid(1), Buffer.from("synthetic-vault-sentinel"));
    await owner.close();
    owner = await facility.open(binding);
    const open = () => {
      repository = openOperationRepository({
        owner,
        config: config(),
        reads: { binding: owner.binding, async listRoutines() {}, async getExercise() {} },
      });
    };
    open();
    return {
      facility,
      get owner() {
        return owner;
      },
      get repository() {
        return repository;
      },
      run: (work, input = args()) => repository.withOperation(owner.binding, input, signal(), work),
      async reopen() {
        repository.close();
        const binding = owner.binding;
        await owner.close();
        owner = await facility.open(binding);
        open();
      },
      async child(record) {
        repository.close();
        const binding = owner.binding;
        await owner.close();
        const child = spawn(
          process.execPath,
          [fileURLToPath(new URL("./s3-reopen-child.mjs", import.meta.url))],
          { stdio: ["pipe", "pipe", "pipe"], timeout: 10000 },
        );
        let stdout = "",
          stderr = "";
        child.stdout.on("data", (b) => {
          stdout += b;
        });
        child.stderr.on("data", (b) => {
          stderr += b;
        });
        const ended = new Promise((resolve, reject) => {
          child.once("error", reject);
          child.once("close", (code) => resolve({ code, stdout, stderr }));
        });
        child.stdin.end(
          JSON.stringify({ ticket: facility.ticket, binding, args: args(), config: config() }),
        );
        expect(await ended).toEqual({ code: 0, stdout: fingerprint(record), stderr: "" });
        owner = await facility.open(binding);
        open();
      },
      async close() {
        repository.close();
        await teardownAll([() => owner.close(), () => facility.cleanup()]);
      },
    };
  } catch (error) {
    await teardownAll([...(owner ? [() => owner.close()] : []), () => facility.cleanup()]);
    throw error;
  }
}

describe("S3 persisted states, restart and minimization", () => {
  it("retains alternate exact bytes and Int64 across pending/confirmed/terminal/receipt process restarts", async () => {
    const f = await fixture();
    try {
      // Seed a valid originally-admitted fixture with alternate byte spelling.
      f.repository.close();
      let next = 100;
      let initial = createOperationCandidate(args(), {
        binding: {
          origin: f.owner.binding.origin,
          accountUuid: f.owner.binding.accountUuid,
          profileGenerationId: f.owner.binding.profileGenerationId,
        },
        limits: { maxRequestBytes: 65536, maxResponseBytes: 65536 },
        intentDigest: await f.owner.keyedIntentDigest(operationIntentMaterial(args())),
        generateUuid: () => uuid(next++),
      });
      initial = JSON.parse(JSON.stringify(initial));
      initial.steps = initial.steps.map((s) => ({
        ...s,
        bodyBase64: Buffer.from(
          " \n" + JSON.stringify(JSON.parse(Buffer.from(s.bodyBase64, "base64")), null, 2) + "\n",
        ).toString("base64"),
      }));
      initial.reservationBytes = 0;
      initial.reservationBytes =
        Buffer.byteLength(JSON.stringify(initial)) + initial.limits.maxResponseBytes + 2048;
      initial = validateOperationRecord(initial, initial.binding);
      await f.owner.commit({
        operationBytes: encodeOperationStore({
          version: 1,
          binding: initial.binding,
          operations: [initial],
        }),
      });
      await f.reopen();
      const vault = await f.owner.readVaultBytes();
      await f.run(async (h) => {
        expect(await h.snapshot()).toEqual(initial);
        await h.recordDispatchPossible("draft");
      });
      const pending = await f.run((h) => h.snapshot());
      await f.child(pending);
      await f.run(async (h) => {
        expect((await h.snapshot()).steps[0].state).toBe("dispatch-possible");
        for (const step of initial.steps)
          expect(Buffer.from((await h.readStep(step.step)).body).toString("base64")).toBe(
            step.bodyBase64,
          );
        await h.recordConfirmation({ step: "draft", revision: "9007199254740993" });
      });
      await f.reopen();
      await f.run(async (h) => {
        expect((await h.confirmationBaseline()).revision).toBe("9007199254740993");
        await h.recordDispatchPossible("populate");
        await h.recordConfirmation({ step: "populate", revision: "9007199254740995" });
        await h.recordDispatchPossible("save");
        await h.recordConfirmation(
          { step: "save", revision: "9223372036854775807" },
          saved(initial),
        );
      });
      await f.reopen();
      const terminal = await f.run((h) => h.snapshot());
      expect(terminal.terminal).toEqual(saved(initial));
      expect(terminal.steps.map((s) => ({ ...s, state: "unsent" }))).toEqual(initial.steps);
      expect(terminal.reservationBytes).toBe(initial.reservationBytes);
      await f.run((h) => h.compactTerminal());
      await f.reopen();
      const receipt = await f.run((h) => h.snapshot());
      await f.child(receipt);
      expect(receipt.kind).toBe("receipt");
      expect(receipt.intent).toEqual(initial.intent);
      expect(receipt.result).toEqual(saved(initial));
      expect(Object.keys(receipt).sort()).toEqual(
        [
          "version",
          "kind",
          "binding",
          "operationId",
          "routineId",
          "intent",
          "maxResponseBytes",
          "lastConfirmedStep",
          "result",
        ].sort(),
      );
      const plaintext = Buffer.from(await f.owner.readOperationStoreBytes()).toString();
      for (const forbidden of [
        "bodyBase64",
        "resourceKey",
        "exercises",
        "Synthetic routine",
        "synthetic-vault-sentinel",
      ])
        expect(plaintext).not.toContain(forbidden);
      expect(await f.owner.readVaultBytes()).toEqual(vault);
      expect(
        readFileSync(join(f.facility.locations.profileRoot, "operations.bin")).includes(
          Buffer.from("Synthetic routine"),
        ),
      ).toBe(false);
      await expect(f.run(async () => {}, { ...args(), name: "Changed" })).rejects.toMatchObject({
        code: "operation_id_reused",
      });
    } finally {
      await f.close();
    }
  }, 30000);

  it("retains uncertain evidence on reopen and explicitly retires without releasing the ID", async () => {
    const f = await fixture();
    try {
      let initial;
      await f.run(async (h) => {
        initial = await h.snapshot();
        await h.recordDispatchPossible("draft");
        await h.settleTerminal(uncertain(initial));
      });
      await f.reopen();
      await f.run(async (h) => {
        expect((await h.snapshot()).terminal).toEqual(uncertain(initial));
        await expect(h.compactTerminal()).rejects.toMatchObject({ code: "invalid_state" });
      });
      await f.repository.retireOperation(f.owner.binding, args().operationId, signal());
      await f.reopen();
      const store = decodeOperationStore(await f.owner.readOperationStoreBytes(), initial.binding);
      expect(store.operations).toEqual([
        {
          version: 1,
          kind: "retired",
          binding: initial.binding,
          operationId: initial.operationId,
          routineId: initial.routineId,
        },
      ]);
      for (const input of [args(), { ...args(), name: "Changed" }])
        await expect(f.run(async () => {}, input)).rejects.toMatchObject({
          code: "recovery_unavailable",
        });
      expect(Buffer.from(await f.owner.readOperationStoreBytes()).toString()).not.toContain(
        "intent",
      );
    } finally {
      await f.close();
    }
  });

  for (const point of ["commit.before.prepare", "commit.reply"]) {
    it(`${point} during confirmation never acknowledges advancement and reopens only durable evidence`, async () => {
      const f = await fixture();
      try {
        await f.run((h) => h.recordDispatchPossible("draft"));
        const before = await f.owner.readOperationStoreBytes();
        let acknowledged = false;
        await f.facility.armFault({
          point,
          action: point === "commit.reply" ? "kill-holder" : "throw",
        });
        await expect(
          f.run(async (h) => {
            await h.recordConfirmation({ step: "draft", revision: "9007199254740993" });
            acknowledged = true;
          }),
        ).rejects.toMatchObject({
          code: point === "commit.reply" ? "commit_ambiguous" : "io_failure",
        });
        expect(acknowledged).toBe(false);
        await f.facility.clearFault();
        if (point === "commit.reply")
          await expect(f.run(async () => {})).rejects.toMatchObject({
            code: "operation_interrupted",
          });
        else expect(await f.owner.readOperationStoreBytes()).toEqual(before);
        await f.reopen();
        const reopened = await f.run((h) => h.snapshot());
        expect(reopened.steps[0].state).toBe(
          point === "commit.reply" ? "confirmed" : "dispatch-possible",
        );
        expect(reopened.confirmed).toEqual(
          point === "commit.reply" ? { step: "draft", revision: "9007199254740993" } : null,
        );
        if (point === "commit.before.prepare")
          await f.run((h) => h.recordConfirmation({ step: "draft", revision: "9007199254740993" }));
      } finally {
        await f.close();
      }
    }, 20000);
  }

  it("a missing key or corrupt journal blocks confirmation without reset or replacement", async () => {
    const f = await fixture();
    try {
      await f.run((h) => h.recordDispatchPossible("draft"));
      const original = await f.owner.readOperationStoreBytes();
      await f.run(async (h) => {
        await f.facility.setKeyState("missing");
        try {
          await expect(
            h.recordConfirmation({ step: "draft", revision: "1" }),
          ).rejects.toMatchObject({ code: "key_not_found" });
        } finally {
          await f.facility.setKeyState("available");
        }
      });
      expect(await f.owner.readOperationStoreBytes()).toEqual(original);
      f.repository.close();
      await f.owner.commit({ operationBytes: Buffer.from('{"version":2}') });
      await f.reopen();
      await expect(f.run(async () => {})).rejects.toMatchObject({ code: "recovery_unavailable" });
      expect(Buffer.from(await f.owner.readOperationStoreBytes()).toString()).toBe('{"version":2}');
    } finally {
      await f.close();
    }
  });

  it("restoring older encrypted operation bytes under the current anchor fails closed", async () => {
    const f = await fixture();
    try {
      await f.run((h) => h.recordDispatchPossible("draft"));
      const file = join(f.facility.locations.profileRoot, "operations.bin");
      const older = readFileSync(file);
      await f.run((h) => h.recordConfirmation({ step: "draft", revision: "1" }));
      const anchor = readFileSync(join(f.facility.locations.anchorRoot, "anchor.bin"));
      f.repository.close();
      await f.owner.close();
      writeFileSync(file, older);
      await expect(f.facility.open(f.owner.binding)).rejects.toMatchObject({
        code: "fence_mismatch",
      });
      expect(readFileSync(join(f.facility.locations.anchorRoot, "anchor.bin"))).toEqual(anchor);
    } finally {
      await f.close();
    }
  });
});
