import { AsyncLocalStorage } from "node:async_hooks";
import { timingSafeEqual } from "node:crypto";
import { isSessionError } from "../auth/index.js";
import type { AuthenticatedSessionState } from "../auth/index.js";
import { DEFAULT_TRANSPORT_BUDGETS, isTransportError } from "../http/index.js";
import { validateConfigRecord } from "../runtime/config.js";
import { isStorageError, StorageError } from "../storage/index.js";
import type { ProfileSession, StorageBinding } from "../storage/index.js";
import {
  createOperationCandidate,
  operationIntentMaterial,
  parseLegacyOperationInput,
} from "./candidate.js";
import { isOperationError, OperationError } from "./errors.js";
import { rememberOperationFailure } from "./context.js";
import {
  decodeOperationStore,
  encodeOperationStore,
  measureOperationStore,
  parseBinding,
  readConfirmationBaseline,
  readOperationStep,
  validateOperationRecord,
} from "./format.js";
import { captureJson, copyBytes } from "./json.js";
import { uuidSchema } from "./schema.js";
import {
  captureConfirmation,
  captureStep,
  captureTerminal,
  compact,
  confirm,
  dispatchPossible,
  retire,
  settle,
} from "./transitions.js";
import type {
  ConfirmationMarker,
  ConfirmationBaseline,
  OperationRecord,
  OperationStepName,
  OperationStore,
  StoredOperationRequest,
  TerminalOperationResult,
} from "./types.js";

export type OperationAdmissionReads = Pick<
  AuthenticatedSessionState,
  "binding" | "listRoutines" | "getExercise"
>;
export interface OperationRepositoryOptions {
  readonly owner: ProfileSession;
  /** Trusted T08 version-1 operator config record; no file IO here. */
  readonly config: unknown;
  readonly reads: OperationAdmissionReads;
  readonly generateUuid?: () => string;
}
export interface AdmittedOperation {
  snapshot(): Promise<OperationRecord>;
  readStep(step: OperationStepName): Promise<StoredOperationRequest>;
  confirmationBaseline(): Promise<ConfirmationBaseline | null>;
  recordDispatchPossible(step: OperationStepName): Promise<void>;
  recordConfirmation(marker: ConfirmationMarker, terminal?: TerminalOperationResult): Promise<void>;
  settleTerminal(result: TerminalOperationResult): Promise<void>;
  compactTerminal(): Promise<void>;
}
export interface OperationRepository {
  withOperation<T>(
    capturedBinding: StorageBinding,
    createArgs: unknown,
    signal: AbortSignal,
    work: (handle: AdmittedOperation) => Promise<T>,
  ): Promise<T>;
  /** Trusted local erasure only; T12 owns warning/user authorization. */
  retireOperation(
    capturedBinding: StorageBinding,
    operationId: string,
    signal: AbortSignal,
  ): Promise<void>;
  /** Permanent synchronous fence; never closes the caller-owned profile. */
  close(): void;
}

// Claims concern already-owned capability objects, never paths or accounts.
const claimedOwners = new WeakSet<object>();
const ambiguousOwners = new WeakSet<object>();
function fail(code: "invalid_arguments" | "operation_interrupted"): never {
  throw new OperationError(code);
}
function fields(value: unknown): Record<string, unknown> {
  if (
    value === null ||
    typeof value !== "object" ||
    ![Object.prototype, null].includes(Object.getPrototypeOf(value) as object | null)
  ) {
    return fail("invalid_arguments");
  }
  const result: Record<string, unknown> = {};
  for (const key of Reflect.ownKeys(value)) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (typeof key !== "string" || descriptor === undefined || !("value" in descriptor)) {
      return fail("invalid_arguments");
    }
    Object.defineProperty(result, key, { value: descriptor.value, enumerable: true });
  }
  return result;
}
function binding(value: unknown): StorageBinding {
  const data = fields(value);
  if (
    Object.keys(data).length !== 4 ||
    !Number.isSafeInteger(data["sessionGeneration"]) ||
    (data["sessionGeneration"] as number) < 0
  )
    return fail("invalid_arguments");
  const durable = parseBinding({
    origin: data["origin"],
    accountUuid: data["accountUuid"],
    profileGenerationId: data["profileGenerationId"],
  });
  return Object.freeze({ ...durable, sessionGeneration: data["sessionGeneration"] as number });
}
function equalBinding(a: StorageBinding, b: StorageBinding): boolean {
  return (
    a.origin === b.origin &&
    a.accountUuid === b.accountUuid &&
    a.profileGenerationId === b.profileGenerationId &&
    a.sessionGeneration === b.sessionGeneration
  );
}
function safeBoundaryError(error: unknown): never {
  if (
    isOperationError(error) ||
    isStorageError(error) ||
    isSessionError(error) ||
    isTransportError(error)
  )
    throw error;
  throw new OperationError("internal_error");
}

/** FIFO exclusion with local queued cancellation, no detached waiter work. */
class Mutex {
  private held = false;
  private readonly queue: Array<() => void> = [];
  acquire(signal: AbortSignal): Promise<() => void> {
    return new Promise((resolve, reject) => {
      if (signal.aborted) {
        reject(new OperationError("operation_interrupted"));
        return;
      }
      const abort = (): void => {
        const index = this.queue.indexOf(grant);
        if (index >= 0) this.queue.splice(index, 1);
        signal.removeEventListener("abort", abort);
        reject(new OperationError("operation_interrupted"));
      };
      const grant = (): void => {
        signal.removeEventListener("abort", abort);
        this.held = true;
        let released = false;
        resolve(() => {
          if (released) return;
          released = true;
          const next = this.queue.shift();
          if (next) next();
          else this.held = false;
        });
      };
      if (this.held) {
        this.queue.push(grant);
        signal.addEventListener("abort", abort, { once: true });
      } else grant();
    });
  }
}

/** No owner provisioning/closing, store read, auth call or dispatch at construction. */
export function openOperationRepository(options: OperationRepositoryOptions): OperationRepository {
  let initial: StorageBinding;
  let owner: ProfileSession;
  let reads: OperationAdmissionReads;
  let config;
  let generateUuid: (() => string) | undefined;
  try {
    const data = fields(options);
    if (
      Object.keys(data).some((key) => !["owner", "reads", "config", "generateUuid"].includes(key))
    ) {
      return fail("invalid_arguments");
    }
    owner = data["owner"] as ProfileSession;
    reads = data["reads"] as OperationAdmissionReads;
    initial = binding(owner.binding);
    if (!equalBinding(initial, binding(reads.binding))) return fail("invalid_arguments");
    generateUuid = data["generateUuid"] as (() => string) | undefined;
    if (generateUuid !== undefined && typeof generateUuid !== "function")
      return fail("invalid_arguments");
    try {
      config = validateConfigRecord(fields(captureJson(data["config"])));
    } catch {
      throw new OperationError("configuration_required");
    }
    if (config.canonicalOrigin !== initial.origin)
      throw new OperationError("configuration_required");
  } catch (error) {
    if (isOperationError(error) && error.code === "configuration_required") throw error;
    return fail("invalid_arguments");
  }
  // Methods retain their receivers. Trusted binding getters remain live.
  const method = <T extends (...args: never[]) => unknown>(capability: object, name: string): T => {
    const proto: unknown = Object.getPrototypeOf(capability);
    const descriptor =
      Object.getOwnPropertyDescriptor(capability, name) ??
      (proto === null ? undefined : Object.getOwnPropertyDescriptor(proto, name));
    if (!descriptor || !("value" in descriptor) || typeof descriptor.value !== "function") {
      return fail("invalid_arguments");
    }
    return descriptor.value.bind(capability) as T;
  };
  const readStore = method<ProfileSession["readOperationStoreBytes"]>(
    owner,
    "readOperationStoreBytes",
  );
  const digestIntent = method<ProfileSession["keyedIntentDigest"]>(owner, "keyedIntentDigest");
  const commit = method<ProfileSession["commit"]>(owner, "commit");
  const authenticate = method<OperationAdmissionReads["listRoutines"]>(reads, "listRoutines");
  const visible = method<OperationAdmissionReads["getExercise"]>(reads, "getExercise");
  if (ambiguousOwners.has(owner)) throw new StorageError("commit_ambiguous");
  if (claimedOwners.has(owner)) return fail("invalid_arguments");
  claimedOwners.add(owner);
  const durableBinding = parseBinding({
    origin: initial.origin,
    accountUuid: initial.accountUuid,
    profileGenerationId: initial.profileGenerationId,
  });
  const limits = {
    maxRequestBytes: config.budgets?.maxRequestBytes ?? DEFAULT_TRANSPORT_BUDGETS.maxRequestBytes,
    maxResponseBytes:
      config.budgets?.maxResponseBytes ?? DEFAULT_TRANSPORT_BUDGETS.maxResponseBytes,
  };
  const storeLock = new Mutex();
  const operationLocks = new Map<string, { mutex: Mutex; users: number }>();
  const callbackContext = new AsyncLocalStorage<{ active: boolean }>();
  const invalidated = new AbortController();
  let pending = 0;
  let closed = false;
  const releaseClaim = (): void => {
    if (closed && pending === 0) claimedOwners.delete(owner);
  };
  const close = (): void => {
    closed = true;
    invalidated.abort();
    releaseClaim();
  };
  const check = (captured: StorageBinding, signal: AbortSignal): void => {
    if (closed || signal.aborted) return fail("operation_interrupted");
    try {
      if (
        !equalBinding(captured, binding(owner.binding)) ||
        !equalBinding(captured, binding(reads.binding)) ||
        captured.origin !== durableBinding.origin ||
        captured.accountUuid !== durableBinding.accountUuid ||
        captured.profileGenerationId !== durableBinding.profileGenerationId
      )
        return fail("operation_interrupted");
    } catch {
      return fail("operation_interrupted");
    }
  };
  const load = async (): Promise<OperationStore> => {
    let bytes;
    try {
      bytes = await readStore();
    } catch (error) {
      return safeBoundaryError(error);
    }
    return decodeOperationStore(bytes, durableBinding);
  };
  const compare = (record: OperationRecord | undefined, digest: Uint8Array): void => {
    if (!record) return;
    if (record.kind === "retired") throw new OperationError("recovery_unavailable");
    if (!timingSafeEqual(Buffer.from(record.intent.digestBase64, "base64"), digest)) {
      throw new OperationError("operation_id_reused");
    }
  };
  const probe = async (captured: StorageBinding, signal: AbortSignal): Promise<void> => {
    check(captured, signal);
    try {
      await authenticate(captured, { limit: 1 }, signal);
    } catch (error) {
      return safeBoundaryError(error);
    }
    check(captured, signal);
  };
  const persist = async (
    store: OperationStore,
    previous: OperationRecord | undefined,
    next: OperationRecord,
    captured: StorageBinding,
    signal: AbortSignal,
  ): Promise<void> => {
    const updated: OperationStore = {
      ...store,
      operations:
        previous === undefined
          ? [...store.operations, next]
          : store.operations.map((item) => (item === previous ? next : item)),
    };
    measureOperationStore(updated);
    const operationBytes = encodeOperationStore(updated);
    check(captured, signal);
    try {
      await commit({ operationBytes });
    } catch (error) {
      if (!isStorageError(error) || error.code === "commit_ambiguous") {
        ambiguousOwners.add(owner);
        close();
        throw new StorageError("commit_ambiguous");
      }
      throw error;
    }
    // Caller updates its local state before suppressing any late success.
  };
  return Object.freeze({
    close,
    async retireOperation(
      capturedBinding: StorageBinding,
      operationId: string,
      signal: AbortSignal,
    ): Promise<void> {
      let captured: StorageBinding;
      let id: string;
      try {
        captured = binding(capturedBinding);
        id = uuidSchema.parse(operationId);
        if (!(signal instanceof AbortSignal)) return fail("invalid_arguments");
      } catch {
        return fail("invalid_arguments");
      }
      if (callbackContext.getStore()?.active) return fail("invalid_arguments");
      check(captured, signal);
      const combined = AbortSignal.any([signal, invalidated.signal]);
      const lock = operationLocks.get(id) ?? { mutex: new Mutex(), users: 0 };
      operationLocks.set(id, lock);
      lock.users += 1;
      pending += 1;
      let unlock: (() => void) | undefined;
      try {
        unlock = await lock.mutex.acquire(combined);
        await probe(captured, combined);
        const release = await storeLock.acquire(combined);
        try {
          check(captured, combined);
          const store = await load();
          check(captured, combined);
          const previous = store.operations.find((item) => item.operationId === id);
          if (!previous) throw new OperationError("recovery_unavailable");
          const next = retire(previous);
          if (next !== previous) await persist(store, previous, next, captured, combined);
          check(captured, combined);
        } finally {
          release();
        }
      } finally {
        unlock?.();
        lock.users -= 1;
        if (lock.users === 0) operationLocks.delete(id);
        pending -= 1;
        releaseClaim();
      }
    },
    async withOperation<T>(
      capturedBinding: StorageBinding,
      createArgs: unknown,
      signal: AbortSignal,
      work: (handle: AdmittedOperation) => Promise<T>,
    ): Promise<T> {
      // Complete ordinary input capture precedes the first await.
      let captured: StorageBinding;
      let args;
      let material: Uint8Array;
      try {
        captured = binding(capturedBinding);
        args = parseLegacyOperationInput(captureJson(createArgs));
        material = operationIntentMaterial(args);
        if (!(signal instanceof AbortSignal) || typeof work !== "function")
          return fail("invalid_arguments");
      } catch {
        return fail("invalid_arguments");
      }
      if (callbackContext.getStore()?.active) return fail("invalid_arguments");
      check(captured, signal);
      if (!config.writesEnabled) throw new OperationError("configuration_required");
      const combined = AbortSignal.any([signal, invalidated.signal]);
      const lock = operationLocks.get(args.operationId) ?? { mutex: new Mutex(), users: 0 };
      operationLocks.set(args.operationId, lock);
      lock.users += 1;
      pending += 1;
      let unlock: (() => void) | undefined;
      let acknowledged: OperationRecord | undefined;
      try {
        unlock = await lock.mutex.acquire(combined);
        check(captured, combined);
        await probe(captured, combined);
        let record: OperationRecord | undefined;
        let digest: Uint8Array;
        let releaseStore = await storeLock.acquire(combined);
        try {
          check(captured, combined);
          const store = await load();
          check(captured, combined);
          record = store.operations.find((item) => item.operationId === args.operationId);
          if (record?.kind === "retired") throw new OperationError("recovery_unavailable");
          try {
            digest = copyBytes(await digestIntent(material));
            if (digest.byteLength !== 32) throw new Error();
          } catch (error) {
            return safeBoundaryError(error);
          }
          check(captured, combined);
          compare(record, digest);
          acknowledged = record;
        } finally {
          releaseStore();
        }
        if (!record) {
          for (const exerciseId of new Set(args.exercises.map((entry) => entry.exerciseId))) {
            try {
              await visible(captured, exerciseId, combined);
            } catch (error) {
              if (isTransportError(error) && error.code === "not_found")
                throw new OperationError("invalid_reference");
              return safeBoundaryError(error);
            }
            check(captured, combined);
          }
          releaseStore = await storeLock.acquire(combined);
          try {
            check(captured, combined);
            const store = await load();
            check(captured, combined);
            record = store.operations.find((item) => item.operationId === args.operationId);
            compare(record, digest);
            if (!record) {
              record = createOperationCandidate(args, {
                binding: durableBinding,
                limits,
                intentDigest: digest,
                ...(generateUuid === undefined ? {} : { generateUuid }),
              });
              if (store.operations.some((item) => item.routineId === record?.routineId))
                throw new OperationError("internal_error");
              await persist(store, undefined, record, captured, combined);
              acknowledged = record;
              check(captured, combined);
            }
          } finally {
            releaseStore();
          }
        }
        check(captured, combined);
        let admitted = record;
        let live = true;
        const assertLive = (): void => {
          if (!live) return fail("operation_interrupted");
          check(captured, combined);
        };
        const retainedRecord = (store: OperationStore): OperationRecord => {
          const retained = store.operations.find(
            (item) => item.operationId === admitted.operationId,
          );
          if (!retained || JSON.stringify(retained) !== JSON.stringify(admitted)) {
            throw new OperationError("recovery_unavailable");
          }
          return retained;
        };
        const current = async (duringCallback = true): Promise<OperationRecord> => {
          const guard = (): void => {
            if (duringCallback) assertLive();
            else check(captured, combined);
          };
          guard();
          const release = await storeLock.acquire(combined);
          try {
            guard();
            // T04's binding remains a captured snapshot after generation change;
            // only an owner call proves current lease/generation/integrity.
            const store = await load();
            guard();
            return retainedRecord(store);
          } finally {
            release();
          }
        };
        const change = async (
          transform: (record: OperationRecord) => OperationRecord,
        ): Promise<void> => {
          assertLive();
          await probe(captured, combined);
          assertLive();
          const release = await storeLock.acquire(combined);
          try {
            assertLive();
            const store = await load();
            assertLive();
            const previous = retainedRecord(store);
            const next = transform(previous);
            if (next !== previous) {
              await persist(store, previous, next, captured, combined);
              admitted = next;
              acknowledged = next;
            }
            assertLive();
          } finally {
            release();
          }
        };
        // In-flight handle work cannot outlive exclusion or the owner claim.
        const tasks = new Set<Promise<unknown>>();
        const track = <R>(work: () => Promise<R>): Promise<R> => {
          const task = work();
          tasks.add(task);
          void task.then(
            () => tasks.delete(task),
            () => tasks.delete(task),
          );
          return task;
        };
        const handle: AdmittedOperation = Object.freeze({
          snapshot: () =>
            track(async () => {
              return validateOperationRecord(await current(), durableBinding);
            }),
          readStep: (step: OperationStepName) =>
            track(async () => {
              const retained = await current();
              if (retained.kind !== "journal") throw new OperationError("recovery_unavailable");
              return readOperationStep(retained, step);
            }),
          confirmationBaseline: () =>
            track(async () => {
              const retained = await current();
              return retained.kind === "journal" ? readConfirmationBaseline(retained) : null;
            }),
          recordDispatchPossible: (step: OperationStepName) =>
            track(async () => {
              const capturedStep = captureStep(step);
              await change((record) => dispatchPossible(record, capturedStep));
            }),
          recordConfirmation: (marker: ConfirmationMarker, terminal?: TerminalOperationResult) =>
            track(async () => {
              const capturedMarker = captureConfirmation(marker);
              const capturedTerminal =
                terminal === undefined ? undefined : captureTerminal(terminal);
              await change((record) => confirm(record, capturedMarker, capturedTerminal));
            }),
          settleTerminal: (result: TerminalOperationResult) =>
            track(async () => {
              const capturedResult = captureTerminal(result);
              await change((record) => settle(record, capturedResult));
            }),
          compactTerminal: () =>
            track(async () => {
              await change(compact);
            }),
        });
        const context = { active: true };
        let result: T | undefined;
        let failed = false;
        let failure: unknown;
        try {
          result = await callbackContext.run(context, () => work(handle));
        } catch (error) {
          failed = true;
          failure = error;
        } finally {
          live = false;
          const settling = await Promise.allSettled([...tasks]);
          for (const task of settling) {
            if (!failed && task.status === "rejected") {
              failed = true;
              failure = task.reason;
            }
          }
        }
        try {
          if (failed) return safeBoundaryError(failure);
          await current(false);
          return result as T;
        } finally {
          context.active = false;
        }
      } catch (error) {
        // Cancellation/close may land after commit and before the service's first snapshot.
        // Preserve only acknowledged history under the still-matching captured binding.
        if (acknowledged !== undefined) {
          try {
            if (
              equalBinding(captured, binding(owner.binding)) &&
              equalBinding(captured, binding(reads.binding))
            )
              rememberOperationFailure(error, captured, acknowledged, work);
          } catch {
            // Invalidated bindings never disclose captured history.
          }
        }
        throw error;
      } finally {
        unlock?.();
        lock.users -= 1;
        if (lock.users === 0) operationLocks.delete(args.operationId);
        pending -= 1;
        releaseClaim();
      }
    },
  });
}
