import { OperationError } from "./errors.js";
import { validateOperationRecord } from "./format.js";
import { captureJson } from "./json.js";
import { confirmationSchema, terminalSchema } from "./schema.js";
import type {
  ActiveJournal,
  ConfirmationMarker,
  OperationRecord,
  OperationStepName,
  TerminalOperationResult,
} from "./types.js";

const NAMES = ["draft", "populate", "save"] as const;
function invalidState(): never {
  throw new OperationError("invalid_state");
}
export function captureStep(value: unknown): OperationStepName {
  if (!NAMES.includes(value as OperationStepName)) throw new OperationError("invalid_arguments");
  return value as OperationStepName;
}
export function captureConfirmation(value: unknown): ConfirmationMarker {
  try {
    return confirmationSchema.parse(captureJson(value));
  } catch {
    throw new OperationError("invalid_arguments");
  }
}
export function captureTerminal(value: unknown): TerminalOperationResult {
  try {
    return terminalSchema.parse(captureJson(value)) as TerminalOperationResult;
  } catch {
    throw new OperationError("invalid_arguments");
  }
}
function validated(record: OperationRecord): OperationRecord {
  try {
    return validateOperationRecord(record, record.binding);
  } catch {
    return invalidState();
  }
}
function active(record: OperationRecord): ActiveJournal {
  if (record.kind !== "journal" || record.terminal !== null) return invalidState();
  return record;
}
function same(a: unknown, b: unknown): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}
function stepState(
  record: ActiveJournal,
  name: OperationStepName,
  state: "dispatch-possible" | "confirmed",
): ActiveJournal["steps"] {
  return record.steps.map((step) =>
    step.step === name ? { ...step, state } : step,
  ) as unknown as ActiveJournal["steps"];
}

export function dispatchPossible(
  record: OperationRecord,
  step: OperationStepName,
): OperationRecord {
  const journal = active(record);
  const next = journal.steps.find((item) => item.state !== "confirmed");
  if (!next || next.step !== step) return invalidState();
  if (next.state === "dispatch-possible") return record;
  return validated({ ...journal, steps: stepState(journal, step, "dispatch-possible") });
}

export function confirm(
  record: OperationRecord,
  marker: ConfirmationMarker,
  terminal?: TerminalOperationResult,
): OperationRecord {
  if (record.kind !== "journal") return invalidState();
  if (record.terminal !== null) {
    if (terminal !== undefined && same(marker, record.confirmed) && same(terminal, record.terminal))
      return record;
    return invalidState();
  }
  if (same(marker, record.confirmed)) {
    return terminal === undefined ? record : settle(record, terminal);
  }
  const next = record.steps.find((item) => item.state !== "confirmed");
  if (!next || next.step !== marker.step || next.state !== "dispatch-possible")
    return invalidState();
  return validated({
    ...record,
    steps: stepState(record, marker.step, "confirmed"),
    confirmed: marker,
    terminal: terminal ?? null,
  });
}

export function settle(
  record: OperationRecord,
  terminal: TerminalOperationResult,
): OperationRecord {
  if (record.kind === "receipt") return same(record.result, terminal) ? record : invalidState();
  if (record.kind !== "journal") return invalidState();
  if (record.terminal !== null) return same(record.terminal, terminal) ? record : invalidState();
  return validated({ ...record, terminal });
}

export function compact(record: OperationRecord): OperationRecord {
  if (record.kind === "receipt") return record;
  if (
    record.kind !== "journal" ||
    record.terminal === null ||
    (!record.terminal.ok && record.terminal.error.outcomeUnknown)
  )
    return invalidState();
  return validated({
    version: 1,
    kind: "receipt",
    binding: record.binding,
    operationId: record.operationId,
    routineId: record.routineId,
    intent: record.intent,
    maxResponseBytes: record.limits.maxResponseBytes,
    lastConfirmedStep: record.confirmed?.step ?? "none",
    result: record.terminal,
  });
}

export function retire(record: OperationRecord): OperationRecord {
  if (record.kind === "retired") return record;
  if (
    record.kind !== "journal" ||
    (record.terminal !== null && (record.terminal.ok || !record.terminal.error.outcomeUnknown))
  )
    return invalidState();
  return validated({
    version: 1,
    kind: "retired",
    binding: record.binding,
    operationId: record.operationId,
    routineId: record.routineId,
  });
}
