import { projectRevision } from "../domain/index.js";
import { OperationError } from "./errors.js";

export function unavailable(): never {
  throw new OperationError("recovery_unavailable");
}

/** Capture own data without getters/toJSON; reject holes, extra keys and cycles. */
export function captureJson(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return value;
  }
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }
  if (typeof value !== "object" || ancestors.has(value)) {
    return unavailable();
  }
  const array = Array.isArray(value);
  const proto: unknown = Object.getPrototypeOf(value);
  if (!array && proto !== Object.prototype && proto !== null) {
    return unavailable();
  }
  ancestors.add(value);
  try {
    const result: Record<string, unknown> | unknown[] = array ? [] : {};
    const keys = Reflect.ownKeys(value);
    if (array && keys.length !== value.length + 1) {
      return unavailable();
    }
    for (const key of keys) {
      if (array && key === "length") {
        continue;
      }
      if (typeof key !== "string") {
        return unavailable();
      }
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (descriptor === undefined || !("value" in descriptor) || !descriptor.enumerable) {
        return unavailable();
      }
      if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= value.length)) {
        return unavailable();
      }
      Object.defineProperty(result, key, {
        value: captureJson(descriptor.value as unknown, ancestors),
        enumerable: true,
        configurable: true,
        writable: true,
      });
    }
    return result;
  } finally {
    ancestors.delete(value);
  }
}

export function copyBytes(value: unknown): Uint8Array {
  if (!(value instanceof Uint8Array)) {
    return unavailable();
  }
  const getter = Object.getOwnPropertyDescriptor(
    Object.getPrototypeOf(Uint8Array.prototype),
    "buffer",
  )?.get;
  if (getter === undefined || Reflect.apply(getter, value, []) instanceof SharedArrayBuffer) {
    return unavailable();
  }
  return new Uint8Array(value);
}

export function textFromBytes(value: unknown): string {
  const bytes = copyBytes(value);
  if (bytes[0] === 0xef && bytes[1] === 0xbb && bytes[2] === 0xbf) {
    return unavailable();
  }
  return new TextDecoder("utf-8", { fatal: true }).decode(bytes);
}

export function decodeBase64(value: string): Uint8Array {
  const bytes = Buffer.from(value, "base64");
  if (bytes.toString("base64") !== value) {
    return unavailable();
  }
  return new Uint8Array(bytes);
}

const INTEGER_FIELDS: ReadonlySet<string> = new Set([
  "version",
  "maxRequestBytes",
  "maxResponseBytes",
  "reservationBytes",
  "retryAfterSeconds",
  "position",
  "restDurationSeconds",
  "repetitions",
]);

/** Native parsing with exact integer-token checks, followed by duplicate-key scan. */
export function parseJson(text: string): unknown {
  const parsed: unknown = JSON.parse(
    text,
    (key: string, value: unknown, context?: { source?: string }) => {
      if (typeof value === "number") {
        if (!Number.isFinite(value)) {
          return unavailable();
        }
        if (INTEGER_FIELDS.has(key)) {
          const source = context?.source;
          if (source === undefined || !Number.isSafeInteger(value) || value < 0) {
            return unavailable();
          }
          if (value === 0) {
            if (!/^-?0(?:\.0+)?(?:[eE][+-]?[0-9]+)?$/.test(source)) {
              return unavailable();
            }
          } else if (projectRevision(source) !== String(value)) {
            return unavailable();
          }
        }
      }
      return value;
    },
  );
  // JSON.parse already establishes grammar. This scan only tracks object keys;
  // escaped string tokens are decoded before comparing them ("a" == "\\u0061").
  const stack: Array<Set<string> | null> = [];
  for (let offset = 0; offset < text.length; offset += 1) {
    const char = text[offset];
    if (char === "{") {
      stack.push(new Set());
    } else if (char === "[") {
      stack.push(null);
    } else if (char === "}" || char === "]") {
      stack.pop();
    } else if (char === '"') {
      const start = offset;
      offset += 1;
      while (text[offset] !== '"') {
        offset += text[offset] === "\\" ? 2 : 1;
      }
      let next = offset + 1;
      while (/\s/.test(text[next] ?? "x")) {
        next += 1;
      }
      if (text[next] === ":") {
        const key: unknown = JSON.parse(text.slice(start, offset + 1));
        const keys = stack[stack.length - 1];
        if (typeof key !== "string" || keys == null || keys.has(key)) {
          return unavailable();
        }
        keys.add(key);
      }
    }
  }
  return parsed;
}

export function jsonBytes(value: unknown): Uint8Array {
  return new TextEncoder().encode(JSON.stringify(value));
}
