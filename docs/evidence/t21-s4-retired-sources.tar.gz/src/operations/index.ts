/**
 * T09 format and guarded admission boundary. Imports never open a profile or
 * send a request. Candidate construction alone does not admit an operation.
 */
export { OperationError, isOperationError } from "./errors.js";
export { openOperationRepository } from "./repository.js";
export type {
  OperationAdmissionReads,
  OperationRepositoryOptions,
  OperationRepository,
  AdmittedOperation,
} from "./repository.js";
export type { OperationErrorCode } from "./errors.js";
export { operationIntentMaterial, createOperationCandidate } from "./candidate.js";
export {
  JOURNAL_VERSION,
  OPERATION_STORE_VERSION,
  validateOperationRecord,
  encodeOperationStore,
  decodeOperationStore,
  readOperationStep,
  readConfirmationBaseline,
  measureOperationStore,
} from "./format.js";
export type {
  OperationBinding,
  OperationLimits,
  IntentIdentity,
  OperationStepName,
  LastConfirmedStep,
  OperationStepState,
  OperationStep,
  ConfirmationMarker,
  PermanentOperationCode,
  TerminalOperationError,
  TerminalOperationResult,
  ActiveJournal,
  OperationReceipt,
  RetiredOperation,
  OperationRecord,
  OperationStore,
  CandidateOptions,
  StoredOperationRequest,
  ConfirmationBaseline,
  OperationStoreSize,
} from "./types.js";
