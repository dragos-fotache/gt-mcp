/** Private, process-local recovery context. Never attached to serialized error objects. */
import type { StorageBinding } from "../storage/index.js";
import type { LastConfirmedStep, OperationRecord } from "./types.js";

export interface OperationFailureContext {
  readonly operationId: string;
  readonly routineId: string;
  readonly lastConfirmedStep: LastConfirmedStep;
  readonly outcomeUnknown: boolean;
}

const contexts = new WeakMap<
  object,
  WeakMap<object, { readonly binding: StorageBinding; readonly history: OperationFailureContext }>
>();

function same(a: StorageBinding, b: StorageBinding): boolean {
  return (
    a.origin === b.origin &&
    a.accountUuid === b.accountUuid &&
    a.sessionGeneration === b.sessionGeneration &&
    a.profileGenerationId === b.profileGenerationId
  );
}

export function rememberOperationFailure(
  error: unknown,
  binding: StorageBinding,
  record: OperationRecord,
  invocation: object,
): void {
  if (typeof error !== "object" || error === null || record.kind === "retired") return;
  const terminal = record.kind === "receipt" ? record.result : record.terminal;
  const calls = contexts.get(error) ?? new WeakMap();
  contexts.set(error, calls);
  calls.set(invocation, {
    binding: { ...binding },
    history: Object.freeze({
      operationId: record.operationId,
      routineId: record.routineId,
      lastConfirmedStep:
        record.kind === "receipt" ? record.lastConfirmedStep : (record.confirmed?.step ?? "none"),
      outcomeUnknown:
        terminal !== null
          ? !terminal.ok && terminal.error.outcomeUnknown
          : record.kind === "journal" &&
            record.steps.some((step) => step.state === "dispatch-possible"),
    }),
  });
}

export function operationFailureContext(
  error: unknown,
  binding: StorageBinding,
  invocation: object,
): OperationFailureContext | undefined {
  if (typeof error !== "object" || error === null) return undefined;
  const context = contexts.get(error)?.get(invocation);
  return context !== undefined && same(context.binding, binding) ? context.history : undefined;
}
