import { randomUUID } from "node:crypto";
import { buildRoutineInput, intentIdentityMaterial, parseArguments } from "../domain/index.js";
import { OperationError } from "./errors.js";
import { journalReservation, parseBinding, validateOperationRecord } from "./format.js";
import { copyBytes, captureJson, jsonBytes } from "./json.js";
import { limitsSchema, uuidSchema } from "./schema.js";
import type { ActiveJournal, CandidateOptions, OperationStep } from "./types.js";

/** Temporary legacy lifecycle boundary; the public tool rejects operationId. */
export function parseLegacyOperationInput(input: unknown) {
  const captured = captureJson(input) as Record<string, unknown>;
  const { operationId, ...intent } = captured;
  const id = uuidSchema.parse(operationId);
  return { ...parseArguments("create_routine", intent), operationId: id };
}

export function operationIntentMaterial(input: unknown): Uint8Array {
  try {
    const args = parseLegacyOperationInput(input);
    const intent = { name: args.name, exercises: args.exercises };
    const material = intentIdentityMaterial(intent);
    return new TextEncoder().encode(`${material.version}\0${material.canonicalJson}`);
  } catch {
    throw new OperationError("invalid_arguments");
  }
}

export function createOperationCandidate(input: unknown, options: CandidateOptions): ActiveJournal {
  let generate: () => string;
  let args;
  let binding;
  let limits;
  let digest: Uint8Array;
  try {
    args = parseLegacyOperationInput(input);
    if (
      options === null ||
      typeof options !== "object" ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(options) as object | null)
    ) {
      throw new OperationError("invalid_arguments");
    }
    const fields: Record<string, unknown> = {};
    for (const key of Reflect.ownKeys(options)) {
      const descriptor = Object.getOwnPropertyDescriptor(options, key);
      if (
        typeof key !== "string" ||
        !["binding", "limits", "intentDigest", "generateUuid"].includes(key) ||
        descriptor === undefined ||
        !("value" in descriptor)
      ) {
        throw new OperationError("invalid_arguments");
      }
      fields[key] = descriptor.value as unknown;
    }
    binding = parseBinding(fields["binding"]);
    limits = limitsSchema.parse(captureJson(fields["limits"]));
    digest = copyBytes(fields["intentDigest"]);
    if (
      digest.byteLength !== 32 ||
      ("generateUuid" in fields && typeof fields["generateUuid"] !== "function")
    ) {
      throw new OperationError("invalid_arguments");
    }
    generate = (fields["generateUuid"] ?? randomUUID) as () => string;
  } catch {
    throw new OperationError("invalid_arguments");
  }
  const familyIds = new Set<string>();
  const resourceKeys = new Set<string>();
  const allocate = (seen: Set<string> = familyIds): string => {
    try {
      const value = uuidSchema.parse(generate());
      if (seen.has(value)) {
        throw new OperationError("internal_error");
      }
      seen.add(value);
      return value;
    } catch {
      throw new OperationError("internal_error");
    }
  };
  const routineId = allocate();
  const identities = {
    routineId,
    exercises: args.exercises.map((entry) => ({
      id: allocate(),
      setIds: entry.sets.map(() => allocate()),
    })),
  };
  const intent = { name: args.name, exercises: args.exercises };
  const populate = buildRoutineInput(intent, identities);
  const bodies = [
    jsonBytes({ id: routineId }),
    jsonBytes(populate),
    jsonBytes({ name: args.name }),
  ];
  if (bodies.some((body) => body.byteLength > limits.maxRequestBytes)) {
    throw new OperationError("request_too_large");
  }
  const names = ["draft", "populate", "save"] as const;
  const steps = bodies.map((body, index): OperationStep => ({
    step: names[index] ?? "draft",
    method: index === 1 ? "PUT" : "POST",
    route: index === 0 ? "/v1/routines" : `/v1/routines/${routineId}${index === 2 ? "/save" : ""}`,
    resourceKey: allocate(resourceKeys),
    bodyBase64: Buffer.from(body).toString("base64"),
    state: "unsent",
  })) as unknown as ActiveJournal["steps"];
  const journal: ActiveJournal = {
    version: 1,
    kind: "journal",
    binding,
    operationId: args.operationId,
    routineId,
    intent: {
      version: "gymtracka-create-intent-v1",
      digestKeyVersion: "gymtracka-digest-v1",
      digestBase64: Buffer.from(digest).toString("base64"),
    },
    limits,
    reservationBytes: 0,
    steps,
    confirmed: null,
    terminal: null,
  };
  return validateOperationRecord(
    { ...journal, reservationBytes: journalReservation(journal) },
    binding,
  ) as ActiveJournal;
}
