import { z } from "zod";
import { projectRevision } from "../domain/index.js";

export const uuidSchema = z
  .string()
  .regex(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![\s\S])/);
export const bindingSchema = z.strictObject({
  origin: z.string().refine((value) => {
    try {
      const url = new URL(value);
      return url.protocol === "https:" && url.origin === value && !url.username && !url.password;
    } catch {
      return false;
    }
  }),
  accountUuid: uuidSchema,
  profileGenerationId: uuidSchema,
});
const budgetSchema = z.number().int().min(64).max(16777216);
export const limitsSchema = z.strictObject({
  maxRequestBytes: budgetSchema,
  maxResponseBytes: budgetSchema,
});
const intentSchema = z.strictObject({
  version: z.literal("gymtracka-create-intent-v1"),
  digestKeyVersion: z.literal("gymtracka-digest-v1"),
  digestBase64: z.string().regex(/^[A-Za-z0-9+/]{43}=(?![\s\S])/),
});
const stepNameSchema = z.enum(["draft", "populate", "save"]);
const lastStepSchema = z.enum(["none", "draft", "populate", "save"]);
const stepSchema = z.strictObject({
  step: stepNameSchema,
  method: z.enum(["POST", "PUT"]),
  route: z.string(),
  resourceKey: uuidSchema,
  bodyBase64: z.string(),
  state: z.enum(["unsent", "dispatch-possible", "confirmed"]),
});
export const confirmationSchema = z.strictObject({
  step: stepNameSchema,
  revision: z.string().refine((value) => {
    try {
      return /^[1-9][0-9]*$/.test(value) && projectRevision(value) === value;
    } catch {
      return false;
    }
  }),
});
export const terminalSchema = z.discriminatedUnion("ok", [
  z.strictObject({
    ok: z.literal(true),
    data: z.strictObject({
      operationId: uuidSchema,
      routineId: uuidSchema,
      status: z.literal("saved"),
    }),
  }),
  z.strictObject({
    ok: z.literal(false),
    error: z.strictObject({
      code: z.enum([
        "not_found",
        "invalid_reference",
        "validation_error",
        "invalid_state",
        "id_collision",
        "read_only",
        "idempotency_key_reused",
        "concurrent_modification",
        "backend_error",
        "request_too_large",
        "result_too_large",
      ]),
      retryable: z.literal(false),
      operationId: uuidSchema,
      routineId: uuidSchema,
      lastConfirmedStep: lastStepSchema,
      outcomeUnknown: z.boolean(),
      message: z.literal("Routine creation failed.").optional(),
      backendErrorCode: z
        .string()
        .regex(/^[a-z][a-z0-9_]*(?![\s\S])/)
        .refine((value) => !/[0-9a-f]{32,}/.test(value))
        .optional(),
      retryAfterSeconds: z.number().int().positive().max(Number.MAX_SAFE_INTEGER).optional(),
    }),
  }),
]);
const common = {
  version: z.literal(1),
  binding: bindingSchema,
  operationId: uuidSchema,
  routineId: uuidSchema,
};
export const recordSchema = z.discriminatedUnion("kind", [
  z.strictObject({
    ...common,
    kind: z.literal("journal"),
    intent: intentSchema,
    limits: limitsSchema,
    reservationBytes: z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER),
    steps: z.tuple([stepSchema, stepSchema, stepSchema]),
    confirmed: confirmationSchema.nullable(),
    terminal: terminalSchema.nullable(),
  }),
  z.strictObject({
    ...common,
    kind: z.literal("receipt"),
    intent: intentSchema,
    maxResponseBytes: budgetSchema,
    lastConfirmedStep: lastStepSchema,
    result: terminalSchema,
  }),
  z.strictObject({ ...common, kind: z.literal("retired") }),
]);
export const storeSchema = z.strictObject({
  version: z.literal(1),
  binding: bindingSchema,
  operations: z.array(recordSchema),
});
