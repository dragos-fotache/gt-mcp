import { buildRoutineInput, makeToolResult, type RoutineInput } from "../domain/index.js";
import { MAX_STORE_BYTES } from "../storage/index.js";
import { OperationError } from "./errors.js";
import {
  captureJson,
  copyBytes,
  decodeBase64,
  jsonBytes,
  parseJson,
  textFromBytes,
  unavailable,
} from "./json.js";
import { bindingSchema, recordSchema, storeSchema } from "./schema.js";
import type {
  ActiveJournal,
  ConfirmationBaseline,
  LastConfirmedStep,
  OperationBinding,
  OperationRecord,
  OperationStepName,
  OperationStore,
  OperationStoreSize,
  StoredOperationRequest,
  TerminalOperationResult,
} from "./types.js";

export const JOURNAL_VERSION = 1 as const;
export const OPERATION_STORE_VERSION = 1 as const;
const STEP_NAMES = ["draft", "populate", "save"] as const;

export function checked<T>(work: () => T): T {
  try {
    return work();
  } catch (error) {
    if (error instanceof OperationError) {
      throw error;
    }
    return unavailable();
  }
}

export function parseBinding(value: unknown): OperationBinding {
  return bindingSchema.parse(captureJson(value));
}

function sameBinding(a: OperationBinding, b: OperationBinding): boolean {
  return (
    a.origin === b.origin &&
    a.accountUuid === b.accountUuid &&
    a.profileGenerationId === b.profileGenerationId
  );
}

/** Comparison only. Never used to regenerate stored dispatch bytes. */
function comparable(value: unknown): string {
  if (Array.isArray(value)) {
    return `[${value.map(comparable).join(",")}]`;
  }
  if (value !== null && typeof value === "object") {
    const record = value as Record<string, unknown>;
    return `{${Object.keys(record)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${comparable(record[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

function equalBody(actual: unknown, expected: unknown): void {
  if (comparable(actual) !== comparable(expected)) {
    unavailable();
  }
}

function object(value: unknown): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    return unavailable();
  }
  return value as Record<string, unknown>;
}

/** Recover the whitelisted admitted domain for validation/comparison, not replay. */
export function populateDomain(journal: ActiveJournal): RoutineInput {
  const body = object(parseJson(textFromBytes(decodeBase64(journal.steps[1].bodyBase64))));
  const exercises = body["exercises"];
  if (!Array.isArray(exercises)) {
    return unavailable();
  }
  const entries = exercises.map((value: unknown) => {
    const entry = object(value);
    const sets = entry["sets"];
    if (!Array.isArray(sets)) {
      return unavailable();
    }
    return { entry, sets: sets.map((set: unknown) => object(set)) };
  });
  const args = {
    operationId: journal.operationId,
    name: body["name"],
    exercises: entries.map(({ entry, sets }) => ({
      exerciseId: entry["exerciseId"],
      restDurationSeconds: entry["restDurationSeconds"],
      sets: sets.map((set) => ({ repetitions: set["repetitions"], weightKg: set["weightKg"] })),
    })),
  };
  const identities = {
    routineId: journal.routineId,
    exercises: entries.map(({ entry, sets }) => ({
      id: entry["id"],
      setIds: sets.map((set) => set["id"]),
    })),
  };
  const intent = { name: args.name, exercises: args.exercises };
  const expected = buildRoutineInput(intent, identities);
  equalBody(body, expected);
  return expected;
}

/** Bound encoded growth independently of current confirmation/terminal state. */
export function journalReservation(journal: ActiveJournal): number {
  const initial: ActiveJournal = {
    ...journal,
    reservationBytes: 0,
    steps: journal.steps.map((step) => ({
      ...step,
      state: "unsent" as const,
    })) as unknown as ActiveJournal["steps"],
    confirmed: null,
    terminal: null,
  };
  return jsonBytes(initial).byteLength + journal.limits.maxResponseBytes + 2048;
}

function validateTerminal(
  result: TerminalOperationResult,
  record: { readonly operationId: string; readonly routineId: string },
  last: LastConfirmedStep,
  responseBudget: number,
): void {
  const fields: Record<string, unknown> = { ...(result.ok ? result.data : result.error) };
  delete fields["operationId"];
  makeToolResult(
    "create_routine",
    result.ok ? { ok: true, data: fields } : { ok: false, error: { ...fields, retryable: false } },
  );
  const identity = result.ok ? result.data : result.error;
  if (identity.operationId !== record.operationId || identity.routineId !== record.routineId) {
    unavailable();
  }
  if (result.ok) {
    if (last !== "save") {
      unavailable();
    }
  } else {
    if (result.error.lastConfirmedStep !== last) {
      unavailable();
    }
    if (
      last === "save" &&
      (result.error.code !== "concurrent_modification" || result.error.outcomeUnknown)
    ) {
      unavailable();
    }
  }
  if (jsonBytes(result).byteLength > responseBudget + 1024) {
    unavailable();
  }
}

function validateRecord(record: OperationRecord, expectedBinding: OperationBinding): void {
  if (!sameBinding(record.binding, expectedBinding)) {
    unavailable();
  }
  if (record.kind === "retired") {
    return;
  }
  if (decodeBase64(record.intent.digestBase64).byteLength !== 32) {
    unavailable();
  }
  if (record.kind === "receipt") {
    validateTerminal(record.result, record, record.lastConfirmedStep, record.maxResponseBytes);
    if (!record.result.ok && record.result.error.outcomeUnknown) {
      unavailable();
    }
    return;
  }
  const keys = new Set<string>();
  let last: LastConfirmedStep = "none";
  let unconfirmed = false;
  let possible = false;
  for (const [index, step] of record.steps.entries()) {
    const method = index === 1 ? "PUT" : "POST";
    const route =
      index === 0
        ? "/v1/routines"
        : `/v1/routines/${record.routineId}${index === 2 ? "/save" : ""}`;
    if (
      step.step !== STEP_NAMES[index] ||
      step.method !== method ||
      step.route !== route ||
      keys.has(step.resourceKey)
    ) {
      unavailable();
    }
    keys.add(step.resourceKey);
    const bytes = decodeBase64(step.bodyBase64);
    if (bytes.byteLength > record.limits.maxRequestBytes) {
      unavailable();
    }
    if (step.state === "confirmed") {
      if (unconfirmed) {
        unavailable();
      }
      last = step.step;
    } else {
      if (step.state === "dispatch-possible") {
        if (unconfirmed) {
          unavailable();
        }
        possible = true;
      }
      unconfirmed = true;
    }
  }
  if ((record.confirmed?.step ?? "none") !== last) {
    unavailable();
  }
  const populate = populateDomain(record);
  equalBody(parseJson(textFromBytes(decodeBase64(record.steps[0].bodyBase64))), {
    id: record.routineId,
  });
  equalBody(parseJson(textFromBytes(decodeBase64(record.steps[2].bodyBase64))), {
    name: populate.name,
  });
  if (record.terminal !== null) {
    validateTerminal(record.terminal, record, last, record.limits.maxResponseBytes);
    if (!record.terminal.ok && record.terminal.error.outcomeUnknown && !possible) {
      unavailable();
    }
  }
  if (
    record.reservationBytes !== journalReservation(record) ||
    jsonBytes(record).byteLength > record.reservationBytes
  ) {
    unavailable();
  }
  if (record.reservationBytes > MAX_STORE_BYTES) {
    throw new OperationError("resource_exhausted");
  }
}

export function validateOperationRecord(
  value: unknown,
  expectedBinding: OperationBinding,
): OperationRecord {
  return checked(() => {
    const binding = parseBinding(expectedBinding);
    // Capture rejects explicit undefined, so optional Zod outputs are absent,
    // matching the exactOptionalPropertyTypes public shape.
    const record = recordSchema.parse(captureJson(value)) as OperationRecord;
    validateRecord(record, binding);
    return record;
  });
}

function validatedStore(value: unknown, expectedBinding?: OperationBinding): OperationStore {
  const store = storeSchema.parse(captureJson(value)) as OperationStore;
  if (expectedBinding !== undefined && !sameBinding(store.binding, parseBinding(expectedBinding))) {
    unavailable();
  }
  const ids = new Set<string>();
  const roots = new Set<string>();
  for (const record of store.operations) {
    if (ids.has(record.operationId) || roots.has(record.routineId)) {
      unavailable();
    }
    ids.add(record.operationId);
    roots.add(record.routineId);
    validateRecord(record, store.binding);
  }
  return store;
}

function storeSize(store: OperationStore): OperationStoreSize {
  const encodedBytes = jsonBytes(store).byteLength;
  let reservedBytes = jsonBytes({
    version: OPERATION_STORE_VERSION,
    binding: store.binding,
    operations: [],
  }).byteLength;
  for (const [index, record] of store.operations.entries()) {
    reservedBytes +=
      (record.kind === "journal" ? record.reservationBytes : jsonBytes(record).byteLength) +
      (index === 0 ? 0 : 1);
    if (!Number.isSafeInteger(reservedBytes) || reservedBytes > MAX_STORE_BYTES) {
      throw new OperationError("resource_exhausted");
    }
  }
  if (encodedBytes > MAX_STORE_BYTES || reservedBytes > MAX_STORE_BYTES) {
    throw new OperationError("resource_exhausted");
  }
  return { encodedBytes, reservedBytes, remainingBytes: MAX_STORE_BYTES - reservedBytes };
}

export function measureOperationStore(value: unknown): OperationStoreSize {
  return checked(() => storeSize(validatedStore(value)));
}

export function encodeOperationStore(value: unknown): Uint8Array {
  return checked(() => {
    const store = validatedStore(value);
    storeSize(store);
    return jsonBytes(store);
  });
}

export function decodeOperationStore(
  bytes: Uint8Array,
  expectedBinding: OperationBinding,
): OperationStore {
  return checked(() => {
    const captured = copyBytes(bytes);
    if (captured.byteLength > MAX_STORE_BYTES) {
      throw new OperationError("resource_exhausted");
    }
    const text = textFromBytes(captured);
    const store = validatedStore(
      text.length === 0
        ? { version: 1, binding: expectedBinding, operations: [] }
        : parseJson(text),
      expectedBinding,
    );
    storeSize(store);
    return store;
  });
}

export function readOperationStep(
  journal: ActiveJournal,
  step: OperationStepName,
): StoredOperationRequest {
  return checked(() => {
    if (!STEP_NAMES.includes(step)) {
      throw new OperationError("invalid_arguments");
    }
    const captured = object(captureJson(journal));
    const record = validateOperationRecord(captured, parseBinding(captured["binding"]));
    if (record.kind !== "journal") {
      return unavailable();
    }
    const selected = record.steps[STEP_NAMES.indexOf(step)];
    if (selected === undefined) {
      return unavailable();
    }
    return {
      method: selected.method,
      route: selected.route,
      resourceKey: selected.resourceKey,
      body: decodeBase64(selected.bodyBase64),
    };
  });
}

export function readConfirmationBaseline(journal: ActiveJournal): ConfirmationBaseline | null {
  return checked(() => {
    const captured = object(captureJson(journal));
    const record = validateOperationRecord(captured, parseBinding(captured["binding"]));
    if (record.kind !== "journal") {
      return unavailable();
    }
    if (record.confirmed === null || record.terminal !== null) {
      return null;
    }
    const draft = record.confirmed.step === "draft";
    const domain = populateDomain(record);
    return {
      id: record.routineId,
      name: draft ? "" : domain.name,
      isDraft: record.confirmed.step !== "save",
      exercises: draft ? [] : domain.exercises,
      revision: record.confirmed.revision,
    };
  });
}
