/** Durable identity deliberately excludes the invocation's session generation. */
export interface OperationBinding {
  readonly origin: string;
  readonly accountUuid: string;
  readonly profileGenerationId: string;
}

export interface OperationLimits {
  readonly maxRequestBytes: number;
  readonly maxResponseBytes: number;
}

export interface IntentIdentity {
  readonly version: "gymtracka-create-intent-v1";
  readonly digestKeyVersion: "gymtracka-digest-v1";
  readonly digestBase64: string;
}

export type OperationStepName = "draft" | "populate" | "save";
export type LastConfirmedStep = "none" | OperationStepName;
export type OperationStepState = "unsent" | "dispatch-possible" | "confirmed";

export interface OperationStep {
  readonly step: OperationStepName;
  readonly method: "POST" | "PUT";
  readonly route: string;
  readonly resourceKey: string;
  readonly bodyBase64: string;
  readonly state: OperationStepState;
}

export interface ConfirmationMarker {
  readonly step: OperationStepName;
  readonly revision: string;
}

export type PermanentOperationCode =
  | "not_found"
  | "invalid_reference"
  | "validation_error"
  | "invalid_state"
  | "id_collision"
  | "read_only"
  | "idempotency_key_reused"
  | "concurrent_modification"
  | "backend_error"
  | "request_too_large"
  | "result_too_large";

export interface TerminalOperationError {
  readonly code: PermanentOperationCode;
  readonly retryable: false;
  readonly operationId: string;
  readonly routineId: string;
  readonly lastConfirmedStep: LastConfirmedStep;
  readonly outcomeUnknown: boolean;
  readonly message?: "Routine creation failed.";
  readonly backendErrorCode?: string;
  readonly retryAfterSeconds?: number;
}

export type TerminalOperationResult =
  | {
      readonly ok: true;
      readonly data: {
        readonly operationId: string;
        readonly routineId: string;
        readonly status: "saved";
      };
    }
  | { readonly ok: false; readonly error: TerminalOperationError };

export interface ActiveJournal {
  readonly version: 1;
  readonly kind: "journal";
  readonly binding: OperationBinding;
  readonly operationId: string;
  readonly routineId: string;
  readonly intent: IntentIdentity;
  readonly limits: OperationLimits;
  readonly reservationBytes: number;
  readonly steps: readonly [OperationStep, OperationStep, OperationStep];
  readonly confirmed: ConfirmationMarker | null;
  readonly terminal: TerminalOperationResult | null;
}

export interface OperationReceipt {
  readonly version: 1;
  readonly kind: "receipt";
  readonly binding: OperationBinding;
  readonly operationId: string;
  readonly routineId: string;
  readonly intent: IntentIdentity;
  readonly maxResponseBytes: number;
  readonly lastConfirmedStep: LastConfirmedStep;
  readonly result: TerminalOperationResult;
}

export interface RetiredOperation {
  readonly version: 1;
  readonly kind: "retired";
  readonly binding: OperationBinding;
  readonly operationId: string;
  readonly routineId: string;
}

export type OperationRecord = ActiveJournal | OperationReceipt | RetiredOperation;

export interface OperationStore {
  readonly version: 1;
  readonly binding: OperationBinding;
  readonly operations: readonly OperationRecord[];
}

export interface CandidateOptions {
  readonly binding: OperationBinding;
  readonly limits: OperationLimits;
  readonly intentDigest: Uint8Array;
  readonly generateUuid?: () => string;
}

export interface StoredOperationRequest {
  readonly method: "POST" | "PUT";
  readonly route: string;
  readonly resourceKey: string;
  readonly body: Uint8Array;
}

export interface ConfirmationBaseline {
  readonly id: string;
  readonly name: string;
  readonly isDraft: boolean;
  readonly exercises: readonly import("../domain/index.js").RoutineInputEntry[];
  readonly revision: string;
}

export interface OperationStoreSize {
  readonly encodedBytes: number;
  readonly reservedBytes: number;
  readonly remainingBytes: number;
}
