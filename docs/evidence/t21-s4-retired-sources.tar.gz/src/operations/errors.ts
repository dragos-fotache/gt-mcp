export type OperationErrorCode =
  | "invalid_arguments"
  | "recovery_unavailable"
  | "request_too_large"
  | "resource_exhausted"
  | "configuration_required"
  | "operation_id_reused"
  | "operation_interrupted"
  | "invalid_reference"
  | "invalid_state"
  | "internal_error";

const CODES: ReadonlySet<string> = new Set([
  "invalid_arguments",
  "recovery_unavailable",
  "request_too_large",
  "resource_exhausted",
  "configuration_required",
  "operation_id_reused",
  "operation_interrupted",
  "invalid_reference",
  "invalid_state",
  "internal_error",
]);

/** No caller-controlled diagnostics, native causes, payloads or stack paths. */
export class OperationError extends Error {
  readonly code: OperationErrorCode;

  constructor(code: OperationErrorCode) {
    const safeCode = CODES.has(code) ? code : "invalid_arguments";
    super(`Operation failure: ${safeCode}.`);
    this.name = "OperationError";
    this.code = safeCode;
    this.stack = `${this.name}: ${this.message}`;
  }
}

export function isOperationError(value: unknown): value is OperationError {
  return value instanceof OperationError;
}
