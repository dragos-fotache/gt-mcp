/** Credential-free external removal fences; readable after destruction of the master key. */
import { Buffer } from "node:buffer";
import { parseStrictMetadataJson } from "../runtime/files.js";
import { StorageError } from "./errors.js";
import { assertBinding, assertUuid, captureShape, requiredField } from "./validate.js";
import type { StorageBinding } from "./types.js";

export interface RemovalRoot {
  readonly path: string;
  readonly dev: string;
  readonly ino: string;
}
export interface RemovalFence {
  readonly version: 1;
  readonly phase: "pending" | "complete";
  readonly profileGenerationId: string;
  readonly profile: RemovalRoot;
  readonly anchor: RemovalRoot;
  readonly lock: { readonly dev: string; readonly ino: string };
  readonly euid: number;
  readonly files?: ReadonlyArray<{
    readonly root: "profile" | "anchor";
    readonly name: string;
    readonly dev: string;
    readonly ino: string;
    readonly digest: string;
    readonly ctimeNs: string;
  }>;
  readonly binding?: StorageBinding;
  readonly keyDigest?: string;
}

export function removalName(generationId: string): string {
  return `removed.${assertUuid(generationId)}.json`;
}

function identity(value: unknown, withPath: boolean): RemovalRoot {
  const r = captureShape(value, withPath ? ["path", "dev", "ino"] : ["dev", "ino"]);
  const dev = requiredField(r, "dev");
  const ino = requiredField(r, "ino");
  const selectedPath = withPath ? requiredField(r, "path") : "";
  if (
    typeof dev !== "string" ||
    typeof ino !== "string" ||
    !/^(0|[1-9][0-9]*)$/.test(dev) ||
    !/^(0|[1-9][0-9]*)$/.test(ino) ||
    typeof selectedPath !== "string"
  )
    throw new StorageError("fence_mismatch");
  return { path: selectedPath, dev, ino };
}

export function parseRemovalFence(bytes: Uint8Array): RemovalFence {
  try {
    const raw = parseStrictMetadataJson(bytes);
    const pending = raw["phase"] === "pending";
    const r = captureShape(raw, [
      "version",
      "phase",
      "profileGenerationId",
      "profile",
      "anchor",
      "lock",
      "euid",
      ...(pending ? ["binding", "keyDigest", "files"] : []),
    ]);
    if (
      requiredField(r, "version") !== 1 ||
      !["pending", "complete"].includes(raw["phase"] as string)
    )
      throw new StorageError("fence_mismatch");
    const profileGenerationId = assertUuid(requiredField(r, "profileGenerationId"));
    const uid = requiredField(r, "euid");
    if (typeof uid !== "number" || !Number.isSafeInteger(uid) || uid < 0)
      throw new StorageError("fence_mismatch");
    const common = {
      version: 1 as const,
      phase: pending ? ("pending" as const) : ("complete" as const),
      profileGenerationId,
      profile: identity(requiredField(r, "profile"), true),
      anchor: identity(requiredField(r, "anchor"), true),
      lock: (({ dev, ino }) => ({ dev, ino }))(identity(requiredField(r, "lock"), false)),
      euid: uid,
    };
    if (!pending) return common;
    const binding = assertBinding(requiredField(r, "binding"));
    const keyDigest = requiredField(r, "keyDigest");
    if (
      binding.profileGenerationId !== profileGenerationId ||
      typeof keyDigest !== "string" ||
      !/^[0-9a-f]{64}$/.test(keyDigest)
    )
      throw new StorageError("fence_mismatch");
    const rawFiles = requiredField(r, "files");
    if (!Array.isArray(rawFiles) || rawFiles.length > 128) throw new StorageError("fence_mismatch");
    const files = rawFiles.map((value: unknown): NonNullable<RemovalFence["files"]>[number] => {
      const f = captureShape(value, ["root", "name", "dev", "ino", "digest", "ctimeNs"]);
      const root = requiredField(f, "root"),
        name = requiredField(f, "name"),
        digest = requiredField(f, "digest"),
        ctimeNs = requiredField(f, "ctimeNs");
      const id = identity({ dev: requiredField(f, "dev"), ino: requiredField(f, "ino") }, false);
      if (
        (root !== "profile" && root !== "anchor") ||
        typeof name !== "string" ||
        !(
          root === "profile"
            ? /^(?:vault\.bin|operations\.bin|\.(?:vault\.bin|operations\.bin)\.[0-9]+\.[0-9]+\.[0-9a-f]+\.tmp)$/
            : /^(?:anchor\.bin|\.anchor\.bin\.[0-9]+\.[0-9]+\.[0-9a-f]+\.tmp)$/
        ).test(name) ||
        typeof ctimeNs !== "string" ||
        !/^(0|[1-9][0-9]*)$/.test(ctimeNs) ||
        typeof digest !== "string" ||
        !/^[0-9a-f]{64}$/.test(digest)
      )
        throw new StorageError("fence_mismatch");
      return { root, name, dev: id.dev, ino: id.ino, digest, ctimeNs };
    });
    if (new Set(files.map((f) => `${f.root}/${f.name}`)).size !== files.length)
      throw new StorageError("fence_mismatch");
    for (const [root, name] of [
      ["profile", "vault.bin"],
      ["profile", "operations.bin"],
      ["anchor", "anchor.bin"],
    ])
      if (!files.some((f) => f.root === root && f.name === name))
        throw new StorageError("fence_mismatch");
    return { ...common, binding, keyDigest, files };
  } catch {
    throw new StorageError("fence_mismatch");
  }
}

export function encodeRemovalFence(fence: RemovalFence): Buffer {
  const bytes = Buffer.from(JSON.stringify(fence));
  parseRemovalFence(bytes);
  return bytes;
}
