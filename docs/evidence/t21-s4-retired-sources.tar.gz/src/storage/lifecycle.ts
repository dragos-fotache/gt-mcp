/** Explicit trusted removal recovery/reconciliation factories. Imports perform no IO. */
import { fileURLToPath } from "node:url";
import { bootstrapLock, launchIpcSession } from "./client.js";
import type { LifecycleProfileSession, OpenRequest, ReconciledProvisionRequest } from "./types.js";
import {
  assertBinding,
  assertLocationRoots,
  assertOpenRequest,
  assertProvisionRequest,
  assertTimeoutMs,
  captureShape,
  requiredField,
} from "./validate.js";

export async function resumeProfileRemoval(request: OpenRequest): Promise<LifecycleProfileSession> {
  const checked = assertOpenRequest(request);
  const roots = assertLocationRoots(checked.profileRoot, checked.anchorRoot);
  const timeoutMs = assertTimeoutMs(checked.timeoutMs);
  const bootstrap = bootstrapLock(roots.anchorRoot, roots.profileRoot, false);
  const deadlineMs = Date.now() + timeoutMs;
  return launchIpcSession({
    workerJsPath: fileURLToPath(new URL("./holder.js", import.meta.url)),
    lockFd: bootstrap.fd,
    op: "resumeRemoval",
    params: {
      ...roots,
      expectedBinding: { ...checked.expectedBinding },
      busAddress: checked.secretServiceBusAddress,
      expectedLock: bootstrap.identity,
      deadlineMs,
    },
    timeoutMs,
    deadlineMs,
    requirePid: false,
  });
}

export async function provisionReconciledProfile(
  request: ReconciledProvisionRequest,
): Promise<LifecycleProfileSession> {
  const fields = captureShape(request, [
    "profileRoot",
    "anchorRoot",
    "secretServiceBusAddress",
    "timeoutMs",
    "origin",
    "profileGenerationId",
    "removedBinding",
  ]);
  const removedBinding = assertBinding(requiredField(fields, "removedBinding"));
  const plain: Record<string, unknown> = {};
  for (const [key, value] of fields) if (key !== "removedBinding") plain[key] = value;
  const checked = assertProvisionRequest(plain);
  const roots = assertLocationRoots(checked.profileRoot, checked.anchorRoot);
  const timeoutMs = assertTimeoutMs(checked.timeoutMs);
  const bootstrap = bootstrapLock(roots.anchorRoot, roots.profileRoot, false);
  const deadlineMs = Date.now() + timeoutMs;
  return launchIpcSession({
    workerJsPath: fileURLToPath(new URL("./holder.js", import.meta.url)),
    lockFd: bootstrap.fd,
    op: "reconcile",
    params: {
      ...roots,
      origin: checked.origin,
      profileGenerationId: checked.profileGenerationId,
      removedBinding: { ...removedBinding },
      busAddress: checked.secretServiceBusAddress,
      expectedLock: bootstrap.identity,
      deadlineMs,
    },
    timeoutMs,
    deadlineMs,
    requirePid: false,
  });
}
