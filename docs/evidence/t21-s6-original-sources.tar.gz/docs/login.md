# Trusted local setup, login and lifecycle

This guide describes the T21 version-2 source candidate. The unchanged T18-R1
archive and its installed copies use the earlier format; use their bundled guides.
A new installable T21 archive and installed verification belong to S6. Login/logout
are trusted local actions, never model-facing tools. Stop the server and await
profile ownership release before using a separate CLI process.

## Private configuration

Use Linux x64, pinned Node24.21.0/npm11.19.0 and an available, unlocked OS Secret
Service. Supply its intended Unix bus address explicitly. The store has no
filesystem-name/magic restriction: required safe IO must succeed. Agent verification
uses isolated ext4; Btrfs testing is user-owned. This is not certification of every
filesystem, network storage, another OS or actual power-loss survival.

Create a private0700 parent directory and separate user-owned0400/0600 regular,
single-link config/login files. Paths must be absolute/normalized and symlink-free;
ancestors must satisfy the existing trusted ownership/write rules. Keep both files
outside profileRoot. **Leave profileRoot nonexistent**: explicit setup creates it
exclusively, even an existing empty root is refused. Profile directories/files use
0700/0600. Unsafe permissions are refused, not silently repaired.

```json
{
  "version": 2,
  "serviceOrigin": "https://service.example.invalid",
  "storage": {
    "profileRoot": "/PRIVATE/NEW-PROFILE",
    "secretServiceBusAddress": "unix:path=/PRIVATE/SECRET-SERVICE-SOCKET"
  },
  "writesEnabled": false
}
```

These are placeholders, not deployment inputs. Optional existing transportBudgets,
protocol.maxToolResultBytes and storage.timeoutMs retain their validated constraints.
No anchorRoot or bindingDescriptorPath is accepted. Binding and auth vault are
stored together in credentials.enc, with owner.lock and possible private temporary
replacements. Temporary files are never promoted on startup.

Login settings remain version1, separate from server config:

```json
{
  "version": 1,
  "googleWebClientId": "REPLACE-WITH-PREPARED-WEB-CLIENT-ID",
  "browserOrigin": "http://localhost:REPLACE-WITH-PREPARED-PORT"
}
```

Use the intended Google client, HTTPS backend origin and available unprivileged
localhost port. The owned helper reserves both loopback families; do not paste
tokens into a model, config, logs or command arguments. Real Google/browser
qualification remains T19, outside synthetic S4 acceptance.

## Commands

Replace all angle-bracket placeholders with prepared local paths. No global binary
installation is needed. The examples select the compiled trusted CLI explicitly.

```sh
<NODE24>/bin/node <APP>/dist/cli/main.js setup --config <CONFIG>
<NODE24>/bin/node <APP>/dist/cli/main.js login --config <CONFIG> --login-config <LOGIN_CONFIG>
<NODE24>/bin/node <APP>/dist/cli/main.js login --config <CONFIG> --login-config <LOGIN_CONFIG> --resume
<NODE24>/bin/node <APP>/dist/cli/main.js login --config <CONFIG> --login-config <LOGIN_CONFIG> --cancel
<NODE24>/bin/node <APP>/dist/cli/main.js recover --config <CONFIG>
<NODE24>/bin/node <APP>/dist/cli/main.js sign-out --config <CONFIG>
<NODE24>/bin/node <APP>/dist/cli/main.js account-status --config <CONFIG> --login-config <LOGIN_CONFIG>
<NODE24>/bin/node <APP>/dist/cli/main.js profile-remove --config <CONFIG> --confirm
```

Setup creates a fresh key/profile, never migrates existing state. Successful login
installs the backend-confirmed account/session and vault atomically. Existing-account
login must confirm that same account; it cannot silently switch accounts. Foreground
login retains encrypted exact exchange evidence for bounded explicit resume/cancel.

Recover validates the selected record/auth state without backend sends or repair.
It can report ready, or directs pending foreground login to explicit resume/cancel.
Missing/corrupt/old state requires fresh configuration/profile/login; recover never
creates a replacement key, repairs an external descriptor or resumes creation.

Sign-out fences/settles domain and auth work, advances generation and durably clears
usable grants before best-effort dedicated-session logout. Account identity remains
bound. Account-status uses a fresh proof matching that account and challenge/purpose;
only authoritative matching deletion authorizes automatic local credential cleanup.
A lost proof reply requires a new foreground attempt, not a stored proof replay.

Profile removal requires explicit local confirmation and exclusive ownership. It
deletes the authenticated exact key first, then known credential files/temps. Unknown
contents or partial cleanup fail safely. owner.lock/root remain available for explicit
cleanup retry and are never unlinked while held. After interrupted key deletion,
normal open fails; repeat profile-remove explicitly to finish. Choose a different
new root for later setup. It never deletes backend data, host transcripts or backups;
physical erasure is not promised. Retired retire-operation and setup --reconcile
commands are rejected. See [recovery](recovery.md) and [server operations](stdio-server.md).
