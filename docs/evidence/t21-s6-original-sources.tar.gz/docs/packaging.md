# Building a private runtime package

T21-S4 source notice: this document's detailed packaging evidence/procedure describes
the earlier R1/T17 artifacts. Current source uses config2 and single-record credentials;
use [current setup](login.md) and [recovery](recovery.md). S5/S6 must refresh and
qualify the corresponding delivered boundary. No new package/host certification
is claimed here; Btrfs testing remains user-owned.

The [T18-R1 refresh](evidence/t18-r1-review.md) verifies the current private
candidate:40/40 in12 files on workspace and clean, with byte-identical clean
archive reconstruction. [Inventory](evidence/t18-r1-package-inventory.json) names
the exact digest,96 files and111 locked runtime dependencies. Historical T18-S3
archive identity remains preserved separately; no release approval follows.

Use the disposable pinned Node24.21.0/npm11.19.0 toolchain. From a locked source
checkout, run the production checks and clean build, then:

```text
npm run package:artifact -- --out <absolute existing empty output directory>
```

The command does not build, install dependencies or publish. It stages only the
reviewed production JS/worker list, operator documents/templates, projected
runtime manifest/shrinkwrap and runtime dependency notices. Root package-lock
versions/resolutions/integrities remain authoritative; workspace/dev/Pi packages
are excluded by dependency reachability. Missing inputs, unsafe paths or nonempty
output fail closed. Failure removes only the command's own temporary/partial
outputs. Root npm pack is not the distribution procedure.

Outputs are gymtracka-mcp-0.0.0.tgz and its sibling inventory JSON. Inventory records
archive/content SHA256, file modes, nonsecret selected input hashes and all locked
runtime dependency identities. Version0.0.0 is a private candidate identity: use
the archive digest to distinguish candidates. No public version/license/release
permission is implied. Do not package a live configuration, descriptor, state root,
key, credentials or logs; no private material is needed to build the package.

Extract into a fresh dedicated application directory and run
`npm ci --omit=dev --ignore-scripts` with the pinned toolchain. This is the sole
supported install route. Installing the tarball as a consumer dependency with
`npm install` can re-resolve transitive versions under npm11.19 and is unsupported
by explicit user decision during T18-S1. Dependencies require registry/cache
access; no node_modules, Node, system helpers or host runtime are bundled.

Use absolute installed `dist/protocol/server.js` and `dist/cli/main.js` paths from
any working directory, with pinned Node or their executable shebang entries.
The CLI package metadata now targets the delivered trusted CLI; the old inert
foundation CLI remains only in the source build for its preserved regressions.
No global installation or source compilation is needed on the receiving machine.

The package README, standalone [installation](installation.md),
[login](login.md), [server](stdio-server.md), [recovery](recovery.md) guides and
false configuration/login templates are included. Retained recovery/upgrade and
clean parent acceptance are recorded in [T18-S3](evidence/t18-s3-review.md). Keep private configuration, stores,
anchors/fences and OS keys separate from executable installation; never reset
private state to repair an install. No real backend/Google/Android/named-host or
independent release certification follows from package smoke checks.
