# Installation transition and source setup

**T21-S4 is a source candidate, not a new delivery package.** S6 owns a separately
identified archive, clean locked installed reproduction and installation handoff.
The preserved T18-R1 archive remains unchanged and uses version-1 storage/config;
follow the instructions bundled with that archive for that historical installation.
Do not install current source as an accepted T21 delivery or reuse old R1 state.

T21 retains Linux x64, Node24.21.0/npm11.19.0 and the OS-protected Secret Service key.
It removes filesystem-name gating, separate anchor/binding roots and creation
journals. Required restricted path/file operations and durability primitives must
succeed. Agent checks use disposable ext4; Btrfs testing is user-owned. Other OS,
network filesystem and power-loss certification are not implied.

For an authorized isolated source check, use the provisioned disposable Node toolchain,
locked dependencies without lifecycle scripts and an explicit build. No global
package, system Node replacement or Pi setting change is needed. Preserve existing
archives outside dist before a clean build. Never rebuild/install while tests use
that target. [Packaging](packaging.md) still records the historical delivery and S6
must refresh its allowlists/closure before a new archive is accepted.

Prepare deployment inputs independently: intended HTTPS backend origin, Google web
client ID, free dual-loopback browser port, explicit private Secret Service bus and
a private parent with a **nonexistent** fresh profileRoot. Do not invent deployment
values. [Trusted setup/login](login.md) specifies config2, settings1, permissions and
commands; [server operations](stdio-server.md) explains the fixed write policy.

For old installations: stop the old server, inspect uncertain remote routines,
create a separate version-2 config/new root and sign in again. New code refuses
version1/old files without mutation and never migrates, replays or discards them.
Old data cleanup is a separate explicit local action using the old bundled guide.
The laptop installation is not changed by source acceptance. [Recovery](recovery.md)
documents ambiguous IO, pending auth, explicit cleanup and restored-snapshot limits.
