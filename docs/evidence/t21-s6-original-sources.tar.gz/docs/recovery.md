# Recovery and fresh-profile transition

This guide covers the version-2 T21 source candidate. R1 keeps its bundled older
procedure and evidence. No automatic format migration or old-data cleanup occurs.
Stop old servers before changing an installation or using trusted local commands.
New package/installed acceptance remains S6.

| Situation | Action |
| --- | --- |
| Version-1 config/old storage | Stop the old server; manually inspect uncertain remote creations. Prepare version-2 config with a new nonexistent private root and sign in again. Never point new setup at old state or use the new removal command to erase old-format data. Old cleanup is a separate explicit action using that installation's guide. |
| Missing/unsafe config | Fix the protected version-2 config and separation/permissions. No environment or CLI write override exists. |
| Signed out | Explicitly sign in to the same bound account. This does not resume creation. |
| Pending foreground login | Use login --resume within the original deadline/budget, or login --cancel. Original token/body/key are retained encrypted; never invent a replacement retry identity. |
| Pending refresh after lost response | Retain the exact encrypted credential record. The auth layer preserves/replays the original refresh token/body/key under current session fences; do not manufacture a new refresh attempt to bypass uncertainty. |
| Ambiguous credential commit | Close the fenced owner. Reopen authenticates only credentials.enc and may find valid old or new state; missing/corrupt state fails. Temporary files are never promoted. |
| Missing/locked/ambiguous/replaced key | Restore access to the intended OS facility where appropriate, or prepare a separately selected fresh profile/login. No cached-key fallback or automatic replacement key. |
| Interrupted explicit removal after key deletion | Normal open remains unavailable. Repeat trusted profile-remove --confirm on the same version-2 selection to finish known local cleanup; do not recursively delete unknown contents. |
| Lost account-status response | Start a fresh foreground proof. A completed local deletion is not reversed; an interrupted key-first cleanup needs explicit profile removal retry. |
| Lost/interrupted routine result | Manually inspect saved routines and a known own draft ID if available. A deliberate new call starts a new attempt and can create a duplicate. There is no operationId, durable creation receipt, restart resume, automatic deletion or multi-request rollback. |

Recover validates current credential/auth state only. It does not repair old
metadata, reconstruct missing state, send creation, or finish cleanup without an
explicit removal action. Full syntax is in [trusted lifecycle](login.md#commands).

## Restore and filesystem limits

The one authenticated record protects confidentiality/integrity and commits binding
with vault bytes using private temporary write, file fsync, rename and directory
fsync under exclusive ownership. No filesystem type is hard-coded. Actual IO errors
are reported safely; fsync/hardware compliance remains conditional and tests do not
prove power-loss survival. Btrfs qualification belongs to the user.

There is no independent anchor or rollback marker. Restoring an older valid encrypted
credential snapshot is not detected independently and may require fresh login or
trigger backend refresh-token reuse consequences. Do not describe encryption as
rollback detection. Preserve pending refresh identity; do not merge vault snapshots,
manually edit bindings or copy credentials between accounts/origins.

No creation content is retained locally for retry. Auth recovery and foreground
login evidence remain encrypted as required. AI hosts may retain fitness requests,
results and transcripts under their own policies. Removal does not erase those,
remote routines, filesystem snapshots, backups or physical media copies.
