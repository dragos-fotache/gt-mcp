# Local stdio MCP server

T21-S4 integrates version-2 configuration and the single-record credential store in
the source candidate. T18-R1 archive/installed copies retain their old behavior and
bundled instructions. S5 backend/host and S6 new installed-artifact acceptance remain
open; this guide does not authorize deployment or real write enablement.

Run the compiled server with pinned Node24.21.0 and an absolute normalized config
selection. Missing selection/config provides an unavailable seven-tool catalogue;
invalid selected config fails configuration_required. A selected credential/key/
ownership failure is recovery_unavailable. A null-account or signed-out profile
requires trusted local login. Logs/errors never print the config path or credentials.

```sh
<NODE24>/bin/node <APP>/dist/protocol/server.js --config <CONFIG>
```

See [setup/login](login.md) for the strict version-2 config and separate version-1
login settings. No anchorRoot, binding descriptor, operation journal, migration,
provider override, per-routine permission prompt or CLI write-enable flag exists.
The trusted startup snapshot is fixed; editing config does not enable writes in a
running process. Restart deliberately after an operator configuration change.

Six read tools expose canonical domain results: search_exercises, get_exercise,
list_workouts, get_workout, list_routines and get_routine. create_routine accepts
name/exercises, rejects obsolete operationId, and returns routineId/status:saved
only after validated backend confirmation. Only strict operator writesEnabled:true
permits creation; omitted/false defaults to disabled before mutations. Any connected
local client shares that operator trust. Authentication, complete validation,
visibility, origin and current account/session fences still apply.

Each creation is independent and non-idempotent. Repeating identical content can
create another routine. Eligible bounded auth retry within a call retains exact
resource bytes/key, but tool-level creation failures are retryable:false. After
interruption, unsent steps stop; available authorized context reports routineId,
lastConfirmedStep and outcomeUnknown. A canceled/disconnected host may receive no
reply. No routine bodies, identities or final receipts are persisted for replay.
Use [manual recovery guidance](recovery.md) before deliberately trying again.

The server holds exclusive profile ownership. Stop it and await release before
trusted CLI lifecycle/login/removal. Signal/EOF cancellation fences results and
settles begun auth persistence. Never send login/logout through model tools.
Only MCP frames go to stdout; trusted CLI diagnostics use fixed safe stderr text.
Fitness data may remain in host/model transcripts; local removal cannot erase them.
The credential store does not gate on filesystem type; required permissions, safe
paths, atomic replacement/fsync and actual IO must work. No independent snapshot
rollback detection or power-loss certification is claimed.
