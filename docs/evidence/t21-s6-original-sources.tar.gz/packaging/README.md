# GymTracka MCP — private package candidate

Compiled portable stdio server and trusted local CLI. This candidate has no public
release or real backend/Google/Android/named-host certification. The operator guides
are included. Same-format replacement/recovery qualification is tied to exact
candidate checksums and accepted evidence; it does not establish release readiness.

Use Node 24.21.0 and npm 11.19.0 on Linux x64. Profile storage requires supported
local ext4, compatible util-linux flock and an unlocked OS Secret Service on an
explicitly selected private bus. Desktop browser login also requires the accepted
xdg-open and registered Google/localhost deployment configuration.

Extract into a fresh dedicated application directory and run
`npm ci --omit=dev --ignore-scripts`. Start `node dist/protocol/server.js` or
`node dist/cli/main.js --help` with the pinned toolchain. Use the installed absolute
JS entry paths when launching from another directory; both entries are executable
with the pinned Node on PATH. Extract-and-ci is the sole supported installation
route. Installing the tarball as a dependency can re-resolve transitive versions
under the pinned npm and is unsupported. No global installation, compilation,
Pi runtime or permission extension is needed.
Dependencies require registry/cache access; they are not bundled in the archive.

Start with [installation and prerequisites](docs/installation.md), then
[trusted setup/login/lifecycle](docs/login.md), [server operations and budgets](docs/stdio-server.md)
and [recovery/retention/upgrades](docs/recovery.md). The guides and their local
operator links are self-contained in this archive. Templates in examples/ contain
placeholders, not deployment settings. Prepare distinct private files with accepted
ownership/modes outside the installed application. Never place credentials in argv/chat.

Creation defaults to disabled. All bundled examples use `writesEnabled:false`;
omission is false and malformed configuration fails closed. Only strict true in
the operator config permits authenticated explicit creation. Any local client
connected to an enabled server can request creation without a per-routine prompt;
protect the config, process and private state. Config/descriptor loading is
startup-only: stop, await cleanup, update or perform trusted lifecycle work, then
relaunch. Startup never resumes unfinished operations.

Keep existing private config, encrypted stores, anchors/fences and OS keys separate
from executable replacement. Do not reset/recreate profiles to fix an install.
Unresolved evidence can remain indefinitely; compact receipts persist for the
profile lifetime. Sign-out preserves recovery. Lost storage/removal ends local
replay guarantees. Remote drafts/saved work and host transcripts may remain;
local cleanup does not roll back backend data or wipe backups/offline copies.

This private candidate grants no new project license. Runtime dependency notices
are in THIRD-PARTY-NOTICES.txt; dependency packages retain their own terms.
