// Shared draft0.2 creation/recovery and T18 same-format replacement contract.
// Actual isolated provider/ext4/TLS, explicitly frozen source and installed process.
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { args, fixture, processSession } from "../create-stdio/helpers.mjs";
import { expectEnvelope, expectError } from "../read-protocol/helpers.mjs";
import { createArtifactFixture, installExtracted, sha256 } from "./helpers.mjs";

let artifact, app, oldEntry;
beforeAll(() => {
  const historic = process.env.GT_T18_BASELINE_ROOT;
  const refresh = process.env.GT_PACKAGE_REFRESH_BASELINE_ROOT;
  if (
    process.env.GT_S3_ISOLATION_CONFIRMED !== "t08-s3-isolated" ||
    (!historic && !refresh) ||
    (historic && refresh)
  )
    throw new Error(
      "Qualified private runner and one verified historical or refresh baseline required",
    );
  // Historical T18 grants still use the pre-T18 target. R1 explicitly records
  // current frozen source -> installed candidate; it is not an old-release claim.
  oldEntry = path.join(historic ?? refresh, "dist/protocol/server.js");
  expect(fs.statSync(oldEntry).isFile()).toBe(true);
  artifact = createArtifactFixture();
  app = installExtracted(artifact);
}, 360000);
afterAll(() => artifact?.cleanup());

function privateImage(f) {
  const image = {};
  function visit(file) {
    if (fs.statSync(file).isDirectory()) {
      for (const name of fs.readdirSync(file).sort()) visit(path.join(file, name));
    } else image[path.relative(path.dirname(f.configPath), file)] = sha256(fs.readFileSync(file));
  }
  for (const file of [
    f.configPath,
    f.config.bindingDescriptorPath,
    f.storage.profileRoot,
    f.storage.anchorRoot,
  ])
    visit(file);
  return image;
}

const call = (s, input = args()) => s.client.callTool({ name: "create_routine", arguments: input });
const stepRequest = (step) => ({
  method: step.method,
  target: step.route,
  key: step.resourceKey,
  body: Buffer.from(step.bodyBase64, "base64"),
});

describe("T18-S3 installed same-format replacement", () => {
  it("preserves pending identity and settled receipt across inert replacement, policy denial and explicit exact retry", async () => {
    const f = await fixture();
    const installed = {
      entry: path.join(app, "dist/protocol/server.js"),
      cwd: artifact.root,
      env: artifact.env,
    };
    let s;
    try {
      s = await processSession(f.configPath, { entry: oldEntry, cwd: artifact.root });
      const saved = await call(s, args(8));
      expect(saved.structuredContent).toMatchObject({ ok: true, data: { status: "saved" } });
      f.state.malformed = "populate"; // remote commit, unusable confirmation reply
      const uncertain = await call(s);
      expectError(uncertain, "internal_error", true, {
        operationId: args().operationId,
        routineId: JSON.parse(f.mutations().at(-2).body).id,
        lastConfirmedStep: "draft",
        outcomeUnknown: true,
      });
      await s.close("eof");
      expect(s.stderr()).toBe("");
      s = undefined;

      const records = await f.inspect();
      const pending = records.find((r) => r.operationId === args().operationId);
      const receipt = records.find((r) => r.operationId === args(8).operationId);
      expect(receipt).toMatchObject({ kind: "receipt", result: saved.structuredContent });
      expect(pending).toMatchObject({ kind: "journal", terminal: null });
      expect(pending.steps.map((step) => step.state)).toEqual([
        "confirmed",
        "dispatch-possible",
        "unsent",
      ]);
      expect(f.mutations().slice(-2)).toEqual(pending.steps.slice(0, 2).map(stepRequest));
      const before = f.requests.length;
      const image = privateImage(f);

      // Replacement/start/stop with no call: no network and no persistent byte change.
      s = await processSession(f.configPath, installed);
      expect(f.requests).toHaveLength(before);
      await s.close("eof");
      expect(s.stderr()).toBe("");
      s = undefined;
      expect(privateImage(f)).toEqual(image);
      expect(await f.inspect()).toEqual(records);

      f.write({ ...f.config, writesEnabled: false });
      const disabledImage = privateImage(f);
      s = await processSession(f.configPath, installed);
      expectError(await call(s), "configuration_required", false, {
        message: "Routine creation is disabled in the operator configuration.",
      });
      expect(f.requests).toHaveLength(before);
      await s.close("eof");
      expect(s.stderr()).toBe("");
      s = undefined;
      expect(privateImage(f)).toEqual(disabledImage);
      expect(await f.inspect()).toEqual(records);

      f.write(f.config);
      s = await processSession(f.configPath, installed);
      expect(f.requests).toHaveLength(before);
      const mutationCount = f.mutations().length;
      expectEnvelope(await call(s, args(8)), receipt.result);
      expect(f.mutations()).toHaveLength(mutationCount);
      expectEnvelope(await call(s), {
        ok: true,
        data: {
          operationId: pending.operationId,
          routineId: pending.routineId,
          status: "saved",
        },
      });
      expect(f.mutations().slice(mutationCount)).toEqual(pending.steps.slice(1).map(stepRequest));
      await s.close("eof");
      expect(s.stderr()).toBe("");
      s = undefined;
      const after = await f.inspect();
      expect(after.find((r) => r.operationId === receipt.operationId)).toEqual(receipt);
      expect(after.find((r) => r.operationId === pending.operationId)).toMatchObject({
        kind: "receipt",
        binding: pending.binding,
        operationId: pending.operationId,
        routineId: pending.routineId,
        intent: pending.intent,
        lastConfirmedStep: "save",
        result: {
          ok: true,
          data: {
            operationId: pending.operationId,
            routineId: pending.routineId,
            status: "saved",
          },
        },
      });
    } finally {
      await s?.close("eof");
      await f.close();
    }
  }, 60000);

  it("refuses future store/journal versions and invalid step keys at installed startup, even with writes disabled", async () => {
    const f = await fixture();
    let s;
    try {
      f.state.malformed = "populate";
      s = await processSession(f.configPath, { entry: oldEntry, cwd: artifact.root });
      expect((await call(s)).structuredContent).toMatchObject({
        ok: false,
        error: { outcomeUnknown: true },
      });
      await s.close("eof");
      expect(s.stderr()).toBe("");
      s = undefined;
      const owner = await f.open(f.binding);
      let store;
      try {
        store = JSON.parse(Buffer.from(await owner.readOperationStoreBytes()).toString());
      } finally {
        await owner.close();
      }
      const futureJournal = JSON.parse(JSON.stringify(store));
      futureJournal.operations[0].version = 2;
      const invalidKey = JSON.parse(JSON.stringify(store));
      invalidKey.operations[0].steps[1].resourceKey = invalidKey.operations[0].steps[0].resourceKey;
      for (const [value, writesEnabled] of [
        [{ version: 2 }, false],
        [futureJournal, true],
        [invalidKey, true],
      ]) {
        const owner = await f.open(f.binding);
        try {
          await owner.commit({ operationBytes: Buffer.from(JSON.stringify(value)) });
        } finally {
          await owner.close();
        }
        f.write({ ...f.config, writesEnabled });
        await refusesStartup(f);
      }

      // GTMS2 envelope version at byte 5, specified by accepted T04 storage format.
      const file = path.join(f.storage.profileRoot, "operations.bin");
      const bytes = fs.readFileSync(file);
      bytes.writeUInt16BE(2, 5);
      fs.writeFileSync(file, bytes);
      await refusesStartup(f, false); // incompatible envelope also prevents direct storage open
    } finally {
      await s?.close("eof");
      await f.close();
    }
  }, 60000);

  it("refuses nonempty operation evidence on a never-bound profile without resetting it", async () => {
    const f = await fixture({ signedOut: true, writesEnabled: false });
    try {
      expect(f.binding.accountUuid).toBeNull();
      const owner = await f.open(f.binding);
      try {
        await owner.commit({ operationBytes: Buffer.from('{"version":2}') });
      } finally {
        await owner.close();
      }
      await refusesStartup(f);
    } finally {
      await f.close();
    }
  }, 30000);
});

async function refusesStartup(f, probeOwner = true) {
  const image = privateImage(f);
  const requestCount = f.requests.length;
  const result = spawnSync(
    process.execPath,
    [path.join(app, "dist/protocol/server.js"), "--config", f.configPath],
    {
      cwd: artifact.root,
      env: artifact.env,
      encoding: "utf8",
      timeout: 15000,
    },
  );
  expect(result.error).toBeUndefined();
  expect(result).toMatchObject({
    status: 78,
    signal: null,
    stdout: "",
    stderr: "GymTracka MCP private state could not be opened safely.\n",
  });
  expect(f.requests).toHaveLength(requestCount);
  expect(privateImage(f)).toEqual(image);
  if (probeOwner) {
    // The real installed holder must release its lease even on validation failure.
    const owner = await f.open(f.binding);
    await owner.close();
    expect(privateImage(f)).toEqual(image);
  }
}
