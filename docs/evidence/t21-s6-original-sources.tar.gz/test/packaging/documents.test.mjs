// T18-S2 document oracles come from accepted schemas/specs, not runtime implementation text.
import fs from "node:fs";
import path from "node:path";
import { afterAll, beforeAll, expect, it } from "vitest";
import { validateConfigRecord } from "../../dist/runtime/config.js";
import { validateSettings } from "../../dist/login/records.js";
import { createArtifactFixture, REPO, readJson, run } from "./helpers.mjs";

let fixture;
let texts;
beforeAll(() => {
  fixture = createArtifactFixture();
  const destination = path.join(fixture.root, "documents");
  fs.mkdirSync(destination);
  run("tar", ["-xzf", fixture.archive, "-C", destination, "--no-same-owner"], { env: fixture.env });
  fixture.app = path.join(destination, "package");
  texts = Object.fromEntries(
    [
      "README.md",
      "docs/installation.md",
      "docs/login.md",
      "docs/stdio-server.md",
      "docs/recovery.md",
    ].map((name) => [name, fs.readFileSync(path.join(fixture.app, name), "utf8")]),
  );
}, 60000);
afterAll(() => fixture?.cleanup());

it("ships the complete standalone guide/link closure with installed entry commands and one supported install route", () => {
  for (const [name, text] of Object.entries(texts)) {
    // Only these five shipped documents are inspected; no general-purpose crawler.
    for (const [, target] of text.matchAll(/\[[^\]]+\]\(([^)]+)\)/g)) {
      if (/^[a-z]+:/i.test(target)) continue;
      const [relative, fragment] = target.split("#");
      const resolved = relative
        ? path.posix.normalize(path.posix.join(path.posix.dirname(name), relative))
        : name;
      expect(resolved).not.toMatch(/^(?:\.\.\/|\/)/);
      expect(fs.existsSync(path.join(fixture.app, resolved))).toBe(true);
      if (fragment) {
        const content = fs.readFileSync(path.join(fixture.app, resolved), "utf8");
        const headings = [...content.matchAll(/^#{1,6} (.+)$/gm)].map(([, title]) =>
          title
            .toLowerCase()
            .replace(/[^\w -]/g, "")
            .replace(/ /g, "-"),
        );
        expect(headings).toContain(fragment);
      }
    }
    expect(text).not.toMatch(/\]\((?:decisions|evidence|tasks|\.\.\/shared-docs)\//);
    expect(text).not.toMatch(/npm run build/);
  }
  expect(texts["docs/installation.md"]).toContain("npm ci --omit=dev --ignore-scripts");
  expect(texts["docs/installation.md"]).toContain("sole supported install route");
  expect(texts["docs/login.md"]).toContain(
    'node "<absolute application directory>/dist/cli/main.js" --help',
  );
  expect(texts["docs/stdio-server.md"]).toContain(
    'node "<absolute application directory>/dist/protocol/server.js"',
  );
});

it("keeps packaged and inline templates strict, nonsecret and disabled using synthetic schema substitution only", () => {
  const server = readJson(path.join(fixture.app, "examples/config.template.json"));
  const login = readJson(path.join(fixture.app, "examples/login.template.json"));
  const inline = [...texts["docs/login.md"].matchAll(/```json\n([\s\S]*?)\n```/g)].map(([, json]) =>
    JSON.parse(json),
  );
  expect(inline).toHaveLength(2);
  const substitute = (record) => {
    if (Object.hasOwn(record, "serviceOrigin"))
      return {
        ...record,
        serviceOrigin: "https://synthetic-documentation.invalid",
        storage: {
          ...record.storage,
          profileRoot: "/synthetic-documentation/profile",
          anchorRoot: "/synthetic-documentation/anchor",
          secretServiceBusAddress: "unix:path=/synthetic-documentation/bus",
        },
        bindingDescriptorPath: "/synthetic-documentation/binding.json",
      };
    return {
      ...record,
      googleWebClientId: "synthetic-documentation-client.invalid",
      browserOrigin: "http://localhost:43219",
    };
  };
  for (const record of [server, ...inline.filter((r) => Object.hasOwn(r, "serviceOrigin"))]) {
    expect(record.writesEnabled).toBe(false);
    expect(record.serviceOrigin).toMatch(/^<[^>]+>$/);
    expect(validateConfigRecord(substitute(record)).writesEnabled).toBe(false);
    const omitted = substitute(record);
    delete omitted.writesEnabled;
    expect(validateConfigRecord(omitted).writesEnabled).toBe(false);
    expect(() => validateConfigRecord({ ...omitted, writesEnabled: "true" })).toThrow();
  }
  for (const record of [login, ...inline.filter((r) => Object.hasOwn(r, "googleWebClientId"))]) {
    expect(record.googleWebClientId).toMatch(/^<[^>]+>$/);
    expect(record.browserOrigin).toBe("http://localhost:<registered fixed port>");
    expect(validateSettings(substitute(record)).version).toBe(1);
  }
  for (const text of Object.values(texts))
    for (const [, json] of text.matchAll(/```json\n([\s\S]*?)\n```/g))
      expect(JSON.parse(json).writesEnabled).not.toBe(true);
});

it("documents approved budget defaults/ranges and the essential recovery/privacy boundaries", () => {
  const table = (text) =>
    Object.fromEntries(
      [...text.matchAll(/^\|\s*(\w+(?:\.\w+)?)\s*\|\s*(\d+)\s*\|\s*(\d+)\.\.(\d+)\s*\|/gm)].map(
        ([, field, value, min, max]) => [field, [Number(value), Number(min), Number(max)]],
      ),
    );
  const expected = table(
    fs.readFileSync(path.join(REPO, "docs/decisions/t05-approved-transport-spec.md"), "utf8"),
  );
  expect(Object.keys(expected)).toHaveLength(11);
  expect(table(texts["docs/stdio-server.md"])).toEqual({
    ...expected,
    "storage.timeoutMs": [5000, 1, 15000],
    "protocol.maxToolResultBytes": [4194304, 4096, 67108864],
  });
  const operations = texts["docs/stdio-server.md"];
  expect(operations).toMatch(/baseRetryDelayMs.*must not\s+exceed.*maxRetryDelayMs/s);
  expect(operations).toMatch(/loaded once at startup/);
  expect(operations).toMatch(/file edit\s+alone does not disable/);
  const recovery = texts["docs/recovery.md"].replace(/\s+/g, " ");
  for (const boundary of [
    /indefinitely until settlement/,
    /profile lifetime/,
    /Sign-out preserves/,
    /permanently reserving the ID/,
    /never model-facing tools/,
    /no.*backend DELETE guarantee/i,
    /cannot be\s+automatically detected/,
    /not.*reconstruct.*missing\s+journal/s,
    /Same-format.*require qualification.*exact candidate/,
    /old\/future release migration support/,
    /archive digest.*does not certify real deployments.*release readiness/,
  ])
    expect(recovery).toMatch(boundary);
});
