# Compatibility matrix

Product/release certification rows remain **unverified** while named Pi, live
Google/browser and independent release gates are open. Task-level isolated T16
backend/Android evidence is recorded below; it does not certify those other gates.
Selection, foundation results and parked synthetic experiments are not release passes.
Current [user-approved config-only policy](decisions/routine-creation-config-policy.md)
is aligned in shared MCP draft0.3 (uncommitted working-tree revision based on9a96dcb).
Only config-file writesEnabled:true enables routine creation, without a custom or
external permission extension or per-routine prompt. Backend v1/OpenAPI1.0.0 unchanged.

| Component                                  | Selected / candidate version                                                         | Owning task / evidence boundary                                       | Status                  | Limitations                                                                                                                                            |
| ------------------------------------------ | ------------------------------------------------------------------------------------ | --------------------------------------------------------------------- | ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Node.js                                    | 24.21.0 (LTS Krypton), engines >=24.21.0 <25                                         | T01 foundation; T08/T15/T17 product tests                             | unverified              | import.meta.main Stability1.0/early development, accepted only for pinned inert foundation; retest upgrades                                            |
| npm                                        | 11.19.0                                                                              | T01 lock/packageManager; later clean install                          | unverified              | --ignore-scripts; no lifecycle-hook requirement                                                                                                        |
| TypeScript                                 | 5.9.3                                                                                | T01 typecheck/build                                                   | unverified              | Strict flags; legacy inert companion skipLibCheck exception documented in T01 ADR; no new relaxation                                                   |
| Official MCP SDK                           | 1.32.1                                                                               | T08 stdio and T15 integration                                         | unverified              | v1 maintenance horizon recorded in T01 ADR; no general protocol claim                                                                                  |
| MCP protocol                               | candidate2025-11-25                                                                  | T08/T17 actual product negotiation                                    | unverified              | Parked synthetic fixture negotiation is not product/host certification                                                                                 |
| Zod                                        | 4.5.4                                                                                | T03 schema/lossless codec                                             | unverified              | No domain implementation in T01; exact Int64 proof still required                                                                                      |
| Vitest                                     | 4.1.11                                                                               | Independent task suites                                               | unverified              | Discovery test/**/*.test.mjs; no pass-with-no-tests or silent parked/failing suite exclusion                                                           |
| Node types                                 | 24.19.2                                                                              | T01 declarations                                                      | unverified              | Dev-only                                                                                                                                               |
| ESLint / JS / TS ESLint / Prettier         | 10.12.0 /10.0.1 /8.71.1 /3.9.10                                                      | T01 tooling                                                           | unverified              | Dev-only; exact package versions/integrities in lockfile                                                                                               |
| Pi runtime                                 | coding-agent1.1.0 locked development pin                                             | T17 ordinary portable-server interoperability                         | unverified              | No required permission companion; supported paths/modes need actual evidence                                                                           |
| Config-file routine-creation guard         | writesEnabled strict boolean, default false                                          | T09/T15/T17                                                           | unverified              | True allows valid authenticated explicit calls without confirmation; no extension/UI/client metadata enablement; normal auth/recovery still required   |
| Pi companion / approval ordering           | Retired product scope; T02 parked                                                    | Historical T01 inert scaffold/T02 experiment only                     | not in current delivery | Preserve four accepted slices/six synthetic SDK profiles and unaccepted R3 candidate; no PTY/overall T02 or product approval certification             |
| OS / secret facility                       | Linux x64 Secret Service key + ext4 anchor; dbus-native0.7.8 locked                  | T04                                                                   | unverified              | Production interop, lease contention, PREPARED-kill fencing, power loss pending QA relay/review                                                        |
| Backend / OpenAPI / shared docs            | Backend v1/OpenAPI1.0.0; committed9a96dcb plus MCP draft0.2 working revision         | T16 isolated actual-service evidence; T20 certification separate      | unverified              | Full T16 source candidate verified in isolation, including S6 timestamp repair; deployed service, host/Google and release certification remain open    |
| Google / helper origin                     | Unselected placeholders                                                              | T07/T19                                                               | unverified              | No audience/client ID/registered port invented                                                                                                         |
| Android sync observation                   | API37 x86_64; emulator37.1.11; Android source72bf70db with isolated S7 test addition | T16 ordinary HTTP/Room/engine observation; T20 certification separate | unverified              | Exact saved MCP graph and stable repeated ordinary sync verified on owned emulator; no live phone, account UI/Google or instant/offline delivery claim |
| Artifact / journal / intent / key upgrades | T04 GTMS2 v1 envelopes, anchor v1, digest v1 built                                   | T04 built; T11/T18 own upgrades                                       | unverified              | Exact-byte migration/ownership/recovery fences need proof; T04 interop pending QA relay                                                                |

### T21-S5 current source boundary evidence

[S5 review](evidence/t21-s5-review.md):545/545 checks in58 exact files, zero
failures/skips;569 stable hashes,176 unchanged compiled outputs and owned cleanup
PASS. Current config2/single-record/invocation-local source passes actual isolated
backend/PostgreSQL and Pi1.1.0 SDK print/direct/deferred/codemode boundaries with
MCP2025-11-25. Repeated/concurrent creation is independent; no persisted receipt or
startup creation. Real pending-refresh and in-call auth retry identity remain.
[Scenario mapping](evidence/t21-s5-scenario-reconciliation.md),
[current package identities](evidence/t21-s5-environment.json).

This supersedes historical T16/T17 creation-recovery expectations only for current
source. Historical package/Android/host evidence below retains its original artifact
scope. Current Android delivery and actual Pi CLI/modes/lifecycle/session/output,
T19 and independent T20 remain unverified. S6 exact installed package/clean parent
acceptance is ready/unassigned; R1/laptop unchanged. Matrix rows remain unverified
for release. Btrfs testing is user-owned.

### T18-R1 current private package evidence

[R1 review](evidence/t18-r1-review.md):40/40 in12 files on workspace and clean,
zero failures/skips.430 source inputs and194 emitted files match; archive bytes,
content/modes and runtime lock reproduce identically.96 files/86 JS/111 locked
runtime dependencies. Exact delivery installation, bins/SDK/holder, current-source
pending/receipt recovery and incompatible-state refusal pass; owned cleanup PASS.
Versus historical T18 inventory, only the accepted catalogue decoder and standalone
server-guide wording changed. [Package identity](evidence/t18-r1-package-inventory.json).
No new old-release migration/host/backend/Google/Android or release certification.
T17-S2–S5, T19 and independent T20 remain separate; matrix rows stay unverified.

### T17-S1 named Pi SDK print evidence

[S1 review](evidence/t17-s1-review.md):25/25 in five files (8 actual Pi host +17
unchanged SDK/config checks), zero failures/skips;623 stable hashes and owned
cleanup PASS. Pi1.1.0 SDK print/hasUI:false negotiates MCP2025-11-25 through its
default native stdio transport. Direct, deferred-search-loaded and nested codemode
paths preserve config-only creation, read availability, receipt identity and small
complete envelopes. The model is scripted; backend replies use isolated synthetic
HTTPS, with real private provider/ext4 storage.327 original inputs unchanged,
including194 emitted files. [Pi notes](pi.md),
[package identities](evidence/t17-s1-environment.json).

Parent T17 remains incomplete: actual CLI/interactive mode, lifecycle/reconnect,
concurrency/cancellation, uncertain replay, restart/fork, effective disablement,
large output/untrusted text and clean integrated acceptance remain open. Matrix
rows stay unverified pending complete host/browser/independent release gates.

### T16-S7 integrated backend and Android evidence

[S7 review](evidence/t16-s7-review.md), [scenario reconciliation](evidence/t16-s7-scenario-reconciliation.md)
and [native result](evidence/t16-s7-native-results.json) record the actual isolated
candidate. Full active T16 replay passes **46/46 in nine files**, zero failures or
skips; exact source/APK/input/output and owned cleanup checks pass. Android starts
from an empty baseline, consumes the three real MCP-created batches through normal
HTTP/Room/engine delivery, and observes exact saved IDs/relationships/order/values.
Repeated sync is stable; PostgreSQL independently verifies no duplicate effects.

The source candidate includes S3's accepted catalogue codec repair and S6's accepted
backend timestamp repair. Original Android/backend inputs remain unchanged during
S7. Fixed expiry cases retain the declared test-only backend Clock overlay;
Android uses ordinary wall time. Authentication setup uses synthetic independent
same-account service sessions; external Google is not exercised. Final clean
reconstruction and parent disposition are recorded in the review. The earlier
T18 archive remains historical; no newly released package is claimed. Product/
release matrix rows above stay pending the remaining T17/T19/T20 gates.

### T16-S5 interruption/recovery observations (bounded evidence, not a completed row)

[S5 review](evidence/t16-s5-review.md): **54/54 in eight files**, all 36 active
T16 checks (33 service compositions, three codec) plus 18 unchanged T11/T15
regressions; zero failed/skipped/pending/todo and 611 stable hashes. Per-step durable
process interruption, committed-response cancellation, lost final MCP receipt,
bounded injected429 recovery, actual save rejection/key reuse and corrupted-success
replay pass. Scoped syntax/AST/lint/format/import checks and owned cleanup PASS;
312 product/config inputs/outputs match S4 and 116 original backend inputs stay
stable. Existing production checks/build from S4 apply to the same compiled
candidate; no S5 rebuild/clean-install or independent certification claim. Process
exits occur between acknowledged commits after owner drain; 429/corruption are
explicit relay faults. [Handoff](handoffs/t16-s5.md).
[Remaining plan](decisions/t16-remaining-slices.md): S1–S5 closed; S6 races/lifecycle
and S7 Android/integrated parent acceptance planned/unassigned. Parent T16 incomplete.
Historical T18 archive still needs S3 codec repair in a verified candidate;
compatibility/release gates and T17/T19/independent T20 remain open.

### T16-S4 auth/creation observations (bounded evidence, not a completed row)

[S4 review](evidence/t16-s4-review.md): **42/42 in eight files**, all 21 active
T16 checks (18 actual-service, three codec) plus 21 unchanged T06/T11/T15
regressions; zero failed/skipped/pending/todo and 608 stable hashes. Authentic A05
expired-access replay/install-before-rotation, reference rejection, terminal repeat,
concurrent normalized identity/distinct creation and real root collision pass.
Production/scoped checks and owned cleanup PASS; 312 checked product/config
inputs/outputs and 116 original backend inputs unchanged. A05 uses the existing
trusted-clock production auth facade with real storage/backend, followed by MCP
reopen; no elapsed-wall-clock stdio claim. [Handoff](handoffs/t16-s4.md).
[Remaining plan](decisions/t16-remaining-slices.md): S1–S4 closed; S5 separately
authorized while S4 finished, S6/S7 planned/unassigned. Parent T16 incomplete.
Crash/cancellation/uncertainty, remaining save rejection/key-reuse/malformed success,
other-client races/lifecycle, Android and integrated acceptance remain. Historical
T18 archive still needs S3 codec repair. T17/T19/T20 and release gates unchanged.

### T16-S3 read-boundary observations (bounded evidence, not a completed row)

[S3 review](evidence/t16-s3-review.md) records 147/147 in 11 files: all 16 active
T16 checks (13 actual-backend, three codec) plus 131 unchanged regressions; 607 hashes
stable. Real filters/visibility/saved-only lists, context-bound paging and refresh,
lossless raw numeric Int64 projection, live membership and fixed authentic expiry
pass. Valid bundled cross-role muscle membership exposed and received a narrow
codec repair; custom restrictions remain. Five Java restarts and owned cleanup
verified; original backend inputs unchanged. Fixed Clock is backend-owned test code
in a disposable artifact only. No Android/live/Google or full-parent claim.
S1–S3 closed; later slices unassigned. A05, remaining creation/domain/race/crash/
lifecycle/Android and parent acceptance stay open. Historical T18 archive needs this
repair in a later verified candidate. All matrix/release gates remain unchanged.

### T16-S2 auth/restart observations (bounded evidence, not a completed row)

[Review](evidence/t16-s2-review.md): 90/90 in eight files (all nine active T16 + 81
unchanged auth/lifecycle regressions), zero failed/skipped/pending/todo. Real refresh
serialization/exact lost-response replay across MCP/backend restart, representative
resource replay after service restart and real-lock logout/account-disable write
fences pass. Two Java restarts and owned cleanup verified. All 298 checked product
inputs/194 rebuilt outputs and 116 original backend inputs unchanged; no product or
contract edit. A05 and remaining cursor/ownership/domain/race/recovery/Android gates
stay open. Matrix rows remain unverified; no Google/live-phone/host/release claim.

### T16-S1 actual backend observations (bounded evidence, not a completed row)

[Review](evidence/t16-s1-review.md):4 actual-backend owning checks + 446 unchanged
regressions =450/450 in 49 files, zero failed/skipped/pending/todo. Disposable Java27
backend/PostgreSQL16, SDK1.32.1/Node24.21.0 and private provider/ext4/TLS verify
representative reads, creation, DB child values/revisions/three batches, exact
committed-response-loss replay at draft/populate/save after MCP restart, and ordinary
draft/saved pull/snapshot. Original 116 backend inputs unchanged; owned cleanup PASS.
Current contract/canonical catalogue match; historical build-prose hashes are
reproduced only in a disposable copy. Full auth/race/recovery/backend-restart and
Android gates remain unrun. Matrix rows above remain unverified; no Google/live
phone/host/release certification or automatic successor is implied.

### T08-S2 SDK-factory observations (bounded evidence, not a matrix row)

Coordinator independently observed the same c2 candidate pass SDK 99/99 and
configured 13/13: 112/112 total (20 S2 owning checks, 92 regressions), with all
217 input hashes stable. Source audit confirmed one validated startup snapshot
and result-budget forwarding. SDK 1.32.1 / Zod 4.5.4 on Node 24.21.0 / npm
11.19.0 were used; supplemental actual Client/InMemoryTransport initialization
negotiated 2025-11-25. These observations cover seven tools, six read dispatches,
full schemas and semantically matching structured results with text equal to
JSON.stringify of the actual structured content.

`protocol.maxToolResultBytes` defaults to 4194304, with inclusive range
4096..67108864. It measures the whole serialized CallToolResult in UTF-8,
including duplicate text; equality passes and overflow replaces the result,
without truncation. It is not a whole-wire or memory bound. Real isolated
GNOME 51.1 / ext4 / private-CA HTTPS signed-out composition with
`writesEnabled:true` demonstrated inert creation: true config cannot activate
the placeholder. This is not authenticated stdio, login, host, real-backend or
release verification.

The [common S2 specification](decisions/t08-s2-protocol-spec.md) and
[Coordinator closure review](evidence/t08-s2-coordinator-review.md) bound any
acceptance; this section is not a blanket product claim. The
[original f1 adjudication](decisions/t08-s2-f1-sdk-adjudication.md) remains
95/99 with four failures; the original fourth failure's returned fields remain
UNKNOWN. Historical notes and broad component statuses above remain unchanged.
Parent T08 is incomplete; S3 is unassigned and held.

### T05 transport implementation notes (unverified prose, not a matrix row)

The fixed-origin backend transport is implemented in `src/http/` (Node
builtins `http`/`https` plus the public T03 entry; no new dependencies)
with budgets, hook order, sticky uncertainty, and error mapping per the
approved T05 transport specification. No compatibility status is claimed:
wire/TLS behavior, lossless numeric results, loopback fixtures, and host
interoperability remain pending independent QA relay and coordinator
review. The 17 component rows above are unchanged.

### T06-S1 session state notes (unverified prose, not a matrix row)

The version-1 session vault reader, initial service-grant installation,
exact-expiry decisions, and read-only T05-compatible hooks are implemented
in `src/auth/` (no new dependencies; type-only T04/T05 reuse) per the
S1 work order. No compatibility status is claimed: persistence identity,
transport hook order, expiry boundaries, and fence behavior remain pending
independent QA relay and coordinator review. The 17 component rows above
are unchanged. No refresh, lifecycle, browser, MCP, or write behavior is
supplied in S1.

### T06-S2 durable refresh rotation notes (unverified prose, not a matrix row)

The refresh-only rotation capability is implemented in `src/auth/`
(`refresh.ts` plus an additive version-2 vault codec; no new
dependencies; one unchanged T05 transport constructed internally per
facade) per the S2 work order: exact durable predecessor/token/body/key
persistence before dispatch, single shared serialized attempt with
conservative pending retention and follower cancellation, atomic
same-account successor installation with joint pending clearing, and
blocked recovery state without replay. S1 exports and behavior are
preserved. No compatibility status is claimed: durable
predecessor/body/key-before-dispatch identity, shared-attempt behavior,
transport hook order, commit-failure/cancellation boundaries, and fence
behavior remain pending independent QA relay and coordinator review. The
17 component rows above are unchanged. No restart replay, retry,
lifecycle, browser, MCP, or write behavior is supplied in S2.

### T06-S3 exact refresh recovery notes (unverified prose, not a matrix row)

The recoverable refresh-session capability is implemented in `src/auth/`
(`recover.ts` plus one additive entry export; no new dependencies, vault
version, or error codes; one unchanged T05 transport constructed
internally per facade) per the S3 work order: explicit original-attempt
replay with durable body/key even after local predecessor expiry, atomic
recovered installation with pending cleared before any distinct rotation,
at most one follow-on fresh rotation with a distinct key (two control
requests per cycle at most), read-only live no-op and expired-refresh
refusal without commit/dispatch, full pending retention on every failed
replay, shared entire-cycle semantics for concurrent valid recover
callers with follower-local cancellation, and different-kind overlap
rejection without joining or disturbing the leader. S1/S2 exports and
behavior are preserved. No compatibility status is claimed: exact replay
identity after lost response/close/reopen, install-before-prepare
ordering, follow-on bounds, shared-cycle/cancellation boundaries, and
fence behavior remain pending independent QA relay and coordinator
review. The 17 component rows above are unchanged. No resource
orchestration, lifecycle, browser, MCP, or write behavior is supplied in
S3.

## Parked work and scope boundary

The custom extension lives in experiments/t02/companion, with driver and fixture
separate; production companion/src remains inert T01 scaffolding. Neither is
required for the config-only server. Old package/compiler/Pi pins remain untouched
by this documentation revision. Later removal/package/build reconciliation needs
an explicit bounded task scope and relevant specification-derived regressions.

Historical T02 acceptance records preserve failures/repairs under the old experiment
contract. R3 is candidate artifact-ready only; no independent QA artifact relay.
No new test, protocol, config-guard, host or release acceptance is claimed here.

### T06-S4 authenticated requests notes (unverified prose, not a matrix row)

The authenticated-request capability is implemented in `src/auth/`
(`authenticated.ts` plus one additive entry export; no new npm
dependencies, vault version, or error codes; one unchanged T05 transport
constructed internally per facade with privately capped resource attempts)
per the S4 work order: read-only v1/v2 open, exact pre-refresh local
validation (T03 query parser plus T05-exact body gates), shared
serialized auth controller with exact S3 pending-recovery priority and
durable fresh rotation, nine fixed resource methods with single-attempt
legs and at most one 401 refresh-and-retry, private volatile
grant-revision reuse for concurrent/delayed 401s, unchanged captured
identity across the retry, safe error mapping with pending retention and
mutation-uncertainty preservation, and cancellation-owned commit
settlement with permanent invalidate fence. S1/S2/S3 exports and behavior
are preserved. No compatibility status is claimed: live/preflight/replay/
rotation ordering, revision reuse, cancellation/invalidate settlement,
unresolved-auth mapping, uncertainty preservation, and hook order remain
pending independent QA relay and coordinator review. The 17 component rows
above are unchanged. No lifecycle, browser, MCP, or write behavior is
supplied in S4.

### T06-S5 trusted lifecycle notes (unverified prose, not a matrix row)

The trusted-lifecycle capability is implemented in `src/auth/`
(`lifecycle.ts` plus additive version-3 vault codec and two additive entry
exports; no new npm dependencies, config, or error codes; one unchanged
T05 resource transport plus a neutral-hook cleanup transport per facade)
per the S5 work order: read-only empty/v1/v2/v3 open with bound-account
gate, strict v3 superseded-evidence retention with older factories still
refusing v3 safely, full S4 resource/auth semantics with v3-preserving
refresh transitions, fence-first `signOut`/`replaceGrant` via one T04
`advanceSessionGeneration` with begun-commit settlement and no optimistic
repair, durable clearing before best-effort logout bounded by one shared
monotonic nonrenewable `totalDeadlineMs` window with safe settlement, clock-callback
interruption priority at both replacement deadline boundaries, and shared-deadline
admission rechecked at logout pre-dispatch and final wire handoff (no new wire
attempt after original expiry), and integrated
stale read/write/refresh suppression. S1–S4 exports and behavior are preserved. No compatibility
status is claimed: validation/retention/old-version refusal, replacement
evidence and restart isolation, offline sign-out ordering, and
representative lifecycle races remain pending independent QA relay and
coordinator review. The 17 component rows above are unchanged. No browser,
MCP, journal/creation, caching/cleanup, deletion, or successor behavior is
supplied in S5.

### T08-S3 stdio implementation scope

Current additive local evidence: [T15-S2](evidence/t15-s2-review.md) delivers
official SDK guarded creation dispatch and compiled stdio wiring on the same
Node24.21.0/npm11.19.0/SDK1.32.1/protocol2025-11-25 boundary.68/68 selected checks,
four production checks and545 stable hashes passed with isolated provider/ext4/
HTTPS, enabled saved receipt and disabled zero-mutation calls. Parent T15/S3
process recovery/lifecycle/clean reproduction remain pending; no named-host,
live-backend or release compatibility row changes are claimed.

The actual server entry now composes the accepted runtime and SDK adapter over
local stdio. Node 24.21.0 / npm 11.19.0 / SDK 1.32.1 remain pinned. Public SDK
parsing/serialization, strict UTF-8, 10 MiB input buffering, initialization gating,
fixed diagnostics, callback-based output and owned graceful cleanup implement the
settled S3 contract. See [launch and privacy notes](stdio-server.md).

Current acceptance results are recorded separately in the S3 review; historical
S2 and earlier unassigned descriptions above are prior checkpoints. No named Pi,
Google/browser, live-backend, Android, product-write or release compatibility is
implied by local stdio implementation.

Observed local boundary: actual SDK/stdin-stdout read server on Node 24.21.0 /
npm 11.19.0 / SDK 1.32.1 / protocol 2025-11-25. [T08 acceptance](evidence/t08-s3-review.md)
records active941/941 and clean T08 replay82/82, isolated provider/HTTPS and
lifecycle checks. Named hosts/live services/release remain unverified. This is
local task evidence; the 17 product compatibility rows above remain unchanged.

### T07-S1 protected login composition

The additive `src/login/index.ts` entry provides trusted setup, protected exchange,
initial/same-account session installation and explicit binding-publication recovery.
Temporary v4 vaults require trusted login recovery and remain unsupported by T08
startup. Settled grants use the existing v3 format, strict T08 config and descriptor.
No dependency, public auth/storage contract or packaging change is required.

[S1 evidence](evidence/t07-s1-review.md) records isolated Secret Service/ext4/HTTPS
and T08 read integration plus focused replay/fence/metadata checks. Browser GIS,
executable login commands, genuine Google/backend interoperability, named hosts,
Android, routine creation and release remain outside this slice. Operators cannot
yet invoke a delivered login CLI; S3 owns that delivery.

### T07-S2 secured browser helper

The additive startBrowserLoginHelper entry now reserves both fixed-port loopback
listeners before S1 challenge creation and serves the nonce-protected GIS page,
credential callback and Cancel route. Strict Host/Origin/CSRF, bounded HTTP input,
single callback admission and owned cleanup compose with S1 persistence/recovery.
No dependency, package entry, model tool or existing configuration change is made.

[S2 evidence](evidence/t07-s2-review.md) records real loopback, controlled page/GIS,
isolated S1 storage/HTTPS and unchanged-regression checks. Actual Google/browser
interoperability and CSP enforcement remain T19 gates. Fixed browser launching,
process signal wiring and operator CLI delivery remain S3; no executable login
workflow is claimed yet. The product compatibility matrix above remains unchanged.

### T07-S3 trusted CLI delivery

The compiled `node dist/cli/main.js` entry delivers setup/login/resume/cancel/
recover, fixed Linux desktop launching, fixed stderr-only guidance and bounded
owned cancellation/cleanup. Configured browser composition captures one settings
snapshot for S1 and S2. Legacy package/bin wiring remains unchanged for T18.

[S3 evidence](evidence/t07-s3-review.md) records actual process/SDK stdio workflows
with isolated Secret Service/ext4/HTTPS and a trusted controlled launcher. Direct
entry checks exercise non-browser commands, strict usage and headless failure.
The selected /usr/bin/xdg-open desktop success/timeout behavior and genuine Google/
browser interoperability are not runtime-certified by those fixtures. Named
host/backend/Android/release gates remain separate; creation remains unavailable.
The historical S2-only CLI boundary above is superseded by this delivery; the
17 product compatibility rows remain unchanged.

### T18-S2 standalone guide observations (bounded, not certification)

[S2 acceptance](evidence/t18-s2-review.md) records10/10 focused document/install/
disclosure checks,563 stable hashes and unchanged S1 runtime/dependency inputs.
The96-file candidate ships complete installation/login/server/recovery guides and
false templates, with local links/anchors and approved budget tables verified.
Extract-and-npm-ci is the sole supported route. No runtime rebuild or format change.
Installed replacement/recovery/clean parent proof remains S3; real external and
independent release gates remain pending. Matrix rows above are not promoted by
documentation or unconfigured install smoke.

### T18-S3 installed package and replacement boundary

The configured tool/server opener validates retained local operation evidence at
startup, including versions, binding and step keys, even with writes disabled.
Never-bound profiles require empty operation bytes. Validation sends no requests,
writes no private bytes and resumes nothing; the separate read-only opener retains
its prior behavior. This corrects the shared-contract startup gap under the
[user-resolved S3 work order](tasks/t18-s3-work-order.md).

The supported package route remains fresh extraction and pinned locked npm ci,
with executables separate from protected state/anchors/keys. Qualification covers
same-format replacement from a frozen pre-T18 target, explicit exact retry,
retained receipts, incompatible-state refusal and clean locked reconstruction;
exact disposition/results/limits are recorded in the [S3 review](evidence/t18-s3-review.md).
No historical released-version migration, downgrade, other OS/provider/filesystem,
real backend/Android/Google/named-host or independent release claim is introduced.
The broad component/scenario matrix remains unverified pending its owning gates.
