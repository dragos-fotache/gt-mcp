# T17 remaining slices after S1

> **T21-S1 policy supersession (2026-10-17):** shared MCP draft0.3 removes
> operationId/journal/receipt-based creation recovery. The S4 exact-recovery
> requirements and those parts of S3/S5 below are retired, not passed. Current
> runtime and prior S1 evidence still describe the old behavior. T21-S5 will adapt
> the remaining host plan to fresh-call semantics; modes/config enforcement,
> lifecycle/cancellation, output/privacy and final host acceptance remain required.
> See [T21](../tasks/t21-remove-durable-creation-recovery.md). No T17 slice is opened.

**Authority:** user,2026-10-17: “plan the rest of T17, split it into slices”.
This is a documentation-only planning assignment. S1 stays accepted/closed;
S2 is ready for separate assignment, S3–S5 are sequentially held. No implementation,
test-source edits, runtime execution, successor or release grant follows.

Normative: shared MCP draft0.2 tools/authentication/routine-creation and acceptance
scenarios; unchanged backend v1; [parent T17](../tasks/t17-pi-certification.md);
config-only policy; foundation/storage specifications and
[proportional testing](proportional-testing-policy.md). Reuse
[S1 acceptance](../evidence/t17-s1-review.md), T12/T15 lifecycle/process evidence
and T16 actual-service/Android acceptance with their existing limits.

## Outcome and fixed boundaries

Close named Pi interoperability for the pinned Pi1.1.0/Node24.21.0/npm11.19.0
candidate and actually observed MCP protocol, without a permission companion or
per-routine prompt. S1 already proves SDK print direct/deferred/codemode/nested
paths, seven tools, MCP2025-11-25, false/missing denial, true authenticated save,
small complete envelopes and ordinary receipt identity. Do not rebuild that
matrix at every slice.

Remaining uncertainty is actual CLI/mode behavior, host lifecycle/cancellation,
durable request retention across host transitions, and host output/privacy limits.
Four further outcomes keep terminal qualification, interruption, durable recovery
and final integrated acceptance separately reviewable. This replaces the original
rough two-to-three-session estimate, not any requirement. Target60–90 minutes per
slice; checkpoint at90 minutes, stop at two hours with an honest partial handoff.
Each successor needs separate assignment; elapsed time never waives verification.

Public behavior stays settled:

- Only startup operator config `writesEnabled:true` permits valid creation.
  False/missing denies before admission/mutation; invalid config fails closed.
  UI, mode, clientInfo, annotations, arguments, environment and extensions are not
  permission sources. Reads remain independently available.
- Config changes use **stop, await cleanup, update, relaunch**. Editing the file
  alone does not alter the running process. No watcher/hot reload is introduced.
  Effective disablement blocks new admission/unsent work; previous commits remain.
- Cancellation stops unsent work and retains uncertainty. A host may suppress a
  canceled reply; absence of a reply is not proof of rollback or success.
- Retain the original operationId and exact requested intent outside generated
  retry text. Explicit identical recovery uses original journal IDs/routes/bytes/
  keys under current auth/config; changed admitted intent fails operation_id_reused.
  Starting/reconnecting/resuming/forking alone never continues domain work.
- The adapter returns a complete canonical result or explicit result_too_large.
  Host display shortening is a separate observation, never a valid partial
  canonical success or permission source. Ordinary diagnostics exclude secrets
  and domain bodies; requested data may remain in host transcripts/temp output.

## S2 — Actual CLI registration and modes

**Prerequisite:** accepted S1. **Status:** planned, ready/unassigned.

Use the installed pinned Pi CLI entry and its normal file-configured native MCP
registration from a fresh private agent directory. Target one supported terminal
renderer plus actual print text, JSON and RPC interfaces. Run the interactive
journey in an owned real PTY with terminal stdin/stdout; binding an SDK context
to `interactive` does not qualify it. Use a local scripted model/provider only;
its explicit test extension is not a permission gate. Load no personal resources.

Observe seven-tool discovery/negotiation and representative read/creation calls
with false and true policy in each targeted interface, without confirmation.
SDK S1 retains the routing cross-product: select representative direct and
codemode/deferred paths across these modes rather than repeat every combination.
Check one invalid-config startup through the actual CLI. Record supported
registration/flags, observed mode/UI, stdin/stdout discipline and loaded resources.
Distinguish Pi CLI JSON/RPC stdout from the server's MCP-only stdout.

**Accept:** real CLI and real PTY observations establish the documented modes;
false/invalid policy never admits/mutates, true valid creation reaches the server,
and reads work. Client/terminal closure releases the owned server/profile; reopening
storage independently verifies release. Publish exact versions/configuration
placeholders and mode limits in `docs/pi.md`. A failed/unavailable mode stays
unverified; narrowing an advertised target needs explicit disposition, not a skip.

**Reuse/checks:** S1 native transport/provider/profile fixture and installed CLI
documentation; a small private CLI/PTY launcher only if necessary. Early syntax,
lint/format/import checks, complete active S2 cases, unchanged S1 host suite and
`test/stdio-server/sdk-startup.test.mjs`. Do not import the parked T02 approval
driver or reproduce its terminal/extension matrix.

## S3 — Host lifecycle, concurrency and effective policy changes

**Prerequisite:** accepted S2. **Status:** planned/held.

Through actual Pi calls, verify concurrent identical requests share one admitted
operation/step stream; a conflicting request cannot overwrite that intent. Use
one controlled ordering boundary, not a timing/stress campaign. Exercise host
cancellation before admission and at a representative dispatched mutation;
observe request cancellation, absence of dependent sends and preserved journal
uncertainty. Reuse accepted T15/T16 per-stage cancellation/crash proof rather than
repeat those domain matrices through every Pi mode.

Exercise explicit `/mcp reconnect` or its real public host command path, plus
normal host shutdown with a call in flight. Await actual persistence/owner
release. Change true to false only after the old process stops, relaunch and
verify blocked new admission/continuation with reads usable and journal identity
unchanged. Re-enabling/reconnecting alone must send no mutation. Trusted sign-out
must respect existing ownership refusal while Pi owns the profile; after safe
stop/release, sign-out must fence explicit continuation on reopen. Reuse accepted
T12/T15 internal in-flight generation-fence evidence rather than add an ownership
bypass to provoke a race. Login/logout stay local actions, never model tools.

**Accept:** one operation/root, no conflicting overwrite, no duplicate execution
stream; actual host cancellation/stop fences unsent steps; committed effects and
uncertainty are reported honestly. Reconnect/relaunch obey effective config/auth
and cleanly release profile ownership. Retained pending work is not resumed here
merely to make the test finish; explicit recovery belongs to S4.

**Reuse/checks:** native nested call/event observation, existing held HTTPS fixture,
encrypted journal inspection after release, actual trusted CLI. Complete S3 cases
plus unchanged S1; `test/create-stdio/recovery-stop.test.mjs`,
`test/create-stdio/lifecycle.test.mjs` and
`test/stdio-server/framing-lifecycle.test.mjs`. Add a focused T12 regression only
if a lifecycle repair affects it. No full account-removal/refresh campaign.

## S4 — Exact recovery across reply loss, restart and fork

**Prerequisite:** accepted S3. **Status:** planned/held.

Persist actual private Pi sessions and the original operationId/request before
dispatch. Observe a saved receipt whose final MCP delivery is deliberately lost
before host consumption, and one representative dispatched-but-unconfirmed step.
Keep loss at a declared boundary; use a small fixed drop/hold seam only if the
existing one is insufficient. Do not fabricate Pi tool success or substitute a
different transport/client for the named-host call.

Use real Pi session resume and fork APIs or CLI paths against those persisted
sessions. Include one persisted deferred-tool session and verify retained original
request arguments and loaded tool state. Restart/resume/fork/reconnect without an
explicit call sends no mutation. Then explicitly repeat the stored request: pending-step replay keeps
exact method/route/body/key, confirmed steps are not recreated, and saved receipt
repeat causes no mutation. Changed intent under that admitted ID must refuse.
Exercise matching live authorization and a disabled-config/auth fence without
allocating replacement identities. Observe server restart as well as host/session
transition; a new JSON-RPC/tool-call ID must not become a new operationId.

**Accept:** the actual host/user-controlled retained request survives delivery loss
and branch/process transitions; server journal and replay observations independently
match original IDs/bytes/keys. Preserve one logical root/effect and explicit
uncertainty; no autonomous continuation or request reconstruction from a summary.
Fixture replay/effect observations are host-boundary proof; T16's actual DB/batch
evidence remains the authority for real backend idempotent effects.

**Reuse/checks:** T15 final-reply loss and durable recovery fixtures, S3 stop/cancel
state, public Pi persisted-session operations. Complete S4 cases plus unchanged
S1–S3, `test/create-stdio/recovery-stop.test.mjs` and
`test/create-stdio/policy-identity.test.mjs`. Keep mandatory per-step backend fault
evidence referenced; do not repeat R01–R03's entire matrix at the host boundary.

## S5 — Output/privacy and integrated parent acceptance

**Prerequisite:** accepted S4. **Status:** planned/held.

Use one independently specified valid aggregate large enough to cross Pi's direct
display threshold and a configured server-budget refusal. Include sentinel fields
in the middle as well as the ends, lossless revision and hostile instruction text.
Check raw complete server envelopes/serialized text and canonical codemode data;
validate the actual advertised schemas. Observe result_too_large explicitly when
the complete result exceeds the server allowance; no truncated successful record.

The installed Pi docs describe direct text above20KB as middle-elided with a full
output temp file, while codemode receives the whole CallToolResult. This is a
test target, not an assumed pass. Verify the direct display marker/full-output
artifact and a usable complete-data path. Qualify codemode for complete canonical
data; if full-file retrieval is advertised, exercise it through an explicitly
enabled read tool against that owned synthetic file. A script's deliberate
summary is labeled a summary, never a complete canonical result. Record direct
display limitations and temporary-file/transcript retention accurately. Do not
silently reduce default budgets or patch installed Pi to obtain a pass. An
unresolved complete-output/contract conflict blocks the affected claim and needs
user resolution.

Hostile fitness text remains data: observe it intact while false config cannot
be enabled by it or by attempted client/argument metadata. Inspect server/CLI/Pi
ordinary diagnostics, process arguments and fixture transcripts/output artifacts
for synthetic secret markers; requested fitness content belongs only in intended
results/host copies. Clean owned temp/session/config/provider resources. This is
deterministic boundary/privacy evidence, not live-model prompt-injection immunity
or an OS sandbox claim.

Finish scenario reconciliation for M01/M02/M10, C09–C12 and T17 portions of A07/A09
and R04/R05. Map each subrequirement to a specific new or accepted evidence item;
distinguish host, official SDK, local lifecycle and actual-service evidence.
Only S5 may close parent T17, after all required outcomes and final checks pass.
T19 Google/browser and independent T20 remain unpassed by T17.

**Final acceptance floor:** complete active `test/pi-integration/` owning suite;
complete `test/create-stdio/`, `test/create-protocol/`, `test/stdio-server/`;
`test/fault/t15/s1-runtime.test.mjs` and
`test/read-protocol/result-budget.test.mjs`. Add specific unchanged regressions
for any actual repair. Record the expanded exact file selection before execution;
no whole-repository or parked-T02 pass claim. Run locked clean reconstruction
(`npm ci --ignore-scripts`), the four production checks, exact compiled/installed
host identity, and the complete owning/final regression selection against stable
workspace and clean targets. No install/build while that target is executing.
Document any prose-only closure separately rather than claim another runtime replay.

## Common edit, execution and evidence rules

At assignment, record a concise slice work order with exclusive edit scope,
actual environment/command grant, milestone clock and exact acceptance selection.
Primary agent owns tests, review and integration; no standing team/role relay.
Normal edit scope is `test/pi-integration/`, T17 fixture-specific helpers,
`docs/pi.md` and task/evidence/status notes. Narrow shared fixture/production repairs
require a reproduced T17 defect and recorded scope before editing; public contract
decisions go to the user. No dependency/manifest/compiler/storage-format changes,
shared-contract edits, generalized interception framework or synthetic host clone.

Use provisioned disposable Node24.21.0/npm11.19.0 via T01_NODE_HOME, installed
locked Pi/SDK artifacts, fresh private unlocked Secret Service/bus/ext4 roots and
trusted fixture TLS. All write-enabled operations stay inside those fixtures.
Permitted execution when individually assigned: scoped syntax/types/lint/format/
import checks, relevant production checks/build, exact isolated test selections,
owned offline Pi CLI/RPC/PTY/SDK children and trusted fixture lifecycle actions.
S5 additionally owns disposable locked reconstruction. Planning itself runs only
read-only inspection and documentation/link checks.

Do not use/reconfigure project or personal `.pi`, ambient credentials/providers,
live model/backend/Google/Android sessions, global installations or unrelated
processes. Use private Pi agent/session/config roots, a minimal environment,
offline model/provider and only required tools/resources. Preserve earlier
uncommitted work and parked experiments. No staging/commit, publication,
production enablement, release or automatic successor. Missing safe toolchain,
PTY, isolated secret facility or host capability is a blocker, not a mocked pass.

Each slice delivers scoped runnable cases, exact sanitized commands/results,
versions/package integrity and source/output identity, failed-attempt history,
primary-agent specification/oracle review, owned cleanup, a concise handoff and
task/status updates. Early static checks precede large executions; repairs get
focused checks, then the final active owning/relevant selection. No skipped tests
count as passes. Stop for unsafe ownership/logging, a public contract conflict,
unavailable isolated input, substantial harness expansion or the hard time limit.
