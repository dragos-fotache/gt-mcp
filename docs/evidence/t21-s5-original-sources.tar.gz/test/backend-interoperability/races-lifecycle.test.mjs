/* global AbortController */
// Shared MCP R09/R10 and A07/A08/R11/R12: actual service effects, private owner.
import fs from "node:fs";
import { randomUUID } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { describe, it } from "vitest";
import { openProfile } from "../../dist/storage/index.js";
import { openLifecycleSessionState } from "../../dist/auth/index.js";
import { openLoginMetadata } from "../../dist/login/metadata.js";
import { signOutProfile, retireProfileOperation } from "../../dist/lifecycle/index.js";
import { openOperationRepository, decodeOperationStore } from "../../dist/operations/index.js";
import { createCreationService } from "../../dist/creation/index.js";
import { check, fixture, processSession, waitFor } from "./helpers.mjs";
import { checkpointChild } from "./checkpoint-helper.mjs";

const signal = () => new AbortController().signal;
async function tool(session, name, args = {}) {
  const result = await session.client.callTool({ name, arguments: args });
  check(
    result.content[0].text === JSON.stringify(result.structuredContent),
    "MCP envelopes differ",
  );
  return result.structuredContent;
}
async function close(session) {
  if (!session) return;
  await session.close("eof");
  check(session.stderr() === "", "Unexpected MCP diagnostics");
}
function binding(f) {
  return JSON.parse(fs.readFileSync(f.descriptorPath)).binding;
}
async function profile(f) {
  return openProfile({ ...f.privateProfileOptions(), expectedBinding: binding(f) });
}
async function stored(f) {
  const owner = await profile(f);
  try {
    const { origin, accountUuid, profileGenerationId } = owner.binding;
    return decodeOperationStore(await owner.readOperationStoreBytes(), {
      origin,
      accountUuid,
      profileGenerationId,
    }).operations;
  } finally {
    await owner.close();
  }
}
async function privateBytes(f) {
  const owner = await profile(f);
  try {
    return {
      vault: Buffer.from(await owner.readVaultBytes()),
      operations: Buffer.from(await owner.readOperationStoreBytes()),
    };
  } finally {
    await owner.close();
  }
}
async function checkpoint(f, intent, step) {
  await checkpointChild(
    {
      location: f.privateProfileOptions(),
      config: JSON.parse(fs.readFileSync(f.configPath)),
      intent,
      step,
      phase: "after-confirmation",
    },
    () => check(f.requests.length === 0, "Checkpoint opening sent HTTP"),
  );
  return (await stored(f))[0];
}
async function edited(f, root, other) {
  const current = await f.request("GET", `/v1/routines/${root}`, undefined, other);
  check(current.status === 200, "Other client could not read its draft");
  const body = {
    id: root,
    name: "T16 other client edit",
    isDraft: true,
    exercises: current.value.exercises.map((entry) => ({
      id: entry.id,
      exerciseId: entry.exerciseId,
      position: entry.position,
      restDurationSeconds: entry.restDurationSeconds + 1,
      sets: entry.sets.map((set) => ({
        id: set.id,
        position: set.position,
        repetitions: set.repetitions,
        weightKg: set.weightKg,
      })),
    })),
  };
  // Empty drafts need valid children for save, and populated drafts retain IDs.
  if (body.exercises.length === 0)
    body.exercises = [
      {
        id: randomUUID(),
        exerciseId: f.customs[0],
        position: 0,
        restDurationSeconds: 30,
        sets: [],
      },
    ];
  const result = await f.request("PUT", `/v1/routines/${root}`, body, other);
  check(result.status === 200, "Actual other-client edit failed");
  return body;
}
async function sentinel(f, other) {
  const id = randomUUID();
  check(
    (await f.request("POST", "/v1/routines", { id }, other)).status === 201,
    "Unrelated routine setup failed",
  );
  return id;
}
async function publishTransition(metadata, source, kind, action) {
  const target = { ...source, sessionGeneration: source.sessionGeneration + 1 };
  const receipt = { version: 1, kind, transitionId: randomUUID(), from: source, to: target };
  await metadata.prepareReceipt(receipt);
  const next = await action();
  check(isDeepStrictEqual(next, target), "Lifecycle generation transition differs");
  await metadata.publishDescriptor(source, next);
  await metadata.removeReceipt(receipt);
  return next;
}

describe("T16-S6 actual other-client races", () => {
  for (const change of ["edit", "delete"]) {
    it(`${change} before explicit resume stops unsent work and preserves unrelated state`, async () => {
      const f = await fixture();
      let session;
      try {
        const intent = f.intent();
        const journal = await checkpoint(f, intent, change === "edit" ? "draft" : "populate");
        const root = journal.routineId,
          other = await f.newSession();
        const unrelated = await sentinel(f, other);
        if (change === "edit") await edited(f, root, other);
        else
          check(
            (await f.request("DELETE", `/v1/routines/${root}`, undefined, other)).status === 204,
            "Actual other-client delete failed",
          );
        const beforeUnrelated = f.observe(unrelated);
        const before = f.observe(root),
          count = f.mutations.length;
        session = await processSession(f.configPath);
        const result = await tool(session, "create_routine", intent);
        check(
          !result.ok &&
            result.error.code === "concurrent_modification" &&
            result.error.lastConfirmedStep === (change === "edit" ? "draft" : "populate") &&
            result.error.outcomeUnknown === false,
          "Pre-resume divergence was not reported truthfully",
        );
        check(
          f.mutations.length === count &&
            isDeepStrictEqual(f.observe(root), before) &&
            isDeepStrictEqual(f.observe(unrelated), beforeUnrelated),
          "Divergent recovery rewrote confirmed or unrelated state",
        );
        check(
          isDeepStrictEqual(await tool(session, "create_routine", intent), result) &&
            f.mutations.length === count,
          "Terminal conflict retried remote work",
        );
      } finally {
        await close(session);
        await f.close();
      }
    }, 60000);
  }

  for (const stage of ["populate", "save"]) {
    it(`${stage}: actual edit after advisory GET preserves last-write-wins and truthful saved conflict`, async () => {
      const f = await fixture();
      let session;
      try {
        const intent = f.intent();
        const journal = await checkpoint(f, intent, stage === "populate" ? "draft" : "populate");
        const root = journal.routineId,
          other = await f.newSession();
        let otherBody, beforeRace;
        f.state.beforeRequest = async ({ mutation, step }) => {
          if (!mutation || step !== stage) return;
          f.state.beforeRequest = null;
          // This executes only once the real adapter has completed advisory GET.
          otherBody = await edited(f, root, other);
          beforeRace = f.observe(root);
        };
        session = await processSession(f.configPath);
        const result = await tool(session, "create_routine", intent);
        check(!f.state.hookFailed && otherBody && beforeRace, "Advisory race was not reached");
        const final = f.observe(root);
        check(
          final.roots === 1 &&
            final.draft === false &&
            final.revision === 4 &&
            final.batches === 4 &&
            final.replays === 4,
          "Actual race history duplicated or rolled back effects",
        );
        const count = f.mutations.length;
        if (stage === "populate") {
          check(
            result.ok && result.data.routineId === root,
            "Actual LWW populate did not complete",
          );
          const body = JSON.parse(f.mutations.find((m) => m.method === "PUT").body);
          check(
            final.name === intent.name &&
              isDeepStrictEqual(final.children, body.exercises) &&
              beforeRace.name === otherBody.name,
            "Actual PUT did not overwrite the advisory race under LWW",
          );
        } else {
          check(
            !result.ok &&
              result.error.code === "concurrent_modification" &&
              result.error.lastConfirmedStep === "save" &&
              result.error.outcomeUnknown === false &&
              final.name === intent.name &&
              isDeepStrictEqual(final.children, otherBody.exercises),
            "Confirmed save conflict hid the other client's actual saved shape",
          );
        }
        check(
          isDeepStrictEqual(await tool(session, "create_routine", intent), result) &&
            f.mutations.length === count &&
            isDeepStrictEqual(f.observe(root), final),
          "Repeating settled race changed real remote history",
        );
      } finally {
        await close(session);
        await f.close();
      }
    }, 60000);
  }
});

describe("T16-S6 actual service and local lifecycle composition", () => {
  for (const kind of ["read", "write"]) {
    it(`local sign-out discards a held real ${kind} result and fences unsent steps`, async () => {
      const f = await fixture();
      let owner, auth, repository, pending, release;
      const held = new Promise((resolve) => {
        release = resolve;
      });
      let entered = false;
      try {
        owner = await profile(f);
        const source = owner.binding,
          metadata = await openLoginMetadata(f.configPath);
        auth = await openLifecycleSessionState({
          profile: owner,
          transportConfig: { origin: f.origin },
        });
        f.state.afterResponse = async ({ mutation, route }) => {
          if (
            (kind === "write" && mutation?.route === "/v1/routines") ||
            (kind === "read" && route.startsWith("/v1/routines?"))
          ) {
            entered = true;
            await held;
          }
        };
        if (kind === "write") {
          repository = openOperationRepository({
            owner,
            reads: auth,
            config: JSON.parse(fs.readFileSync(f.configPath)),
          });
          const service = createCreationService({ repository, session: auth });
          pending = service.create(source, f.intent(), signal()).catch((error) => error);
        } else pending = auth.listRoutines(source, {}, signal()).catch((error) => error);
        await waitFor(() => entered, "Real response did not reach held delivery boundary");
        const root = kind === "write" ? JSON.parse(f.mutations[0].body).id : null;
        if (root) check(f.observe(root).revision === 1, "Held real mutation was not committed");
        await publishTransition(metadata, source, "sign-out", () => auth.signOut(source));
        release();
        const result = await pending;
        check(
          result &&
            !result.ok &&
            !("data" in result) &&
            (result.code === "operation_interrupted" ||
              result.code === "generation_mismatch" ||
              result.error?.code === "operation_interrupted"),
          "Obsolete generation exposed a real result",
        );
        check(f.mutations.length === (root ? 1 : 0), "Generation fence dispatched dependent work");
        if (root)
          check(
            f.observe(root).revision === 1 && f.observe(root).draft === true,
            "Local fence pretended to roll back an actual committed draft",
          );
        repository?.close();
        repository = undefined;
        auth.invalidate();
        auth = undefined;
        await owner.close();
        owner = undefined;
        const bytes = await privateBytes(f),
          vault = JSON.parse(bytes.vault);
        check(
          vault.grant === null &&
            binding(f).sessionGeneration === source.sessionGeneration + 1 &&
            (kind === "read" || bytes.operations.length > 0),
          "Sign-out lost recovery material or retained credentials",
        );
      } finally {
        release();
        if (pending) await pending;
        repository?.close();
        auth?.invalidate();
        await owner?.close();
        await f.close();
      }
    }, 60000);
  }

  it("real fresh same-account grant resumes exact uncertain bytes; different account never adopts journals", async () => {
    const f = await fixture();
    let session, owner, auth;
    try {
      const intent = f.intent();
      f.state.lose = "populate";
      session = await processSession(f.configPath);
      const lost = await tool(session, "create_routine", intent);
      check(!lost.ok && lost.error.outcomeUnknown, "Actual uncertain prefix not established");
      await close(session);
      session = undefined;
      const oldBytes = (await privateBytes(f)).operations;
      await signOutProfile({ configPath: f.configPath }, signal());
      check(
        (await privateBytes(f)).operations.equals(oldBytes),
        "Sign-out erased the actual pending journal",
      );
      owner = await profile(f);
      auth = await openLifecycleSessionState({
        profile: owner,
        transportConfig: { origin: f.origin },
      });
      const source = owner.binding;
      const rejected = await auth
        .replaceGrant(source, Buffer.from(JSON.stringify(f.foreign)), signal())
        .catch((error) => error);
      check(
        rejected.code === "operation_interrupted" &&
          Buffer.from(await owner.readOperationStoreBytes()).equals(oldBytes) &&
          JSON.parse(Buffer.from(await owner.readVaultBytes())).grant === null,
        "Different verified account adopted or destroyed old recovery evidence",
      );
      const fresh = await f.newSession(),
        metadata = await openLoginMetadata(f.configPath);
      await publishTransition(metadata, source, "install", () =>
        auth.replaceGrant(source, Buffer.from(JSON.stringify(fresh)), signal()),
      );
      auth.invalidate();
      auth = undefined;
      await owner.close();
      owner = undefined;
      check(
        (await privateBytes(f)).operations.equals(oldBytes),
        "Same binding changed pending exact identity",
      );
      const before = f.observe(lost.error.routineId);
      session = await processSession(f.configPath);
      check(f.mutations.length === 2, "Reauthentication/startup resumed work autonomously");
      const saved = await tool(session, "create_routine", intent);
      const final = f.observe(lost.error.routineId);
      check(
        saved.ok &&
          saved.data.routineId === lost.error.routineId &&
          final.revision === 3 &&
          final.batches === 3 &&
          before.revision === 2 &&
          f.mutations.length === 4 &&
          f.mutations[1].body.equals(f.mutations[2].body) &&
          f.mutations[1].key === f.mutations[2].key,
        "Explicit same-account recovery changed identity or duplicated real effects",
      );
    } finally {
      await close(session);
      auth?.invalidate();
      await owner?.close();
      await f.close();
    }
  }, 60000);

  it("retirement of an actual uncertain draft erases payloads, reserves intent and leaves remote history", async () => {
    const f = await fixture();
    let session;
    try {
      const intent = f.intent();
      f.state.lose = "draft";
      session = await processSession(f.configPath);
      const lost = await tool(session, "create_routine", intent);
      check(!lost.ok && lost.error.outcomeUnknown, "Actual committed uncertain draft missing");
      await close(session);
      session = undefined;
      const before = f.observe(lost.error.routineId);
      await retireProfileOperation({ configPath: f.configPath }, intent.operationId, signal());
      const records = await stored(f);
      check(
        records.length === 1 &&
          records[0].kind === "retired" &&
          !("steps" in records[0]) &&
          !("intent" in records[0]),
        "Retirement retained mutable request payloads",
      );
      session = await processSession(f.configPath);
      for (const input of [intent, { ...intent, name: "Changed retired intent" }]) {
        const result = await tool(session, "create_routine", input);
        check(!result.ok && result.error.code === "recovery_unavailable", "Retired ID was reused");
      }
      check(
        f.mutations.length === 1 && isDeepStrictEqual(f.observe(lost.error.routineId), before),
        "Local retirement changed real state or created replacement work",
      );
    } finally {
      await close(session);
      await f.close();
    }
  }, 60000);
});
