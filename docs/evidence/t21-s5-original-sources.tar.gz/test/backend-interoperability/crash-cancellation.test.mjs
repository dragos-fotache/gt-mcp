/* global AbortController */
// MCP R01–R08: real durable profile/process/service effects with narrow wire faults.
import fs from "node:fs";
import { randomUUID } from "node:crypto";
import { isDeepStrictEqual } from "node:util";
import { describe, it } from "vitest";
import { decodeOperationStore } from "../../dist/operations/index.js";
import { check, fixture, processSession, waitFor } from "./helpers.mjs";
import { checkpointChild } from "./checkpoint-helper.mjs";

const steps = ["draft", "populate", "save"];
async function tool(session, name, args = {}) {
  const result = await session.client.callTool({ name, arguments: args });
  check(
    result.content[0].text === JSON.stringify(result.structuredContent),
    "MCP envelopes differ",
  );
  return result.structuredContent;
}
async function close(session) {
  if (!session) return;
  await session.close("eof");
  check(session.stderr() === "", "MCP process emitted unexpected diagnostics");
}
async function stored(f) {
  return f.withPrivateProfile(async (owner) => {
    const { origin, accountUuid, profileGenerationId } = owner.binding;
    return decodeOperationStore(await owner.readOperationStoreBytes(), {
      origin,
      accountUuid,
      profileGenerationId,
    }).operations;
  });
}
function assertPrefix(f, root, count) {
  const observed = f.observe(root);
  check(
    observed.roots === (count === 0 ? 0 : 1) &&
      observed.revision === (count === 0 ? null : count) &&
      observed.replays === count &&
      observed.batches === count &&
      observed.entries === (count < 2 ? 0 : 3) &&
      observed.sets === (count < 2 ? 0 : 3),
    "Independent real DB prefix differs from committed steps",
  );
  return observed;
}
function assertSaved(f, result, root) {
  check(
    result.ok && result.data.status === "saved" && result.data.routineId === root,
    "Explicit recovery did not preserve the original saved root",
  );
  const observed = assertPrefix(f, root, 3);
  check(
    observed.draft === false && observed.changes.length === 3,
    "Real saved/sync history is incomplete or duplicated",
  );
  const populate = f.mutations.find((request) => request.method === "PUT");
  check(
    isDeepStrictEqual(observed.children, JSON.parse(populate.body).exercises),
    "Real persisted children/order/values differ from the original populated request",
  );
}
function assertWireIdentity(f, journal) {
  for (const actual of f.mutations) {
    const expected = journal.steps.find(
      (step) => step.method === actual.method && step.route === actual.route,
    );
    check(
      expected &&
        expected.resourceKey === actual.key &&
        Buffer.from(expected.bodyBase64, "base64").equals(actual.body),
      "Interrupted operation changed persisted method/route/key/body identity",
    );
  }
}

describe("T16-S5 actual process/crash/cancellation boundaries", () => {
  for (const step of steps)
    for (const phase of ["after-dispatch-mark", "after-confirmation"]) {
      it(`${step}: ${phase} survives process exit with exact identity and explicit-only continuation`, async () => {
        const f = await fixture();
        let session;
        try {
          const intent = f.intent();
          await checkpointChild(
            {
              location: f.privateProfileOptions(),
              config: JSON.parse(fs.readFileSync(f.configPath)),
              intent,
              step,
              phase,
            },
            () => check(f.requests.length === 0, "Checkpoint child opening sent autonomous HTTP"),
          );
          const records = await stored(f);
          check(
            records.length === 1 && records[0].kind === "journal",
            "Interrupted durable journal is missing",
          );
          const journal = records[0],
            index = steps.indexOf(step),
            root = journal.routineId;
          const committed = index + (phase === "after-confirmation" ? 1 : 0);
          assertPrefix(f, root, committed);
          check(
            journal.steps[index].state ===
              (phase === "after-confirmation" ? "confirmed" : "dispatch-possible") &&
              f.mutations.length === committed,
            "Durable checkpoint advanced or lost its dispatch/confirmation boundary",
          );
          assertWireIdentity(f, journal);
          const before = f.requests.length,
            mutationStart = f.mutations.length;
          session = await processSession(f.configPath);
          check(
            f.requests.length === before,
            "MCP opening resumed an interrupted operation autonomously",
          );
          const saved = await tool(session, "create_routine", intent);
          assertSaved(f, saved, root);
          assertWireIdentity(f, journal);
          check(
            isDeepStrictEqual(
              f.mutations.slice(mutationStart).map((request) => request.route),
              journal.steps.slice(committed).map((request) => request.route),
            ),
            "Recovery repeated a confirmed step or skipped an unsent original step",
          );
          await close(session);
          session = undefined;
          const [receipt] = await stored(f);
          check(
            receipt.kind === "receipt" && isDeepStrictEqual(receipt.result, saved),
            "Explicit recovery did not persist its original terminal receipt",
          );
        } finally {
          await close(session);
          await f.close();
        }
      }, 60000);
    }

  it("returns the durable saved receipt after real commit and lost final MCP delivery", async () => {
    const f = await fixture();
    let session;
    try {
      const intent = f.intent();
      session = await processSession(f.configPath);
      let lost;
      void session.loseSavedReply().then((result) => {
        lost = result;
      });
      const delivered = session.client.callTool({ name: "create_routine", arguments: intent }).then(
        () => true,
        () => false,
      );
      await waitFor(() => lost !== undefined, "Saved MCP reply did not reach the loss boundary");
      await close(session);
      session = undefined;
      check(!(await delivered), "Discarded MCP result was delivered to the SDK caller");
      const [receipt] = await stored(f),
        root = JSON.parse(f.mutations[0].body).id;
      check(
        receipt.kind === "receipt" && isDeepStrictEqual(receipt.result, lost.structuredContent),
        "Lost delivered result was not already a durable original receipt",
      );
      const observed = assertPrefix(f, root, 3),
        before = f.requests.length;
      session = await processSession(f.configPath);
      check(f.requests.length === before, "Receipt reopening sent autonomous HTTP");
      const repeated = await tool(session, "create_routine", intent);
      check(
        isDeepStrictEqual(repeated, receipt.result) &&
          f.mutations.length === 3 &&
          isDeepStrictEqual(f.observe(root), observed),
        "Lost saved delivery caused new writes or changed receipt/history",
      );
      await close(session);
      session = undefined;
    } finally {
      await close(session);
      await f.close();
    }
  }, 60000);

  for (const step of steps) {
    it(`${step}: SDK cancellation after actual commit retains the prefix and exact explicit recovery`, async () => {
      const f = await fixture();
      let session, release, held;
      try {
        const intent = f.intent(),
          index = steps.indexOf(step);
        session = await processSession(f.configPath);
        if (step === "draft") {
          const before = new AbortController();
          before.abort();
          const canceled = await session.client
            .callTool({ name: "create_routine", arguments: intent }, undefined, {
              signal: before.signal,
            })
            .then(
              () => false,
              () => true,
            );
          check(
            canceled && f.requests.length === 0 && f.mutations.length === 0,
            "Pre-admission cancellation dispatched real HTTP",
          );
          await close(session);
          session = undefined;
          check((await stored(f)).length === 0, "Pre-admission cancellation reserved durable work");
          session = await processSession(f.configPath);
        }
        const hold = new Promise((resolve) => {
          release = resolve;
        });
        f.state.afterResponse = async ({ mutation, step: current }) => {
          if (!mutation || current !== step) return;
          f.state.afterResponse = null;
          held = mutation;
          await hold;
        };
        const controller = new AbortController();
        const canceled = session.client
          .callTool({ name: "create_routine", arguments: intent }, undefined, {
            signal: controller.signal,
          })
          .then(
            () => false,
            () => true,
          );
        await waitFor(
          () => held !== undefined,
          "Real stage response did not reach cancellation gate",
        );
        const root = JSON.parse(f.mutations[0].body).id;
        assertPrefix(f, root, index + 1);
        controller.abort();
        check(await canceled, "SDK delivered a canceled workflow result");
        await waitFor(
          () => held.disconnected,
          "Cancellation did not close the held downstream request",
          2000,
        );
        release();
        await session.client.listTools();
        await close(session);
        session = undefined;
        check(
          !f.state.hookFailed && f.mutations.length === index + 1,
          "Cancellation dispatched dependent work or failed its response gate",
        );
        const [journal] = await stored(f);
        check(
          journal.kind === "journal" &&
            journal.steps[index].state === "dispatch-possible" &&
            journal.confirmed?.step === (index === 0 ? undefined : steps[index - 1]),
          "Canceled real result was falsely confirmed or lost pending evidence",
        );
        const before = f.requests.length;
        session = await processSession(f.configPath);
        check(f.requests.length === before, "Canceled startup resumed work autonomously");
        assertSaved(f, await tool(session, "create_routine", intent), root);
        assertWireIdentity(f, journal);
        check(
          f.mutations.length === 4,
          "Explicit canceled recovery duplicated or omitted its exact replay",
        );
        await close(session);
        session = undefined;
      } finally {
        release?.();
        await close(session);
        await f.close();
      }
    }, 60000);
  }

  it("preserves original identity when an injected Retry-After exceeds budget, then explicitly completes on the real service", async () => {
    const f = await fixture();
    let session;
    try {
      const intent = f.intent();
      f.state.rateLimit = "draft";
      session = await processSession(f.configPath);
      const limited = await tool(session, "create_routine", intent);
      check(
        !limited.ok &&
          limited.error.code === "rate_limited" &&
          limited.error.retryable &&
          limited.error.retryAfterSeconds === 60 &&
          f.mutations.length === 1 &&
          f.mutations[0].status === 429,
        "Retry-After was shortened/retried or reported incorrectly",
      );
      const root = JSON.parse(f.mutations[0].body).id;
      assertPrefix(f, root, 0);
      await close(session);
      session = undefined;
      const [journal] = await stored(f);
      check(
        journal.kind === "journal" && journal.terminal === null,
        "Exhausted rate-limit attempt lost unresolved durable identity",
      );
      f.state.rateLimit = null;
      const before = f.requests.length;
      session = await processSession(f.configPath);
      check(f.requests.length === before, "Rate-limit restart resumed work autonomously");
      assertSaved(f, await tool(session, "create_routine", intent), root);
      assertWireIdentity(f, journal);
      check(f.mutations.length === 4, "Explicit rate-limit repeat changed execution identity");
      await close(session);
      session = undefined;
    } finally {
      await close(session);
      await f.close();
    }
  }, 60000);

  it("retains a real save validation rejection without restoring another client's committed draft", async () => {
    const f = await fixture();
    let session;
    try {
      const intent = f.intent();
      f.state.beforeRequest = async ({ mutation, step }) => {
        if (!mutation || step !== "save") return;
        f.state.beforeRequest = null;
        const populated = JSON.parse(f.mutations.find((request) => request.method === "PUT").body);
        check(
          (
            await f.request("PUT", mutation.route.replace(/\/save$/, ""), {
              ...populated,
              exercises: [],
            })
          ).status === 200,
          "Actual draft-clear fixture mutation failed",
        );
      };
      session = await processSession(f.configPath);
      const rejected = await tool(session, "create_routine", intent);
      check(
        !f.state.hookFailed &&
          !rejected.ok &&
          rejected.error.code === "validation_error" &&
          rejected.error.lastConfirmedStep === "populate" &&
          !rejected.error.outcomeUnknown &&
          f.mutations.length === 3 &&
          f.mutations[2].status === 422,
        "Actual save rejection did not become truthful permanent history",
      );
      const root = JSON.parse(f.mutations[0].body).id,
        observed = f.observe(root);
      check(
        observed.roots === 1 &&
          observed.draft &&
          observed.revision === 3 &&
          observed.entries === 0 &&
          observed.sets === 0 &&
          observed.batches === 3 &&
          observed.replays === 4,
        "Save rejection restored/rolled back the independently committed empty draft",
      );
      await close(session);
      session = undefined;
      session = await processSession(f.configPath);
      check(
        isDeepStrictEqual(await tool(session, "create_routine", intent), rejected) &&
          f.mutations.length === 3 &&
          isDeepStrictEqual(f.observe(root), observed),
        "Permanent save rejection repeated a mutation or changed history",
      );
      await close(session);
      session = undefined;
    } finally {
      await close(session);
      await f.close();
    }
  }, 60000);

  it("fails closed on actual backend key reuse without creating replacement identity", async () => {
    const f = await fixture();
    let session, peer;
    try {
      const intent = f.intent();
      f.state.beforeRequest = async ({ mutation, step }) => {
        if (!mutation || step !== "draft") return;
        f.state.beforeRequest = null;
        peer = randomUUID();
        check(
          peer !== JSON.parse(mutation.body).id &&
            (await f.request("POST", "/v1/routines", { id: peer }, f.grant, mutation.key))
              .status === 201,
          "Actual independent key claim failed",
        );
      };
      session = await processSession(f.configPath);
      const rejected = await tool(session, "create_routine", intent);
      check(
        !f.state.hookFailed &&
          !rejected.ok &&
          rejected.error.code === "idempotency_key_reused" &&
          rejected.error.lastConfirmedStep === "none" &&
          !rejected.error.outcomeUnknown &&
          f.mutations.length === 1 &&
          f.mutations[0].status === 409,
        "Actual key reuse regenerated identity or dispatched dependent work",
      );
      const root = JSON.parse(f.mutations[0].body).id,
        observed = f.observe(root),
        peerState = f.observe(peer);
      check(
        observed.roots === 1 &&
          observed.revision === null &&
          observed.replays === 1 &&
          observed.batches === 0 &&
          peerState.revision === 1 &&
          peerState.batches === 1 &&
          peerState.draft,
        "Backend key reuse changed the independently claimed root/history",
      );
      await close(session);
      session = undefined;
      session = await processSession(f.configPath);
      check(
        isDeepStrictEqual(await tool(session, "create_routine", intent), rejected) &&
          f.mutations.length === 1 &&
          isDeepStrictEqual(f.observe(peer), peerState),
        "Terminal key-reuse repeat chose a replacement key/root",
      );
      await close(session);
      session = undefined;
    } finally {
      await close(session);
      await f.close();
    }
  }, 60000);

  for (const corruption of ["malformed JSON", "unrelated target identity"]) {
    it(`keeps ${corruption} in a genuine success uncertain until exact real replay settles it`, async () => {
      const f = await fixture();
      let session;
      try {
        const intent = f.intent();
        f.state.malformed = "draft";
        f.state.corruptIdentity = corruption === "unrelated target identity";
        session = await processSession(f.configPath);
        const uncertain = await tool(session, "create_routine", intent);
        check(
          !uncertain.ok &&
            uncertain.error.code === "internal_error" &&
            uncertain.error.outcomeUnknown &&
            uncertain.error.lastConfirmedStep === "none" &&
            f.state.malformedSent &&
            f.mutations.length === 1,
          "Corrupted success fabricated confirmation or advanced dependent work",
        );
        const root = JSON.parse(f.mutations[0].body).id;
        assertPrefix(f, root, 1);
        await close(session);
        session = undefined;
        const [journal] = await stored(f);
        check(
          journal.kind === "journal" &&
            journal.steps[0].state === "dispatch-possible" &&
            journal.confirmed === null,
          "Malformed successful response lost original uncertainty",
        );
        f.state.malformed = null;
        const before = f.requests.length;
        session = await processSession(f.configPath);
        check(f.requests.length === before, "Malformed-response reopen resumed work autonomously");
        assertSaved(f, await tool(session, "create_routine", intent), root);
        assertWireIdentity(f, journal);
        check(
          f.mutations.length === 4,
          "Malformed-success replay duplicated or changed original work",
        );
        await close(session);
        session = undefined;
      } finally {
        await close(session);
        await f.close();
      }
    }, 60000);
  }
});
