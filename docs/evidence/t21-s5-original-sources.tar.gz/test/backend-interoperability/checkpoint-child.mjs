/* global AbortController */
// Fixed child: actual production owner/auth/repository, public durable checkpoints.
// Private input enters stdin; stdout contains only a fixed checkpoint marker.
import fs from "node:fs";
import { openProfile } from "../../dist/storage/index.js";
import { openLifecycleSessionState } from "../../dist/auth/index.js";
import { openOperationRepository } from "../../dist/operations/index.js";
import { createCreationExecutor } from "../../dist/creation/index.js";

let owner, auth, repository;
try {
  let text = "";
  for await (const chunk of process.stdin) text += chunk;
  const input = JSON.parse(text);
  owner = await openProfile(input.location);
  auth = await openLifecycleSessionState({
    profile: owner,
    transportConfig: {
      origin: owner.binding.origin,
      testCaPem: fs.readFileSync(process.env.GT_S1_FIXTURE_CERT_FILE),
    },
  });
  repository = openOperationRepository({ owner, reads: auth, config: input.config });
  const executor = createCreationExecutor({
    session: auth,
    async checkpoints(event) {
      if (event.step !== input.step || event.phase !== input.phase) return;
      // No commit is in flight here. Drain the actual holder without advancing
      // the executor, then stop this process at the acknowledged boundary.
      await owner.close();
      fs.writeSync(1, "durable-checkpoint");
      process.exit(73);
    },
  });
  const execute = new Promise((resolve, reject) => {
    process.once("message", (message) =>
      message === "execute" ? resolve() : reject(new Error("Checkpoint command rejected")),
    );
  });
  process.send({ kind: "ready" });
  await execute;
  await repository.withOperation(
    owner.binding,
    input.intent,
    new AbortController().signal,
    (handle) => executor.executeRecovery(owner.binding, handle, new AbortController().signal),
  );
  throw new Error("Expected durable checkpoint was not reached");
} catch {
  fs.writeSync(2, "Isolated checkpoint child failed.");
  process.exitCode = 1;
} finally {
  repository?.close();
  auth?.invalidate();
  await owner?.close();
  if (process.connected) process.disconnect();
}
